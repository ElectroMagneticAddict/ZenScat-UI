function Fitness = Merit_Function3(Work, P, NH,X, Params, Mode, ...
    interface, Obj , DispersionCoeffs, interface_stuff, refractive_idx)
%% Getting this fitness on bois!
    warning('off')
    P.Lx      = X(1);
    P.h       = X(2);
    Params(1) = X(3);
%% -----------------------------------------------------------------------
    grid      = Grid(Params, NH, interface, DispersionCoeffs, P, Work, refractive_idx);
    device    = Device(NH, grid, interface, Work, interface_stuff);
    [TRN, REF] = Launch_RCWA_S(NH, grid, device, Mode, false);
    if strcmp(Obj, 'R(-1)')
        Calc = REF.minus_1; 
    elseif strcmp(Obj, 'R(0)')
        Calc = REF.REF0; 
    elseif strcmp(Obj, 'R(+1)')
        Calc = REF.plus_1; 
    elseif strcmp(Obj, 'T(-1)')
        Calc = TRN.minus_1;
    elseif strcmp(Obj, 'T(0)')
        Calc = TRN.TRN0; 
    elseif strcmp(Obj, 'T(+1)')
        Calc = TRN.plus_1;
    elseif strcmp(Obj, 'Absorption')
        Calc = -1 * (TRN.sum + REF.sum);
    elseif strcmp(Obj, '')
        Calc = TRN.sum + REF.sum;
    end
    Fitness = -sum(Calc);
end