function [rec] = Rectangle(x)
% rectangle function
% evaluates rect(x)
% note: returns odd number of samples for full width
rec = abs(x)<=1/2;
end

