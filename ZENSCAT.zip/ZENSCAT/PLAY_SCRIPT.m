clear all
close all
% clc
%% Parameters
% Password: D@rius_69.
NH = 7; % 11 
N  = 2*NH + 1;  % N is a number of harmonics - always odd number 
lam.lam1 = 935e-9;     % Optimization - minimum wavelength (FWHM)
lam.lam2 = 960e-9;     % Optimization - maximum wavelength (FWHM)
theta.theta1 = -0.75*pi/180;
% Optimization -minimum angle (FWHM)
theta.theta2 = 0.75*pi/180;  % Optimization - maximum angle (FWHM)
interface = 'DE4';
% interface = 'DE4'; % sin for harmonic stuff
% interface = 'rec_bragg';
% interface = 'PhC_rec_circ';
% interface = 'PhC_rec_square';2
% interface = 'PhC_hex_columns';
% interface = 'PhC_honeycomb';
% interface = 'PhC_hex';
% sin for any layers smaller or bigger than modulatin depth
% 'DE1' for a trapsezium shape
% 'DE3' for a Gaussian shape
interface_stuff = Int_Params;
%% Dispersion
% materials -> 1,2,3,4,5,6 rows stand for HfO2(1), Nb2O5(2), SiO2(3), Ta2O5(4),
% Ti3O5(5), Ormocomp (6) respectively; 
% Params = [8 8 1 sqrt(12.05)]; % if PhC, period & material index
Params = [0.2 2];
interface_stuff.radius_star_ellipse = 0.4; % radius for PhC
distribution = 'all'; refractive_idx = 1; 
if strcmp(distribution, 'all')
    layer_num = ceil(length(Params)/2);
else
    layer_num = length(Params) - 2;
    if layer_num == 0
        layer_num = 1;
    end
end
[P] = Parameters(layer_num, distribution); % distribution - two or all for materials
Dispersion       = load('Dispersion.mat');
DispersionCoeffs = Dispersion.Dispersion;
%% Select work regime
Work = 'Casual';
%% Regular RCWA algorithm [0.3618    3.0000] 
for Mode =  ['E']
    P.Params = Params;
    grid     = Grid(Params, NH, interface, DispersionCoeffs, P, Work, refractive_idx); % all good
    device   = Device(NH,grid,interface, Work, interface_stuff);
    [TRN, REF] = Launch_RCWA_S_mex(NH, grid, device, Mode, false);
    % Plot_TRN_REF(TRN,REF,grid,Mode,Params, interface)
end

