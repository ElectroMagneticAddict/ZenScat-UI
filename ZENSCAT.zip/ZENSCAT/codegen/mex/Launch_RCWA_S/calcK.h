//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcK.h
//
// Code generation for function 'calcK'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void calcK(const emlrtStack &sp, const creal_T grid_urR, const creal_T grid_erR,
           const creal_T grid_urT, const creal_T grid_erT, real_T grid_Lx,
           real_T lam0, real_T theta, real_T NH, coder::array<creal_T, 2U> &Kx,
           coder::array<creal_T, 2U> &KzT, coder::array<creal_T, 2U> &KzR);

// End of code generation (calcK.h)
