//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// xsyheev.cpp
//
// Code generation for function 'xsyheev'
//

// Include files
#include "xsyheev.h"
#include "Launch_RCWA_S_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "lapacke.h"
#include <cstddef>

// Variable Definitions
static emlrtRSInfo lg_emlrtRSI{
    10,        // lineNo
    "xsyheev", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xsyheev.m" // pathName
};

static emlrtRSInfo mg_emlrtRSI{
    61,              // lineNo
    "ceval_xsyheev", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xsyheev.m" // pathName
};

static emlrtRTEInfo ch_emlrtRTEI{
    47,        // lineNo
    20,        // colNo
    "xsyheev", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xsyheev.m" // pName
};

// Function Definitions
namespace coder {
namespace internal {
namespace lapack {
int32_T xsyheev(const emlrtStack &sp, array<creal_T, 2U> &A,
                array<real_T, 1U> &W)
{
  static const char_T fname[13]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                '_', 'z', 'h', 'e', 'e', 'v'};
  ptrdiff_t n_t;
  emlrtStack b_st;
  emlrtStack st;
  int32_T info;
  st.prev = &sp;
  st.tls = sp.tls;
  st.site = &lg_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  n_t = (ptrdiff_t)A.size(0);
  W.set_size(&ch_emlrtRTEI, &st, A.size(0));
  if ((A.size(0) != 0) && (A.size(1) != 0)) {
    n_t = LAPACKE_zheev(102, 'V', 'L', n_t,
                        (lapack_complex_double *)&(A.data())[0], n_t,
                        &(W.data())[0]);
    info = (int32_T)n_t;
    b_st.site = &mg_emlrtRSI;
    if ((int32_T)n_t < 0) {
      if ((int32_T)n_t == -1010) {
        emlrtErrorWithMessageIdR2018a(&b_st, &e_emlrtRTEI, "MATLAB:nomem",
                                      "MATLAB:nomem", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &d_emlrtRTEI,
                                      "Coder:toolbox:LAPACKCallErrorInfo",
                                      "Coder:toolbox:LAPACKCallErrorInfo", 5, 4,
                                      13, &fname[0], 12, (int32_T)n_t);
      }
    }
  } else {
    info = 0;
  }
  return info;
}

} // namespace lapack
} // namespace internal
} // namespace coder

// End of code generation (xsyheev.cpp)
