//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_Launch_RCWA_S_info.cpp
//
// Code generation for function 'Launch_RCWA_S'
//

// Include files
#include "_coder_Launch_RCWA_S_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

// Function Definitions
static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[7]{
      "789ced994b8fd25018860f84311aa312638ccb59b875129871bc45132ec3c80cc3ad55ca"
      "583394f694167a9b9e76065cb9713d2e4ddcccdead7fc39d0bf5afe8"
      "425b5aa04d1a20250721fd36a75f5ee07df94ef3f41040ac78140300dc04c3badc1cae37"
      "9c3ee9ac71e02dbf1e73d62bbedead0d90f0bccfd52f9c95551503f6",
      "8d61a330321cbd935365516114831c6810e810a9d219e46c851725488a3224269bb2d5c9"
      "850969d45892759d1320db234c19e8021a2794269bd13c3e057cdfc4"
      "8cf3d80d9847d2a7bfd97b9b7b4abf425047b4a1ea8c42e721ea19aa46372af5433a9ddf"
      "ace71a19bac4980a2b9c58d727c4963cced90a99732330e750611989",
      "3d048bf30bba4f928e820cdd648db1dfc7907e5b817e5e7dc67db0c731cbfc6fcd98cfbf"
      "8e5f7fd55e7f93bf6c0997dfe7ccbd384e3fb796e5d70ff8bc59efaf"
      "bb017e499fae1d0cda5c87dce34a7a4d14b86233dbeff473e31cd5293ed37280801ed7e7"
      "af0a2fb59039fdcf317f4e57b74051d021243486b59e69b8f8c9a966",
      "5b82ffedbe78c68293a3ef8f7e60e528f8731e71142c9ea3e9d3725ba0d8669d3acd282a"
      "aa72e5c70d35e228768e86ddefdb5372baba058c3ae425c81aa2aa10"
      "22e7fc4058d679f432a4dfb3403faf3e074fbde3b13609e0e3c0f76f3fb172f5457cf70b"
      "4e3fb7d69dab5d9eaab6d9d28ea40f48833cae5070bf6b445c5d39ae",
      "de9992d3d52d7090ffe22159446882acabcad5e7817e5e7d0eaefac76393353aaf2ec8cf"
      "a975e7aad4e411936ff41f6a0702039bef1e7154b9f332e2eaaafdee"
      "bf3625a7ab5be0283103a83bfdb2781a765fd2817e5e7d0e9eda63718ea76b7b3ebd685d"
      "cfe2f4736bdd399ae225b6a6503212d9fdd7a9ed73b2c68b283a9f62",
      "e7682b64ce84af1fe71c2ac8606c74aeeaff4d0f02fdbcfa8cfb608d03ebb953bd8f9797"
      "5f8f9f7cc0e9e7d6baf372bbb8d33ba3aa26af76cbbd2a614ad90a9f"
      "2aac3e2fff020f88b22f",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 8376U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[9]{"Version",
                                 "ResolvedFunctions",
                                 "Checksum",
                                 "EntryPoints",
                                 "CoverageInfo",
                                 "IsPolymorphic",
                                 "PropertyList",
                                 "UUID",
                                 "ClassEntryPointIsHandle"};
  const char_T *epFieldName[8]{
      "Name",     "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "FullPath", "TimeStamp",      "Constructor",     "Visible"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 8, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 5);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("Launch_RCWA_S"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(5.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738892.63454861112));
  emlrtSetField(xEntryPoints, 0, "Constructor",
                emlrtMxCreateLogicalScalar(false));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 9, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("23.2.0.2380103 (R2023b) Update 1"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("Np4K3ViqtzP5pnn3OYGx8D"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_Launch_RCWA_S_info.cpp)
