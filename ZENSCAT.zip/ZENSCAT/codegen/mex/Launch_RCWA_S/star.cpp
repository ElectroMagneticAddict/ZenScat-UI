//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// star.cpp
//
// Code generation for function 'star'
//

// Include files
#include "star.h"
#include "Launch_RCWA_S_data.h"
#include "calcReflectionSide.h"
#include "eye.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Variable Definitions
static emlrtRSInfo gk_emlrtRSI{
    5,                                                 // lineNo
    "star",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pathName
};

static emlrtRSInfo hk_emlrtRSI{
    6,                                                 // lineNo
    "star",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pathName
};

static emlrtRSInfo ik_emlrtRSI{
    7,                                                 // lineNo
    "star",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pathName
};

static emlrtRSInfo jk_emlrtRSI{
    8,                                                 // lineNo
    "star",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pathName
};

static emlrtRSInfo kk_emlrtRSI{
    9,                                                 // lineNo
    "star",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pathName
};

static emlrtRSInfo lk_emlrtRSI{
    10,                                                // lineNo
    "star",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pathName
};

static emlrtECInfo pb_emlrtECI{
    1,                                                 // nDims
    5,                                                 // lineNo
    18,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo qb_emlrtECI{
    2,                                                 // nDims
    5,                                                 // lineNo
    18,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo rb_emlrtECI{
    1,                                                 // nDims
    6,                                                 // lineNo
    18,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo sb_emlrtECI{
    2,                                                 // nDims
    6,                                                 // lineNo
    18,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo tb_emlrtECI{
    1,                                                 // nDims
    7,                                                 // lineNo
    13,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo ub_emlrtECI{
    2,                                                 // nDims
    7,                                                 // lineNo
    13,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo vb_emlrtECI{
    1,                                                 // nDims
    10,                                                // lineNo
    13,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtECInfo wb_emlrtECI{
    2,                                                 // nDims
    10,                                                // lineNo
    13,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtRTEInfo tg_emlrtRTEI{
    5,                                                 // lineNo
    18,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtRTEInfo ug_emlrtRTEI{
    6,                                                 // lineNo
    18,                                                // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtRTEInfo vg_emlrtRTEI{
    7,                                                 // lineNo
    5,                                                 // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

static emlrtRTEInfo wg_emlrtRTEI{
    10,                                                // lineNo
    5,                                                 // colNo
    "star",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\star.m" // pName
};

// Function Declarations
static void plus(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                 const coder::array<creal_T, 2U> &in2,
                 const coder::array<creal_T, 2U> &in3);

// Function Definitions
static void plus(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                 const coder::array<creal_T, 2U> &in2,
                 const coder::array<creal_T, 2U> &in3)
{
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(&wg_emlrtRTEI, &sp, loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(&wg_emlrtRTEI, &sp, in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      int32_T i3;
      i2 = i1 * stride_0_0;
      i3 = i1 * stride_1_0;
      in1[i1 + in1.size(0) * i].re = in2[i2 + in2.size(0) * aux_0_1].re +
                                     in3[i3 + in3.size(0) * aux_1_1].re;
      in1[i1 + in1.size(0) * i].im = in2[i2 + in2.size(0) * aux_0_1].im +
                                     in3[i3 + in3.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

void star(const emlrtStack &sp, const coder::array<creal_T, 2U> &SA_S11,
          const coder::array<creal_T, 2U> &SA_S12,
          const coder::array<creal_T, 2U> &SA_S21,
          const coder::array<creal_T, 2U> &SA_S22,
          const coder::array<creal_T, 2U> &SB_S11,
          const coder::array<creal_T, 2U> &SB_S12,
          const coder::array<creal_T, 2U> &SB_S21,
          const coder::array<creal_T, 2U> &SB_S22,
          coder::array<creal_T, 2U> &S_S11, coder::array<creal_T, 2U> &S_S12,
          coder::array<creal_T, 2U> &S_S21, coder::array<creal_T, 2U> &S_S22)
{
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> D;
  coder::array<creal_T, 2U> F;
  coder::array<creal_T, 2U> r1;
  coder::array<real_T, 2U> r;
  emlrtStack b_st;
  emlrtStack st;
  int32_T loop_ub;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  //  Redheffer star product
  st.site = &gk_emlrtRSI;
  coder::eye(st, static_cast<real_T>(SA_S12.size(0)), r);
  st.site = &gk_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SA_S22.size(0) != SB_S11.size(1)) {
    if (((SB_S11.size(0) == 1) && (SB_S11.size(1) == 1)) ||
        ((SA_S22.size(0) == 1) && (SA_S22.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, SB_S11, SA_S22, B);
  if ((r.size(0) != B.size(0)) && ((r.size(0) != 1) && (B.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(r.size(0), B.size(0), &pb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((r.size(1) != B.size(1)) && ((r.size(1) != 1) && (B.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(r.size(1), B.size(1), &qb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  st.site = &gk_emlrtRSI;
  if ((r.size(0) == B.size(0)) && (r.size(1) == B.size(1))) {
    loop_ub = r.size(0) * r.size(1);
    B.set_size(&tg_emlrtRTEI, &st, r.size(0), r.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      B[i].re = r[i] - B[i].re;
      B[i].im = 0.0 - B[i].im;
    }
  } else {
    b_st.site = &gk_emlrtRSI;
    binary_expand_op_3(b_st, B, r);
  }
  if (B.size(1) != SA_S12.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, SA_S12, B, D);
  st.site = &hk_emlrtRSI;
  coder::eye(st, static_cast<real_T>(SA_S12.size(0)), r);
  st.site = &hk_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SB_S11.size(0) != SA_S22.size(1)) {
    if (((SA_S22.size(0) == 1) && (SA_S22.size(1) == 1)) ||
        ((SB_S11.size(0) == 1) && (SB_S11.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, SA_S22, SB_S11, B);
  if ((r.size(0) != B.size(0)) && ((r.size(0) != 1) && (B.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(r.size(0), B.size(0), &rb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((r.size(1) != B.size(1)) && ((r.size(1) != 1) && (B.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(r.size(1), B.size(1), &sb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  st.site = &hk_emlrtRSI;
  if ((r.size(0) == B.size(0)) && (r.size(1) == B.size(1))) {
    loop_ub = r.size(0) * r.size(1);
    B.set_size(&ug_emlrtRTEI, &st, r.size(0), r.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      B[i].re = r[i] - B[i].re;
      B[i].im = 0.0 - B[i].im;
    }
  } else {
    b_st.site = &hk_emlrtRSI;
    binary_expand_op_3(b_st, B, r);
  }
  if (B.size(1) != SB_S21.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, SB_S21, B, F);
  st.site = &ik_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SB_S11.size(0) != D.size(1)) {
    if (((D.size(0) == 1) && (D.size(1) == 1)) ||
        ((SB_S11.size(0) == 1) && (SB_S11.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, D, SB_S11, B);
  st.site = &ik_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SA_S21.size(0) != B.size(1)) {
    if (((B.size(0) == 1) && (B.size(1) == 1)) ||
        ((SA_S21.size(0) == 1) && (SA_S21.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, B, SA_S21, r1);
  if ((SA_S11.size(0) != r1.size(0)) &&
      ((SA_S11.size(0) != 1) && (r1.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(SA_S11.size(0), r1.size(0), &tb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((SA_S11.size(1) != r1.size(1)) &&
      ((SA_S11.size(1) != 1) && (r1.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(SA_S11.size(1), r1.size(1), &ub_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((SA_S11.size(0) == r1.size(0)) && (SA_S11.size(1) == r1.size(1))) {
    S_S11.set_size(&vg_emlrtRTEI, &sp, SA_S11.size(0), SA_S11.size(1));
    loop_ub = SA_S11.size(0) * SA_S11.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      S_S11[i].re = SA_S11[i].re + r1[i].re;
      S_S11[i].im = SA_S11[i].im + r1[i].im;
    }
  } else {
    st.site = &ik_emlrtRSI;
    plus(st, S_S11, SA_S11, r1);
  }
  st.site = &jk_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SB_S12.size(0) != D.size(1)) {
    if (((D.size(0) == 1) && (D.size(1) == 1)) ||
        ((SB_S12.size(0) == 1) && (SB_S12.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, D, SB_S12, S_S12);
  st.site = &kk_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SA_S21.size(0) != F.size(1)) {
    if (((F.size(0) == 1) && (F.size(1) == 1)) ||
        ((SA_S21.size(0) == 1) && (SA_S21.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, F, SA_S21, S_S21);
  st.site = &lk_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SA_S22.size(0) != F.size(1)) {
    if (((F.size(0) == 1) && (F.size(1) == 1)) ||
        ((SA_S22.size(0) == 1) && (SA_S22.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, F, SA_S22, B);
  st.site = &lk_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (SB_S12.size(0) != B.size(1)) {
    if (((B.size(0) == 1) && (B.size(1) == 1)) ||
        ((SB_S12.size(0) == 1) && (SB_S12.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, B, SB_S12, r1);
  if ((SB_S22.size(0) != r1.size(0)) &&
      ((SB_S22.size(0) != 1) && (r1.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(SB_S22.size(0), r1.size(0), &vb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((SB_S22.size(1) != r1.size(1)) &&
      ((SB_S22.size(1) != 1) && (r1.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(SB_S22.size(1), r1.size(1), &wb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((SB_S22.size(0) == r1.size(0)) && (SB_S22.size(1) == r1.size(1))) {
    S_S22.set_size(&wg_emlrtRTEI, &sp, SB_S22.size(0), SB_S22.size(1));
    loop_ub = SB_S22.size(0) * SB_S22.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      S_S22[i].re = SB_S22[i].re + r1[i].re;
      S_S22[i].im = SB_S22[i].im + r1[i].im;
    }
  } else {
    st.site = &lk_emlrtRSI;
    plus(st, S_S22, SB_S22, r1);
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

// End of code generation (star.cpp)
