//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// xunormqr.cpp
//
// Code generation for function 'xunormqr'
//

// Include files
#include "xunormqr.h"
#include "Launch_RCWA_S_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>

// Function Definitions
namespace coder {
namespace internal {
namespace lapack {
void xunormqr(const emlrtStack &sp, const array<creal_T, 2U> &Q,
              array<creal_T, 2U> &C, const array<creal_T, 1U> &tau)
{
  static const char_T fname[14]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                '_', 'z', 'u', 'n', 'm', 'q', 'r'};
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  st.site = &gd_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  if ((Q.size(0) != 0) && (Q.size(1) != 0) &&
      ((C.size(0) != 0) && (C.size(1) != 0))) {
    ptrdiff_t nrc_t;
    int32_T a_tmp;
    int32_T mn;
    boolean_T p;
    nrc_t = (ptrdiff_t)C.size(0);
    mn = Q.size(0);
    a_tmp = Q.size(1);
    nrc_t = LAPACKE_zunmqr(
        102, 'L', 'C', nrc_t, (ptrdiff_t)C.size(1),
        (ptrdiff_t)muIntScalarMin_sint32(mn, a_tmp),
        (lapack_complex_double *)&(((array<creal_T, 2U> *)&Q)->data())[0],
        (ptrdiff_t)Q.size(0),
        (lapack_complex_double *)&(((array<creal_T, 1U> *)&tau)->data())[0],
        (lapack_complex_double *)&(C.data())[0], nrc_t);
    b_st.site = &hd_emlrtRSI;
    if ((int32_T)nrc_t != 0) {
      boolean_T b_p;
      p = true;
      b_p = false;
      if ((int32_T)nrc_t == -7) {
        b_p = true;
      } else if ((int32_T)nrc_t == -9) {
        b_p = true;
      } else if ((int32_T)nrc_t == -10) {
        b_p = true;
      }
      if (!b_p) {
        if ((int32_T)nrc_t == -1010) {
          emlrtErrorWithMessageIdR2018a(&b_st, &e_emlrtRTEI, "MATLAB:nomem",
                                        "MATLAB:nomem", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &d_emlrtRTEI,
                                        "Coder:toolbox:LAPACKCallErrorInfo",
                                        "Coder:toolbox:LAPACKCallErrorInfo", 5,
                                        4, 14, &fname[0], 12, (int32_T)nrc_t);
        }
      }
    } else {
      p = false;
    }
    if (p) {
      if (((int32_T)nrc_t == -10) && (C.size(1) > 1)) {
        int32_T m;
        int32_T nb;
        b_st.site = &id_emlrtRSI;
        m = Q.size(0);
        nb = C.size(1);
        mn = Q.size(0);
        a_tmp = Q.size(1);
        mn = muIntScalarMin_sint32(mn, a_tmp);
        c_st.site = &jd_emlrtRSI;
        if (mn > 2147483646) {
          d_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(d_st);
        }
        for (int32_T j{0}; j < mn; j++) {
          real_T tauj_im;
          real_T tauj_re;
          tauj_re = tau[j].re;
          tauj_im = -tau[j].im;
          if ((tauj_re != 0.0) || (tauj_im != 0.0)) {
            c_st.site = &kd_emlrtRSI;
            if (nb > 2147483646) {
              d_st.site = &eb_emlrtRSI;
              check_forloop_overflow_error(d_st);
            }
            a_tmp = j + 2;
            p = ((j + 2 <= m) && (m > 2147483646));
            for (int32_T k{0}; k < nb; k++) {
              real_T im;
              real_T re;
              real_T wj_im;
              real_T wj_im_tmp;
              real_T wj_re;
              real_T wj_re_tmp;
              wj_re_tmp = C[j + C.size(0) * k].re;
              wj_re = wj_re_tmp;
              wj_im_tmp = C[j + C.size(0) * k].im;
              wj_im = wj_im_tmp;
              c_st.site = &ld_emlrtRSI;
              if (p) {
                d_st.site = &eb_emlrtRSI;
                check_forloop_overflow_error(d_st);
              }
              for (int32_T i{a_tmp}; i <= m; i++) {
                real_T b_wj_re_tmp;
                real_T c_wj_re_tmp;
                re = C[(i + C.size(0) * k) - 1].re;
                im = C[(i + C.size(0) * k) - 1].im;
                b_wj_re_tmp = Q[(i + Q.size(0) * j) - 1].re;
                c_wj_re_tmp = Q[(i + Q.size(0) * j) - 1].im;
                wj_re += b_wj_re_tmp * re + c_wj_re_tmp * im;
                wj_im += b_wj_re_tmp * im - c_wj_re_tmp * re;
              }
              re = tauj_re * wj_re - tauj_im * wj_im;
              im = tauj_re * wj_im + tauj_im * wj_re;
              if ((re != 0.0) || (im != 0.0)) {
                C[j + C.size(0) * k].re = wj_re_tmp - re;
                C[j + C.size(0) * k].im = wj_im_tmp - im;
                c_st.site = &md_emlrtRSI;
                for (int32_T i{a_tmp}; i <= m; i++) {
                  wj_re = Q[(i + Q.size(0) * j) - 1].re;
                  wj_im = Q[(i + Q.size(0) * j) - 1].im;
                  C[(i + C.size(0) * k) - 1].re =
                      C[(i + C.size(0) * k) - 1].re - (wj_re * re - wj_im * im);
                  C[(i + C.size(0) * k) - 1].im =
                      C[(i + C.size(0) * k) - 1].im - (wj_re * im + wj_im * re);
                }
              }
            }
          }
        }
      } else {
        int32_T m;
        int32_T nb;
        m = C.size(0);
        nb = C.size(1);
        for (mn = 0; mn < nb; mn++) {
          for (a_tmp = 0; a_tmp < m; a_tmp++) {
            C[a_tmp + C.size(0) * mn].re = rtNaN;
            C[a_tmp + C.size(0) * mn].im = 0.0;
          }
        }
      }
    }
  }
}

} // namespace lapack
} // namespace internal
} // namespace coder

// End of code generation (xunormqr.cpp)
