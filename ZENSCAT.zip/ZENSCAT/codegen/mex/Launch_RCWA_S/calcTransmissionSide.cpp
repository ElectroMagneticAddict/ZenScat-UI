//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcTransmissionSide.cpp
//
// Code generation for function 'calcTransmissionSide'
//

// Include files
#include "calcTransmissionSide.h"
#include "Launch_RCWA_S_data.h"
#include "Launch_RCWA_S_mexutil.h"
#include "calcReflectionSide.h"
#include "eml_mtimes_helper.h"
#include "eye.h"
#include "inv.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo we_emlrtRSI{
    3,                      // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo xe_emlrtRSI{
    6,                      // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo ye_emlrtRSI{
    8,                      // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo af_emlrtRSI{
    12,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo bf_emlrtRSI{
    14,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo cf_emlrtRSI{
    15,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo df_emlrtRSI{
    16,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo ef_emlrtRSI{
    17,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo ff_emlrtRSI{
    18,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtRSInfo gf_emlrtRSI{
    19,                     // lineNo
    "calcTransmissionSide", // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pathName
};

static emlrtDCInfo n_emlrtDCI{
    4,                      // lineNo
    22,                     // colNo
    "calcTransmissionSide", // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m", // pName
    1 // checkKind
};

static emlrtECInfo s_emlrtECI{
    1,                                                                 // nDims
    6,                                                                 // lineNo
    9,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo t_emlrtECI{
    2,                                                                 // nDims
    6,                                                                 // lineNo
    9,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo u_emlrtECI{
    1,                                                                 // nDims
    14,                                                                // lineNo
    5,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo v_emlrtECI{
    2,                                                                 // nDims
    14,                                                                // lineNo
    5,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo w_emlrtECI{
    1,                                                                 // nDims
    15,                                                                // lineNo
    5,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo x_emlrtECI{
    2,                                                                 // nDims
    15,                                                                // lineNo
    5,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo y_emlrtECI{
    1,                                                                 // nDims
    17,                                                                // lineNo
    17,                                                                // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtECInfo ab_emlrtECI{
    2,                                                                 // nDims
    17,                                                                // lineNo
    17,                                                                // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo wd_emlrtRTEI{
    4,                                                                 // lineNo
    1,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo xd_emlrtRTEI{
    11,                                                                // lineNo
    5,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo yd_emlrtRTEI{
    10,         // lineNo
    5,          // colNo
    "mldivide", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pName
};

static emlrtRTEInfo ae_emlrtRTEI{
    6,                                                                 // lineNo
    9,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo be_emlrtRTEI{
    6,                                                                 // lineNo
    28,                                                                // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo ce_emlrtRTEI{
    7,                                                                 // lineNo
    5,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo de_emlrtRTEI{
    14,                                                                // lineNo
    1,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo ee_emlrtRTEI{
    15,                                                                // lineNo
    1,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo fe_emlrtRTEI{
    17,                                                                // lineNo
    1,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo ge_emlrtRTEI{
    18,                                                                // lineNo
    1,                                                                 // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

static emlrtRTEInfo he_emlrtRTEI{
    19,                                                                // lineNo
    12,                                                                // colNo
    "calcTransmissionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcTransmissionSide.m" // pName
};

// Function Definitions
void calcTransmissionSide(
    const emlrtStack &sp, const coder::array<creal_T, 2U> &Kx,
    const coder::array<creal_T, 2U> &KzT, real_T N,
    const coder::array<real_T, 2U> &W0, const coder::array<creal_T, 2U> &V0,
    const creal_T grid_urT, const creal_T grid_erT, char_T mode,
    coder::array<real_T, 2U> &Wtrn, coder::array<creal_T, 2U> &Strn_S11,
    coder::array<creal_T, 2U> &Strn_S12, coder::array<creal_T, 2U> &Strn_S21,
    coder::array<creal_T, 2U> &Strn_S22)
{
  coder::array<creal_T, 2U> A;
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> Q;
  coder::array<creal_T, 2U> Vtrn;
  coder::array<creal_T, 2U> lam;
  coder::array<real_T, 2U> a;
  emlrtStack b_st;
  emlrtStack st;
  int32_T loop_ub;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  //  Transmitted modes throught the device
  st.site = &we_emlrtRSI;
  coder::eye(st, N, Wtrn);
  if (N != static_cast<int32_T>(muDoubleScalarFloor(N))) {
    emlrtIntegerCheckR2012b(N, &n_emlrtDCI, (emlrtConstCTX)&sp);
  }
  Vtrn.set_size(&wd_emlrtRTEI, &sp, static_cast<int32_T>(N),
                static_cast<int32_T>(N));
  loop_ub = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (int32_T i{0}; i < loop_ub; i++) {
    Vtrn[i].re = 0.0;
    Vtrn[i].im = 0.0;
  }
  if (mode == 'E') {
    real_T bim;
    real_T s;
    int32_T loop_ub_tmp;
    Q.set_size(&ae_emlrtRTEI, &sp, Kx.size(0), Kx.size(1));
    loop_ub = Kx.size(0) * Kx.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      creal_T varargin_1;
      real_T ar;
      real_T re;
      varargin_1 = Kx[i];
      re = varargin_1.re * varargin_1.re - varargin_1.im * varargin_1.im;
      s = varargin_1.re * varargin_1.im;
      ar = s + s;
      if (grid_urT.im == 0.0) {
        if (ar == 0.0) {
          Q[i].re = re / grid_urT.re;
          Q[i].im = 0.0;
        } else if (re == 0.0) {
          Q[i].re = 0.0;
          Q[i].im = ar / grid_urT.re;
        } else {
          Q[i].re = re / grid_urT.re;
          Q[i].im = ar / grid_urT.re;
        }
      } else if (grid_urT.re == 0.0) {
        if (re == 0.0) {
          Q[i].re = ar / grid_urT.im;
          Q[i].im = 0.0;
        } else if (ar == 0.0) {
          Q[i].re = 0.0;
          Q[i].im = -(re / grid_urT.im);
        } else {
          Q[i].re = ar / grid_urT.im;
          Q[i].im = -(re / grid_urT.im);
        }
      } else {
        real_T brm;
        brm = muDoubleScalarAbs(grid_urT.re);
        bim = muDoubleScalarAbs(grid_urT.im);
        if (brm > bim) {
          s = grid_urT.im / grid_urT.re;
          bim = grid_urT.re + s * grid_urT.im;
          Q[i].re = (re + s * ar) / bim;
          Q[i].im = (ar - s * re) / bim;
        } else if (bim == brm) {
          if (grid_urT.re > 0.0) {
            bim = 0.5;
          } else {
            bim = -0.5;
          }
          if (grid_urT.im > 0.0) {
            s = 0.5;
          } else {
            s = -0.5;
          }
          Q[i].re = (re * bim + ar * s) / brm;
          Q[i].im = (ar * bim - re * s) / brm;
        } else {
          s = grid_urT.re / grid_urT.im;
          bim = grid_urT.im + s * grid_urT.re;
          Q[i].re = (s * re + ar) / bim;
          Q[i].im = (s * ar - re) / bim;
        }
      }
    }
    st.site = &xe_emlrtRSI;
    coder::eye(st, N, a);
    lam.set_size(&be_emlrtRTEI, &sp, a.size(0), a.size(1));
    loop_ub_tmp = a.size(0) * a.size(1);
    for (int32_T i{0}; i < loop_ub_tmp; i++) {
      lam[i].re = a[i] * grid_erT.re;
      lam[i].im = a[i] * grid_erT.im;
    }
    if ((Q.size(0) != lam.size(0)) &&
        ((Q.size(0) != 1) && (lam.size(0) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Q.size(0), lam.size(0), &s_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((Q.size(1) != lam.size(1)) &&
        ((Q.size(1) != 1) && (lam.size(1) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Q.size(1), lam.size(1), &t_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((Q.size(0) == lam.size(0)) && (Q.size(1) == lam.size(1))) {
      for (int32_T i{0}; i < loop_ub; i++) {
        Q[i].re = Q[i].re - lam[i].re;
        Q[i].im = Q[i].im - lam[i].im;
      }
    } else {
      st.site = &xe_emlrtRSI;
      minus(st, Q, lam);
    }
    lam.set_size(&ce_emlrtRTEI, &sp, KzT.size(0), KzT.size(1));
    loop_ub = KzT.size(0) * KzT.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      s = KzT[i].im;
      bim = KzT[i].re;
      lam[i].re = 0.0 * bim - s;
      lam[i].im = 0.0 * s + bim;
    }
    st.site = &ye_emlrtRSI;
    if (lam.size(1) != Q.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                    "MATLAB:dimagree", 0);
    }
    b_st.site = &rb_emlrtRSI;
    coder::internal::mrdiv(b_st, Q, lam, Vtrn);
  } else if (mode == 'H') {
    real_T bim;
    real_T s;
    //      Q = (Kx.^2)/grid.erT - eye(N) * grid.urT;
    lam.set_size(&xd_emlrtRTEI, &sp, KzT.size(0), KzT.size(1));
    loop_ub = KzT.size(0) * KzT.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      s = KzT[i].im;
      bim = KzT[i].re;
      lam[i].re = 0.0 * bim - s;
      lam[i].im = 0.0 * s + bim;
    }
    Q.set_size(&yd_emlrtRTEI, &sp, Wtrn.size(0), Wtrn.size(1));
    loop_ub = Wtrn.size(0) * Wtrn.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      real_T ar;
      ar = Wtrn[i];
      if (grid_erT.im == 0.0) {
        Q[i].re = ar / grid_erT.re;
        Q[i].im = 0.0;
      } else if (grid_erT.re == 0.0) {
        if (ar == 0.0) {
          Q[i].re = 0.0 / grid_erT.im;
          Q[i].im = 0.0;
        } else {
          Q[i].re = 0.0;
          Q[i].im = -(ar / grid_erT.im);
        }
      } else {
        real_T brm;
        brm = muDoubleScalarAbs(grid_erT.re);
        bim = muDoubleScalarAbs(grid_erT.im);
        if (brm > bim) {
          s = grid_erT.im / grid_erT.re;
          bim = grid_erT.re + s * grid_erT.im;
          Q[i].re = (ar + s * 0.0) / bim;
          Q[i].im = (0.0 - s * ar) / bim;
        } else if (bim == brm) {
          if (grid_erT.re > 0.0) {
            bim = 0.5;
          } else {
            bim = -0.5;
          }
          if (grid_erT.im > 0.0) {
            s = 0.5;
          } else {
            s = -0.5;
          }
          Q[i].re = (ar * bim + 0.0 * s) / brm;
          Q[i].im = (0.0 * bim - ar * s) / brm;
        } else {
          s = grid_erT.re / grid_erT.im;
          bim = grid_erT.im + s * grid_erT.re;
          Q[i].re = s * ar / bim;
          Q[i].im = (s * 0.0 - ar) / bim;
        }
      }
    }
    st.site = &af_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    if (lam.size(0) != Q.size(1)) {
      if (((Q.size(0) == 1) && (Q.size(1) == 1)) ||
          ((lam.size(0) == 1) && (lam.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b_st.site = &se_emlrtRSI;
    coder::internal::blas::mtimes(b_st, Q, lam, Vtrn);
    //  according to Moharam and Gaylord.
  }
  st.site = &bf_emlrtRSI;
  coder::mldivide(st, W0, Wtrn, a);
  st.site = &bf_emlrtRSI;
  coder::mldivide(st, V0, Vtrn, A);
  if ((a.size(0) != A.size(0)) && ((a.size(0) != 1) && (A.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(0), A.size(0), &u_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(1) != A.size(1)) && ((a.size(1) != 1) && (A.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(1), A.size(1), &v_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(0) == A.size(0)) && (a.size(1) == A.size(1))) {
    loop_ub = a.size(0) * a.size(1);
    A.set_size(&de_emlrtRTEI, &sp, a.size(0), a.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      A[i].re = a[i] + A[i].re;
      A[i].im = A[i].im;
    }
  } else {
    st.site = &bf_emlrtRSI;
    binary_expand_op_4(st, A, a);
  }
  st.site = &cf_emlrtRSI;
  coder::mldivide(st, W0, Wtrn, a);
  st.site = &cf_emlrtRSI;
  coder::mldivide(st, V0, Vtrn, B);
  if ((a.size(0) != B.size(0)) && ((a.size(0) != 1) && (B.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(0), B.size(0), &w_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(1) != B.size(1)) && ((a.size(1) != 1) && (B.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(1), B.size(1), &x_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(0) == B.size(0)) && (a.size(1) == B.size(1))) {
    loop_ub = a.size(0) * a.size(1);
    B.set_size(&ee_emlrtRTEI, &sp, a.size(0), a.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      B[i].re = a[i] - B[i].re;
      B[i].im = 0.0 - B[i].im;
    }
  } else {
    st.site = &cf_emlrtRSI;
    binary_expand_op_3(st, B, a);
  }
  st.site = &df_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, B, A, Strn_S11);
  st.site = &ef_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, B, A, Q);
  st.site = &ef_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (B.size(0) != Q.size(1)) {
    if (((Q.size(0) == 1) && (Q.size(1) == 1)) ||
        ((B.size(0) == 1) && (B.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, Q, B, lam);
  if ((A.size(0) != lam.size(0)) && ((A.size(0) != 1) && (lam.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(0), lam.size(0), &y_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(1) != lam.size(1)) && ((A.size(1) != 1) && (lam.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(1), lam.size(1), &ab_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(0) == lam.size(0)) && (A.size(1) == lam.size(1))) {
    Strn_S12.set_size(&fe_emlrtRTEI, &sp, A.size(0), A.size(1));
    loop_ub = A.size(0) * A.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      Strn_S12[i].re = 0.5 * (A[i].re - lam[i].re);
      Strn_S12[i].im = 0.5 * (A[i].im - lam[i].im);
    }
  } else {
    st.site = &bl_emlrtRSI;
    binary_expand_op_2(st, Strn_S12, A, lam);
  }
  st.site = &ff_emlrtRSI;
  coder::inv(st, A, lam);
  Strn_S21.set_size(&ge_emlrtRTEI, &sp, lam.size(0), lam.size(1));
  loop_ub = lam.size(0) * lam.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    Strn_S21[i].re = 2.0 * lam[i].re;
    Strn_S21[i].im = 2.0 * lam[i].im;
  }
  Vtrn.set_size(&he_emlrtRTEI, &sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    Vtrn[i].re = -A[i].re;
    Vtrn[i].im = -A[i].im;
  }
  st.site = &gf_emlrtRSI;
  coder::mldivide(st, Vtrn, B, Strn_S22);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

// End of code generation (calcTransmissionSide.cpp)
