//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcLayer.cpp
//
// Code generation for function 'calcLayer'
//

// Include files
#include "calcLayer.h"
#include "Launch_RCWA_S_data.h"
#include "Launch_RCWA_S_mexutil.h"
#include "calcFreeSpace.h"
#include "eig.h"
#include "eml_mtimes_helper.h"
#include "expm.h"
#include "eye.h"
#include "mldivide.h"
#include "mpower.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "sqrt1.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo hf_emlrtRSI{
    8,                                                      // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo if_emlrtRSI{
    9,                                                      // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo jf_emlrtRSI{
    10,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo kf_emlrtRSI{
    11,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo lf_emlrtRSI{
    13,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo mf_emlrtRSI{
    14,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo nf_emlrtRSI{
    15,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo of_emlrtRSI{
    16,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo pf_emlrtRSI{
    18,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo qf_emlrtRSI{
    19,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo rf_emlrtRSI{
    20,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo sf_emlrtRSI{
    22,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo tf_emlrtRSI{
    23,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtRSInfo uf_emlrtRSI{
    24,                                                     // lineNo
    "calcLayer",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pathName
};

static emlrtBCInfo hb_emlrtBCI{
    -1,                                                      // iFirst
    -1,                                                      // iLast
    3,                                                       // lineNo
    22,                                                      // colNo
    "device.ERC",                                            // aName
    "calcLayer",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m", // pName
    0                                                        // checkKind
};

static emlrtBCInfo ib_emlrtBCI{
    1,                                                       // iFirst
    1,                                                       // iLast
    3,                                                       // lineNo
    32,                                                      // colNo
    "device.ERC",                                            // aName
    "calcLayer",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m", // pName
    0                                                        // checkKind
};

static emlrtDCInfo o_emlrtDCI{
    4,                                                       // lineNo
    21,                                                      // colNo
    "calcLayer",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m", // pName
    1                                                        // checkKind
};

static emlrtECInfo bb_emlrtECI{
    1,                                                      // nDims
    8,                                                      // lineNo
    17,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo cb_emlrtECI{
    2,                                                      // nDims
    8,                                                      // lineNo
    17,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo db_emlrtECI{
    1,                                                      // nDims
    13,                                                     // lineNo
    23,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo eb_emlrtECI{
    2,                                                      // nDims
    13,                                                     // lineNo
    23,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo fb_emlrtECI{
    1,                                                      // nDims
    19,                                                     // lineNo
    5,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo gb_emlrtECI{
    2,                                                      // nDims
    19,                                                     // lineNo
    5,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo hb_emlrtECI{
    1,                                                      // nDims
    20,                                                     // lineNo
    5,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo ib_emlrtECI{
    2,                                                      // nDims
    20,                                                     // lineNo
    5,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo jb_emlrtECI{
    1,                                                      // nDims
    22,                                                     // lineNo
    11,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo kb_emlrtECI{
    2,                                                      // nDims
    22,                                                     // lineNo
    11,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo lb_emlrtECI{
    1,                                                      // nDims
    23,                                                     // lineNo
    13,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo mb_emlrtECI{
    2,                                                      // nDims
    23,                                                     // lineNo
    13,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo nb_emlrtECI{
    1,                                                      // nDims
    24,                                                     // lineNo
    15,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtECInfo ob_emlrtECI{
    2,                                                      // nDims
    24,                                                     // lineNo
    15,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtBCInfo jb_emlrtBCI{
    -1,                                                      // iFirst
    -1,                                                      // iLast
    18,                                                      // lineNo
    52,                                                      // colNo
    "device.sub_L",                                          // aName
    "calcLayer",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m", // pName
    0                                                        // checkKind
};

static emlrtRTEInfo ie_emlrtRTEI{
    3,                                                      // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo je_emlrtRTEI{
    4,                                                      // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo ke_emlrtRTEI{
    5,                                                      // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo le_emlrtRTEI{
    6,                                                      // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo
    me_emlrtRTEI{
        76,                  // lineNo
        13,                  // colNo
        "eml_mtimes_helper", // fName
        "C:\\Program "
        "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_"
        "helper.m" // pName
    };

static emlrtRTEInfo ne_emlrtRTEI{
    22,                                                     // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo oe_emlrtRTEI{
    23,                                                     // lineNo
    13,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo pe_emlrtRTEI{
    27,                                                     // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo qe_emlrtRTEI{
    28,                                                     // lineNo
    1,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo gh_emlrtRTEI{
    22,                                                     // lineNo
    11,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo hh_emlrtRTEI{
    19,                                                     // lineNo
    5,                                                      // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

static emlrtRTEInfo ih_emlrtRTEI{
    8,                                                      // lineNo
    17,                                                     // colNo
    "calcLayer",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcLayer.m" // pName
};

// Function Declarations
static void b_minus(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                    const coder::array<creal_T, 2U> &in2);

static void binary_expand_op_10(const emlrtStack &sp, const emlrtRSInfo in1,
                                const coder::array<creal_T, 2U> &in2,
                                const coder::array<creal_T, 3U> &in3,
                                real_T in4, coder::array<creal_T, 2U> &in5,
                                coder::array<creal_T, 2U> &in6);

static void binary_expand_op_9(const emlrtStack &sp,
                               coder::array<creal_T, 2U> &in1,
                               const emlrtRSInfo in2,
                               const coder::array<creal_T, 2U> &in3,
                               const coder::array<creal_T, 2U> &in4,
                               const coder::array<creal_T, 2U> &in5);

static void plus(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                 const coder::array<creal_T, 2U> &in2);

// Function Definitions
static void b_minus(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                    const coder::array<creal_T, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in2;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(&gh_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      int32_T i3;
      i2 = i1 * stride_0_0;
      i3 = i1 * stride_1_0;
      b_in2[i1 + b_in2.size(0) * i].re = in2[i2 + in2.size(0) * aux_0_1].re -
                                         in1[i3 + in1.size(0) * aux_1_1].re;
      b_in2[i1 + b_in2.size(0) * i].im = in2[i2 + in2.size(0) * aux_0_1].im -
                                         in1[i3 + in1.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(&gh_emlrtRTEI, &sp, b_in2.size(0), b_in2.size(1));
  loop_ub = b_in2.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in2.size(0);
    for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void binary_expand_op_10(const emlrtStack &sp, const emlrtRSInfo in1,
                                const coder::array<creal_T, 2U> &in2,
                                const coder::array<creal_T, 3U> &in3,
                                real_T in4, coder::array<creal_T, 2U> &in5,
                                coder::array<creal_T, 2U> &in6)
{
  coder::array<creal_T, 2U> b_in2;
  emlrtStack st;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  b_in2.set_size(&ih_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      int32_T i3;
      i2 = i1 * stride_0_0;
      i3 = i1 * stride_1_0;
      b_in2[i1 + b_in2.size(0) * i].re =
          in2[i2 + in2.size(0) * aux_0_1].re -
          in3[(i3 + in3.size(0) * aux_1_1) +
              in3.size(0) * in3.size(1) * (static_cast<int32_T>(in4) - 1)]
              .re;
      b_in2[i1 + b_in2.size(0) * i].im =
          in2[i2 + in2.size(0) * aux_0_1].im -
          in3[(i3 + in3.size(0) * aux_1_1) +
              in3.size(0) * in3.size(1) * (static_cast<int32_T>(in4) - 1)]
              .im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  st.site = const_cast<emlrtRSInfo *>(&in1);
  coder::eig(st, b_in2, in5, in6);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void binary_expand_op_9(const emlrtStack &sp,
                               coder::array<creal_T, 2U> &in1,
                               const emlrtRSInfo in2,
                               const coder::array<creal_T, 2U> &in3,
                               const coder::array<creal_T, 2U> &in4,
                               const coder::array<creal_T, 2U> &in5)
{
  coder::array<creal_T, 2U> b_in4;
  emlrtStack st;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in5.size(0) == 1) {
    loop_ub = in4.size(0);
  } else {
    loop_ub = in5.size(0);
  }
  if (in5.size(1) == 1) {
    b_loop_ub = in4.size(1);
  } else {
    b_loop_ub = in5.size(1);
  }
  b_in4.set_size(&oe_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in4.size(0) != 1);
  stride_0_1 = (in4.size(1) != 1);
  stride_1_0 = (in5.size(0) != 1);
  stride_1_1 = (in5.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      int32_T i3;
      i2 = i1 * stride_0_0;
      i3 = i1 * stride_1_0;
      b_in4[i1 + b_in4.size(0) * i].re = in4[i2 + in4.size(0) * aux_0_1].re -
                                         in5[i3 + in5.size(0) * aux_1_1].re;
      b_in4[i1 + b_in4.size(0) * i].im = in4[i2 + in4.size(0) * aux_0_1].im -
                                         in5[i3 + in5.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  st.site = const_cast<emlrtRSInfo *>(&in2);
  coder::mldivide(st, in3, b_in4, in1);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void plus(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                 const coder::array<creal_T, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in1;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(&hh_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      int32_T i3;
      i2 = i1 * stride_0_0;
      i3 = i1 * stride_1_0;
      b_in1[i1 + b_in1.size(0) * i].re = in1[i2 + in1.size(0) * aux_0_1].re +
                                         in2[i3 + in2.size(0) * aux_1_1].re;
      b_in1[i1 + b_in1.size(0) * i].im = in1[i2 + in1.size(0) * aux_0_1].im +
                                         in2[i3 + in2.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(&hh_emlrtRTEI, &sp, b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void calcLayer(const emlrtStack &sp, const coder::array<creal_T, 2U> &Kx,
               real_T lam0, real_T N, const coder::array<real_T, 2U> &W0,
               const coder::array<creal_T, 2U> &V0,
               const coder::array<creal_T, 3U> &device_ERC,
               const coder::array<real_T, 2U> &device_sub_L, real_T layer,
               real_T sub_layer, char_T mode, coder::array<creal_T, 2U> &Si_S11,
               coder::array<creal_T, 2U> &Si_S12,
               coder::array<creal_T, 2U> &Si_S21,
               coder::array<creal_T, 2U> &Si_S22)
{
  coder::array<creal_T, 2U> A;
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> V;
  coder::array<creal_T, 2U> W;
  coder::array<creal_T, 2U> X;
  coder::array<creal_T, 2U> b_Si_S12;
  coder::array<creal_T, 2U> r;
  coder::array<real_T, 2U> r1;
  emlrtStack b_st;
  emlrtStack st;
  real_T b;
  real_T b_b;
  int32_T b_loop_ub;
  int32_T loop_ub;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  //  Get parameters for current layer
  if ((static_cast<int32_T>(layer) < 1) || (static_cast<int32_T>(layer) > 1)) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(layer), 1, 1,
                                  &ib_emlrtBCI, (emlrtConstCTX)&sp);
  }
  if ((static_cast<int32_T>(sub_layer) < 1) ||
      (static_cast<int32_T>(sub_layer) > device_ERC.size(2))) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(sub_layer), 1,
                                  device_ERC.size(2), &hb_emlrtBCI,
                                  (emlrtConstCTX)&sp);
  }
  Si_S11.set_size(&ie_emlrtRTEI, &sp, device_ERC.size(0), device_ERC.size(1));
  loop_ub = device_ERC.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_loop_ub = device_ERC.size(0);
    for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
      Si_S11[i1 + Si_S11.size(0) * i] =
          device_ERC[(i1 + device_ERC.size(0) * i) +
                     device_ERC.size(0) * device_ERC.size(1) *
                         (static_cast<int32_T>(sub_layer) - 1)];
    }
  }
  if (N != static_cast<int32_T>(muDoubleScalarFloor(N))) {
    emlrtIntegerCheckR2012b(N, &o_emlrtDCI, (emlrtConstCTX)&sp);
  }
  Si_S12.set_size(&je_emlrtRTEI, &sp, static_cast<int32_T>(N),
                  static_cast<int32_T>(N));
  loop_ub = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (int32_T i{0}; i < loop_ub; i++) {
    Si_S12[i].re = 0.0;
    Si_S12[i].im = 0.0;
  }
  W.set_size(&ke_emlrtRTEI, &sp, Si_S12.size(0), Si_S12.size(1));
  for (int32_T i{0}; i < loop_ub; i++) {
    W[i] = Si_S12[i];
  }
  V.set_size(&le_emlrtRTEI, &sp, Si_S12.size(0), Si_S12.size(1));
  for (int32_T i{0}; i < loop_ub; i++) {
    V[i] = Si_S12[i];
  }
  if (mode == 'E') {
    //  include air as well after the first try
    st.site = &hf_emlrtRSI;
    coder::mpower(st, Kx, r);
    if ((r.size(0) != device_ERC.size(0)) &&
        ((r.size(0) != 1) && (device_ERC.size(0) != 1))) {
      emlrtDimSizeImpxCheckR2021b(r.size(0), device_ERC.size(0), &bb_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((r.size(1) != device_ERC.size(1)) &&
        ((r.size(1) != 1) && (device_ERC.size(1) != 1))) {
      emlrtDimSizeImpxCheckR2021b(r.size(1), device_ERC.size(1), &cb_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((r.size(0) == device_ERC.size(0)) &&
        (r.size(1) == device_ERC.size(1))) {
      loop_ub = r.size(1);
      for (int32_T i{0}; i < loop_ub; i++) {
        b_loop_ub = r.size(0);
        for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
          r[i1 + r.size(0) * i].re =
              r[i1 + r.size(0) * i].re -
              device_ERC[(i1 + device_ERC.size(0) * i) +
                         device_ERC.size(0) * device_ERC.size(1) *
                             (static_cast<int32_T>(sub_layer) - 1)]
                  .re;
          r[i1 + r.size(0) * i].im =
              r[i1 + r.size(0) * i].im -
              device_ERC[(i1 + device_ERC.size(0) * i) +
                         device_ERC.size(0) * device_ERC.size(1) *
                             (static_cast<int32_T>(sub_layer) - 1)]
                  .im;
        }
      }
      st.site = &if_emlrtRSI;
      coder::eig(st, r, W, Si_S12);
    } else {
      st.site = &if_emlrtRSI;
      binary_expand_op_10(st, if_emlrtRSI, r, device_ERC, sub_layer, W, Si_S12);
    }
    st.site = &jf_emlrtRSI;
    coder::b_sqrt(st, Si_S12);
    st.site = &kf_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    coder::dynamic_size_checks(b_st, W, Si_S12, W.size(1), Si_S12.size(0));
    b_st.site = &se_emlrtRSI;
    coder::internal::blas::mtimes(b_st, W, Si_S12, V);
  } else if (mode == 'H') {
    st.site = &lf_emlrtRSI;
    if (device_ERC.size(1) != Kx.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                    "MATLAB:dimagree", 0);
    }
    b_st.site = &rb_emlrtRSI;
    coder::internal::mrdiv(b_st, Kx, Si_S11, W);
    st.site = &lf_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    coder::dynamic_size_checks(b_st, W, Kx, W.size(1), Kx.size(0));
    b_st.site = &se_emlrtRSI;
    coder::internal::blas::mtimes(b_st, W, Kx, Si_S12);
    st.site = &lf_emlrtRSI;
    coder::eye(st, N, r1);
    if ((Si_S12.size(0) != r1.size(0)) &&
        ((Si_S12.size(0) != 1) && (r1.size(0) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Si_S12.size(0), r1.size(0), &db_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((Si_S12.size(1) != r1.size(1)) &&
        ((Si_S12.size(1) != 1) && (r1.size(1) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Si_S12.size(1), r1.size(1), &eb_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    st.site = &lf_emlrtRSI;
    if ((Si_S12.size(0) == r1.size(0)) && (Si_S12.size(1) == r1.size(1))) {
      loop_ub = Si_S12.size(0) * Si_S12.size(1);
      for (int32_T i{0}; i < loop_ub; i++) {
        Si_S12[i].re = Si_S12[i].re - r1[i];
        Si_S12[i].im = Si_S12[i].im;
      }
    } else {
      b_st.site = &lf_emlrtRSI;
      binary_expand_op(b_st, Si_S12, r1);
    }
    b_st.site = &te_emlrtRSI;
    coder::dynamic_size_checks(b_st, Si_S11, Si_S12, device_ERC.size(1),
                               Si_S12.size(0));
    b_st.site = &se_emlrtRSI;
    coder::internal::blas::mtimes(b_st, Si_S11, Si_S12, V);
    st.site = &mf_emlrtRSI;
    coder::eig(st, V, W, Si_S12);
    st.site = &nf_emlrtRSI;
    coder::b_sqrt(st, Si_S12);
    st.site = &of_emlrtRSI;
    b_st.site = &of_emlrtRSI;
    coder::mldivide(b_st, Si_S11, W, B);
    b_st.site = &te_emlrtRSI;
    coder::dynamic_size_checks(b_st, B, Si_S12, B.size(1), Si_S12.size(0));
    b_st.site = &se_emlrtRSI;
    coder::internal::blas::mtimes(b_st, B, Si_S12, V);
    //  this is for TM
  }
  b = 6.2831853071795862 / lam0;
  if ((static_cast<int32_T>(sub_layer) < 1) ||
      (static_cast<int32_T>(sub_layer) > device_sub_L.size(1))) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(sub_layer), 1,
                                  device_sub_L.size(1), &jb_emlrtBCI,
                                  (emlrtConstCTX)&sp);
  }
  b_b = device_sub_L[static_cast<int32_T>(sub_layer) - 1];
  b_Si_S12.set_size(&me_emlrtRTEI, &sp, Si_S12.size(0), Si_S12.size(1));
  loop_ub = Si_S12.size(0) * Si_S12.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_Si_S12[i].re = b_b * (b * -Si_S12[i].re);
    b_Si_S12[i].im = b_b * (b * -Si_S12[i].im);
  }
  st.site = &pf_emlrtRSI;
  coder::expm(st, b_Si_S12, X);
  st.site = &qf_emlrtRSI;
  coder::mldivide(st, W, W0, A);
  st.site = &qf_emlrtRSI;
  coder::mldivide(st, V, V0, r);
  if ((A.size(0) != r.size(0)) && ((A.size(0) != 1) && (r.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(0), r.size(0), &fb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(1) != r.size(1)) && ((A.size(1) != 1) && (r.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(1), r.size(1), &gb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(0) == r.size(0)) && (A.size(1) == r.size(1))) {
    loop_ub = A.size(0) * A.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      A[i].re = A[i].re + r[i].re;
      A[i].im = A[i].im + r[i].im;
    }
  } else {
    st.site = &qf_emlrtRSI;
    plus(st, A, r);
  }
  st.site = &rf_emlrtRSI;
  coder::mldivide(st, W, W0, B);
  st.site = &rf_emlrtRSI;
  coder::mldivide(st, V, V0, r);
  if ((B.size(0) != r.size(0)) && ((B.size(0) != 1) && (r.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(B.size(0), r.size(0), &hb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((B.size(1) != r.size(1)) && ((B.size(1) != 1) && (r.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(B.size(1), r.size(1), &ib_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((B.size(0) == r.size(0)) && (B.size(1) == r.size(1))) {
    loop_ub = B.size(0) * B.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      B[i].re = B[i].re - r[i].re;
      B[i].im = B[i].im - r[i].im;
    }
  } else {
    st.site = &rf_emlrtRSI;
    minus(st, B, r);
  }
  //  S matrix > where the transverse modulation is not included (perfect for
  //  homogeneous layers)
  st.site = &sf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, X, B, X.size(1), B.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, X, B, V);
  st.site = &sf_emlrtRSI;
  if (A.size(1) != V.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, V, A, W);
  st.site = &sf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, W, X, W.size(1), X.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, W, X, V);
  st.site = &sf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, V, B, V.size(1), B.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, V, B, Si_S12);
  if ((A.size(0) != Si_S12.size(0)) &&
      ((A.size(0) != 1) && (Si_S12.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(0), Si_S12.size(0), &jb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(1) != Si_S12.size(1)) &&
      ((A.size(1) != 1) && (Si_S12.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(1), Si_S12.size(1), &kb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(0) == Si_S12.size(0)) && (A.size(1) == Si_S12.size(1))) {
    loop_ub = A.size(0) * A.size(1);
    Si_S12.set_size(&ne_emlrtRTEI, &sp, A.size(0), A.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      Si_S12[i].re = A[i].re - Si_S12[i].re;
      Si_S12[i].im = A[i].im - Si_S12[i].im;
    }
  } else {
    st.site = &sf_emlrtRSI;
    b_minus(st, Si_S12, A);
  }
  st.site = &tf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, X, B, X.size(1), B.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, X, B, V);
  st.site = &tf_emlrtRSI;
  if (A.size(1) != V.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, V, A, W);
  st.site = &tf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, W, X, W.size(1), X.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, W, X, V);
  st.site = &tf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, V, A, V.size(1), A.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, V, A, r);
  if ((r.size(0) != B.size(0)) && ((r.size(0) != 1) && (B.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(r.size(0), B.size(0), &lb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((r.size(1) != B.size(1)) && ((r.size(1) != 1) && (B.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(r.size(1), B.size(1), &mb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((r.size(0) == B.size(0)) && (r.size(1) == B.size(1))) {
    b_Si_S12.set_size(&oe_emlrtRTEI, &sp, r.size(0), r.size(1));
    loop_ub = r.size(0) * r.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      b_Si_S12[i].re = r[i].re - B[i].re;
      b_Si_S12[i].im = r[i].im - B[i].im;
    }
    st.site = &tf_emlrtRSI;
    coder::mldivide(st, Si_S12, b_Si_S12, Si_S11);
  } else {
    st.site = &tf_emlrtRSI;
    binary_expand_op_9(st, Si_S11, tf_emlrtRSI, Si_S12, r, B);
  }
  st.site = &uf_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, B, A, W);
  st.site = &uf_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, W, B, W.size(1), B.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, W, B, r);
  if ((A.size(0) != r.size(0)) && ((A.size(0) != 1) && (r.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(0), r.size(0), &nb_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(1) != r.size(1)) && ((A.size(1) != 1) && (r.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(1), r.size(1), &ob_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  st.site = &uf_emlrtRSI;
  b_st.site = &uf_emlrtRSI;
  coder::mldivide(b_st, Si_S12, X, B);
  if ((A.size(0) == r.size(0)) && (A.size(1) == r.size(1))) {
    loop_ub = A.size(0) * A.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      A[i].re = A[i].re - r[i].re;
      A[i].im = A[i].im - r[i].im;
    }
  } else {
    b_st.site = &uf_emlrtRSI;
    minus(b_st, A, r);
  }
  b_st.site = &te_emlrtRSI;
  coder::dynamic_size_checks(b_st, B, A, B.size(1), A.size(0));
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, B, A, Si_S12);
  Si_S21.set_size(&pe_emlrtRTEI, &sp, Si_S12.size(0), Si_S12.size(1));
  loop_ub = Si_S12.size(0) * Si_S12.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    Si_S21[i] = Si_S12[i];
  }
  Si_S22.set_size(&qe_emlrtRTEI, &sp, Si_S11.size(0), Si_S11.size(1));
  loop_ub = Si_S11.size(0) * Si_S11.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    Si_S22[i] = Si_S11[i];
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

// End of code generation (calcLayer.cpp)
