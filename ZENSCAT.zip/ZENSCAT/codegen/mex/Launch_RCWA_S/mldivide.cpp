//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// mldivide.cpp
//
// Code generation for function 'mldivide'
//

// Include files
#include "mldivide.h"
#include "Launch_RCWA_S_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "infocheck.h"
#include "lusolve.h"
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xgeqp3.h"
#include "xgetrfs.h"
#include "xunormqr.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>
#include <emmintrin.h>

// Variable Definitions
static emlrtRSInfo yd_emlrtRSI{
    20,         // lineNo
    "mldivide", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pathName
};

static emlrtRSInfo ae_emlrtRSI{
    42,      // lineNo
    "mldiv", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pathName
};

static emlrtRSInfo be_emlrtRSI{
    44,      // lineNo
    "mldiv", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pathName
};

static emlrtRSInfo fk_emlrtRSI{
    116,         // lineNo
    "LSQFromQR", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m" // pathName
};

static emlrtRTEInfo h_emlrtRTEI{
    16,         // lineNo
    19,         // colNo
    "mldivide", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pName
};

static emlrtRTEInfo ld_emlrtRTEI{
    85,        // lineNo
    26,        // colNo
    "qrsolve", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m" // pName
};

static emlrtRTEInfo md_emlrtRTEI{
    20,         // lineNo
    5,          // colNo
    "mldivide", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pName
};

static emlrtRTEInfo nd_emlrtRTEI{
    48,        // lineNo
    37,        // colNo
    "xgetrfs", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrfs.m" // pName
};

static emlrtRTEInfo sg_emlrtRTEI{
    116,       // lineNo
    5,         // colNo
    "qrsolve", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m" // pName
};

static const char_T cv1[19]{'L', 'A', 'P', 'A', 'C', 'K', 'E', '_', 'd', 'g',
                            'e', 't', 'r', 'f', '_', 'w', 'o', 'r', 'k'};

// Function Definitions
namespace coder {
void mldivide(const emlrtStack &sp, const array<real_T, 2U> &A,
              const array<real_T, 2U> &B, array<real_T, 2U> &Y)
{
  array<ptrdiff_t, 1U> IPIV;
  array<ptrdiff_t, 1U> r;
  array<real_T, 2U> b_A;
  array<real_T, 2U> b_B;
  array<real_T, 1U> tau;
  array<int32_T, 2U> jpvt;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (B.size(0) != A.size(0)) {
    emlrtErrorWithMessageIdR2018a(&sp, &h_emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  st.site = &yd_emlrtRSI;
  if ((A.size(0) == 0) || (A.size(1) == 0) ||
      ((B.size(0) == 0) || (B.size(1) == 0))) {
    int32_T m;
    Y.set_size(&md_emlrtRTEI, &st, A.size(1), B.size(1));
    m = A.size(1) * B.size(1);
    for (int32_T nb{0}; nb < m; nb++) {
      Y[nb] = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    ptrdiff_t INFO;
    ptrdiff_t LDA;
    ptrdiff_t nrc_t;
    int32_T m;
    int32_T ma;
    int32_T nb;
    b_st.site = &ae_emlrtRSI;
    c_st.site = &ub_emlrtRSI;
    Y.set_size(&md_emlrtRTEI, &c_st, B.size(0), B.size(1));
    m = B.size(0) * B.size(1);
    for (nb = 0; nb < m; nb++) {
      Y[nb] = B[nb];
    }
    d_st.site = &ce_emlrtRSI;
    e_st.site = &de_emlrtRSI;
    ma = A.size(0);
    m = A.size(1);
    nb = B.size(0);
    ma = muIntScalarMin_sint32(ma, m);
    ma = muIntScalarMin_sint32(nb, ma);
    f_st.site = &ee_emlrtRSI;
    b_A.set_size(&nd_emlrtRTEI, &f_st, A.size(0), A.size(1));
    m = A.size(0) * A.size(1);
    for (nb = 0; nb < m; nb++) {
      b_A[nb] = A[nb];
    }
    g_st.site = &ge_emlrtRSI;
    nrc_t = (ptrdiff_t)0.0;
    r.set_size(&vc_emlrtRTEI, &g_st, ma);
    for (nb = 0; nb < ma; nb++) {
      r[nb] = nrc_t;
    }
    IPIV.set_size(&od_emlrtRTEI, &f_st, r.size(0));
    nrc_t = (ptrdiff_t)ma;
    LDA = (ptrdiff_t)b_A.size(0);
    INFO = LAPACKE_dgetrf_work(102, nrc_t, nrc_t, &(b_A.data())[0], LDA,
                               &(IPIV.data())[0]);
    g_st.site = &fe_emlrtRSI;
    if ((int32_T)INFO < 0) {
      if ((int32_T)INFO == -1010) {
        emlrtErrorWithMessageIdR2018a(&g_st, &e_emlrtRTEI, "MATLAB:nomem",
                                      "MATLAB:nomem", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&g_st, &d_emlrtRTEI,
                                      "Coder:toolbox:LAPACKCallErrorInfo",
                                      "Coder:toolbox:LAPACKCallErrorInfo", 5, 4,
                                      19, &cv1[0], 12, (int32_T)INFO);
      }
    }
    LAPACKE_dgetrs_work(102, 'N', nrc_t, (ptrdiff_t)B.size(1), &(b_A.data())[0],
                        LDA, &(IPIV.data())[0], &(Y.data())[0],
                        (ptrdiff_t)B.size(0));
    if (((A.size(0) != 1) || (A.size(1) != 1)) && ((int32_T)INFO > 0)) {
      d_st.site = &wb_emlrtRSI;
      e_st.site = &mc_emlrtRSI;
      internal::warning(e_st);
    }
  } else {
    int32_T b_nb;
    int32_T m;
    int32_T ma;
    int32_T nb;
    int32_T rankA;
    boolean_T overflow;
    b_st.site = &be_emlrtRSI;
    b_A.set_size(&wc_emlrtRTEI, &b_st, A.size(0), A.size(1));
    m = A.size(0) * A.size(1);
    for (nb = 0; nb < m; nb++) {
      b_A[nb] = A[nb];
    }
    c_st.site = &nc_emlrtRSI;
    internal::lapack::xgeqp3(c_st, b_A, tau, jpvt);
    c_st.site = &oc_emlrtRSI;
    rankA = internal::rankFromQR(c_st, b_A);
    c_st.site = &pc_emlrtRSI;
    b_B.set_size(&ld_emlrtRTEI, &c_st, B.size(0), B.size(1));
    m = B.size(0) * B.size(1);
    for (nb = 0; nb < m; nb++) {
      b_B[nb] = B[nb];
    }
    b_nb = b_B.size(1);
    ma = b_A.size(1);
    m = b_B.size(1);
    Y.set_size(&md_emlrtRTEI, &c_st, ma, m);
    m *= ma;
    for (nb = 0; nb < m; nb++) {
      Y[nb] = 0.0;
    }
    d_st.site = &cd_emlrtRSI;
    e_st.site = &gd_emlrtRSI;
    ma = b_A.size(0);
    m = b_A.size(1);
    ma = muIntScalarMin_sint32(ma, m);
    if ((b_A.size(0) != 0) && (b_A.size(1) != 0)) {
      ptrdiff_t nrc_t;
      nrc_t = (ptrdiff_t)b_B.size(0);
      nrc_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)b_B.size(1),
                             (ptrdiff_t)ma, &(b_A.data())[0],
                             (ptrdiff_t)b_A.size(0), &(tau.data())[0],
                             &(b_B.data())[0], nrc_t);
      f_st.site = &hd_emlrtRSI;
      if (internal::lapack::infocheck(f_st, (int32_T)nrc_t)) {
        if (((int32_T)nrc_t == -10) && (b_B.size(1) > 1)) {
          f_st.site = &id_emlrtRSI;
          m = b_A.size(0);
          nb = b_B.size(1);
          g_st.site = &jd_emlrtRSI;
          if (ma > 2147483646) {
            h_st.site = &eb_emlrtRSI;
            check_forloop_overflow_error(h_st);
          }
          for (int32_T j{0}; j < ma; j++) {
            if (tau[j] != 0.0) {
              int32_T a_tmp;
              g_st.site = &kd_emlrtRSI;
              if (nb > 2147483646) {
                h_st.site = &eb_emlrtRSI;
                check_forloop_overflow_error(h_st);
              }
              a_tmp = j + 2;
              overflow = ((j + 2 <= m) && (m > 2147483646));
              for (int32_T k{0}; k < nb; k++) {
                real_T wj;
                wj = b_B[j + b_B.size(0) * k];
                g_st.site = &ld_emlrtRSI;
                if (overflow) {
                  h_st.site = &eb_emlrtRSI;
                  check_forloop_overflow_error(h_st);
                }
                for (int32_T i{a_tmp}; i <= m; i++) {
                  wj += b_A[(i + b_A.size(0) * j) - 1] *
                        b_B[(i + b_B.size(0) * k) - 1];
                }
                wj *= tau[j];
                if (wj != 0.0) {
                  int32_T scalarLB;
                  int32_T vectorUB;
                  b_B[j + b_B.size(0) * k] = b_B[j + b_B.size(0) * k] - wj;
                  g_st.site = &md_emlrtRSI;
                  scalarLB = (((((m - j) - 1) / 2) << 1) + j) + 2;
                  vectorUB = scalarLB - 2;
                  for (int32_T i{a_tmp}; i <= vectorUB; i += 2) {
                    __m128d r1;
                    __m128d r2;
                    r1 = _mm_loadu_pd(&b_A[(i + b_A.size(0) * j) - 1]);
                    r2 = _mm_loadu_pd(&b_B[(i + b_B.size(0) * k) - 1]);
                    _mm_storeu_pd(
                        &b_B[(i + b_B.size(0) * k) - 1],
                        _mm_sub_pd(r2, _mm_mul_pd(r1, _mm_set1_pd(wj))));
                  }
                  for (int32_T i{scalarLB}; i <= m; i++) {
                    b_B[(i + b_B.size(0) * k) - 1] =
                        b_B[(i + b_B.size(0) * k) - 1] -
                        b_A[(i + b_A.size(0) * j) - 1] * wj;
                  }
                }
              }
            }
          }
        } else {
          ma = b_B.size(0);
          m = b_B.size(1);
          b_B.set_size(&yc_emlrtRTEI, &e_st, ma, m);
          m *= ma;
          for (nb = 0; nb < m; nb++) {
            b_B[nb] = rtNaN;
          }
        }
      }
    }
    d_st.site = &dd_emlrtRSI;
    if (b_nb > 2147483646) {
      e_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(e_st);
    }
    overflow = (rankA > 2147483646);
    for (int32_T k{0}; k < b_nb; k++) {
      d_st.site = &ed_emlrtRSI;
      if (overflow) {
        e_st.site = &eb_emlrtRSI;
        check_forloop_overflow_error(e_st);
      }
      for (int32_T i{0}; i < rankA; i++) {
        Y[(jpvt[i] + Y.size(0) * k) - 1] = b_B[i + b_B.size(0) * k];
      }
      for (int32_T j{rankA}; j >= 1; j--) {
        nb = jpvt[j - 1];
        Y[(nb + Y.size(0) * k) - 1] =
            Y[(nb + Y.size(0) * k) - 1] / b_A[(j + b_A.size(0) * (j - 1)) - 1];
        d_st.site = &fd_emlrtRSI;
        for (int32_T i{0}; i <= j - 2; i++) {
          Y[(jpvt[i] + Y.size(0) * k) - 1] =
              Y[(jpvt[i] + Y.size(0) * k) - 1] -
              Y[(nb + Y.size(0) * k) - 1] * b_A[i + b_A.size(0) * (j - 1)];
        }
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void mldivide(const emlrtStack &sp, const array<creal_T, 2U> &A,
              const array<real_T, 2U> &B, array<creal_T, 2U> &Y)
{
  array<creal_T, 2U> CB;
  array<creal_T, 2U> b_A;
  array<creal_T, 1U> tau;
  array<int32_T, 2U> jpvt;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (B.size(0) != A.size(0)) {
    emlrtErrorWithMessageIdR2018a(&sp, &h_emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  st.site = &yd_emlrtRSI;
  if ((A.size(0) == 0) || (A.size(1) == 0) ||
      ((B.size(0) == 0) || (B.size(1) == 0))) {
    int32_T loop_ub;
    Y.set_size(&md_emlrtRTEI, &st, A.size(1), B.size(1));
    loop_ub = A.size(1) * B.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    int32_T loop_ub;
    b_st.site = &ae_emlrtRSI;
    c_st.site = &ub_emlrtRSI;
    d_st.site = &ce_emlrtRSI;
    Y.set_size(&pd_emlrtRTEI, &d_st, B.size(0), B.size(1));
    loop_ub = B.size(0) * B.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      Y[i].re = B[i];
      Y[i].im = 0.0;
    }
    b_A.set_size(&qd_emlrtRTEI, &d_st, A.size(0), A.size(1));
    loop_ub = A.size(0) * A.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      b_A[i] = A[i];
    }
    e_st.site = &de_emlrtRSI;
    loop_ub = internal::lapack::xgetrfs(e_st, b_A, Y);
    if (((A.size(0) != 1) || (A.size(1) != 1)) && (loop_ub > 0)) {
      d_st.site = &wb_emlrtRSI;
      e_st.site = &mc_emlrtRSI;
      internal::warning(e_st);
    }
  } else {
    int32_T i;
    int32_T loop_ub;
    int32_T nb;
    int32_T rankA;
    boolean_T overflow;
    b_st.site = &be_emlrtRSI;
    b_A.set_size(&wc_emlrtRTEI, &b_st, A.size(0), A.size(1));
    loop_ub = A.size(0) * A.size(1);
    for (i = 0; i < loop_ub; i++) {
      b_A[i] = A[i];
    }
    c_st.site = &nc_emlrtRSI;
    internal::lapack::xgeqp3(c_st, b_A, tau, jpvt);
    c_st.site = &oc_emlrtRSI;
    rankA = internal::rankFromQR(c_st, b_A);
    c_st.site = &pc_emlrtRSI;
    nb = B.size(1);
    Y.set_size(&md_emlrtRTEI, &c_st, b_A.size(1), B.size(1));
    loop_ub = b_A.size(1) * B.size(1);
    for (i = 0; i < loop_ub; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
    CB.set_size(&sg_emlrtRTEI, &c_st, B.size(0), B.size(1));
    loop_ub = B.size(0) * B.size(1);
    for (i = 0; i < loop_ub; i++) {
      CB[i].re = B[i];
      CB[i].im = 0.0;
    }
    d_st.site = &fk_emlrtRSI;
    internal::lapack::xunormqr(d_st, b_A, CB, tau);
    d_st.site = &dd_emlrtRSI;
    if (B.size(1) > 2147483646) {
      e_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(e_st);
    }
    overflow = (rankA > 2147483646);
    for (int32_T k{0}; k < nb; k++) {
      d_st.site = &ed_emlrtRSI;
      if (overflow) {
        e_st.site = &eb_emlrtRSI;
        check_forloop_overflow_error(e_st);
      }
      for (loop_ub = 0; loop_ub < rankA; loop_ub++) {
        Y[(jpvt[loop_ub] + Y.size(0) * k) - 1] = CB[loop_ub + CB.size(0) * k];
      }
      for (int32_T j{rankA}; j >= 1; j--) {
        real_T ai;
        real_T ar;
        real_T bi;
        real_T br;
        real_T brm;
        real_T im;
        real_T re;
        real_T sgnbr;
        i = jpvt[j - 1];
        ar = Y[(i + Y.size(0) * k) - 1].re;
        ai = Y[(i + Y.size(0) * k) - 1].im;
        br = b_A[(j + b_A.size(0) * (j - 1)) - 1].re;
        bi = b_A[(j + b_A.size(0) * (j - 1)) - 1].im;
        if (bi == 0.0) {
          if (ai == 0.0) {
            re = ar / br;
            im = 0.0;
          } else if (ar == 0.0) {
            re = 0.0;
            im = ai / br;
          } else {
            re = ar / br;
            im = ai / br;
          }
        } else if (br == 0.0) {
          if (ar == 0.0) {
            re = ai / bi;
            im = 0.0;
          } else if (ai == 0.0) {
            re = 0.0;
            im = -(ar / bi);
          } else {
            re = ai / bi;
            im = -(ar / bi);
          }
        } else {
          brm = muDoubleScalarAbs(br);
          im = muDoubleScalarAbs(bi);
          if (brm > im) {
            brm = bi / br;
            im = br + brm * bi;
            re = (ar + brm * ai) / im;
            im = (ai - brm * ar) / im;
          } else if (im == brm) {
            if (br > 0.0) {
              sgnbr = 0.5;
            } else {
              sgnbr = -0.5;
            }
            if (bi > 0.0) {
              im = 0.5;
            } else {
              im = -0.5;
            }
            re = (ar * sgnbr + ai * im) / brm;
            im = (ai * sgnbr - ar * im) / brm;
          } else {
            brm = br / bi;
            im = bi + brm * br;
            re = (brm * ar + ai) / im;
            im = (brm * ai - ar) / im;
          }
        }
        Y[(i + Y.size(0) * k) - 1].re = re;
        Y[(i + Y.size(0) * k) - 1].im = im;
        d_st.site = &fd_emlrtRSI;
        for (loop_ub = 0; loop_ub <= j - 2; loop_ub++) {
          im = Y[(jpvt[j - 1] + Y.size(0) * k) - 1].re;
          brm = b_A[loop_ub + b_A.size(0) * (j - 1)].im;
          sgnbr = Y[(jpvt[j - 1] + Y.size(0) * k) - 1].im;
          br = b_A[loop_ub + b_A.size(0) * (j - 1)].re;
          Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].re =
              Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].re -
              (im * br - sgnbr * brm);
          Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].im =
              Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].im -
              (im * brm + sgnbr * br);
        }
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void mldivide(const emlrtStack &sp, const array<creal_T, 2U> &A,
              const array<creal_T, 2U> &B, array<creal_T, 2U> &Y)
{
  emlrtStack b_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  if (B.size(0) != A.size(0)) {
    emlrtErrorWithMessageIdR2018a(&sp, &h_emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  st.site = &yd_emlrtRSI;
  if ((A.size(0) == 0) || (A.size(1) == 0) ||
      ((B.size(0) == 0) || (B.size(1) == 0))) {
    int32_T loop_ub;
    Y.set_size(&md_emlrtRTEI, &st, A.size(1), B.size(1));
    loop_ub = A.size(1) * B.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    b_st.site = &ae_emlrtRSI;
    internal::lusolve(b_st, A, B, Y);
  } else {
    b_st.site = &be_emlrtRSI;
    internal::qrsolve(b_st, A, B, Y);
  }
}

void mldivide(const emlrtStack &sp, const array<real_T, 2U> &A,
              const array<real_T, 1U> &B, array<real_T, 1U> &Y)
{
  array<ptrdiff_t, 1U> IPIV;
  array<ptrdiff_t, 1U> r;
  array<real_T, 2U> b_A;
  array<real_T, 1U> b_B;
  array<real_T, 1U> tau;
  array<int32_T, 2U> jpvt;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (B.size(0) != A.size(0)) {
    emlrtErrorWithMessageIdR2018a(&sp, &h_emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  st.site = &yd_emlrtRSI;
  if ((A.size(0) == 0) || (A.size(1) == 0) || (B.size(0) == 0)) {
    int32_T na;
    Y.set_size(&md_emlrtRTEI, &st, A.size(1));
    na = A.size(1);
    for (int32_T i{0}; i < na; i++) {
      Y[i] = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    ptrdiff_t INFO;
    ptrdiff_t LDA;
    ptrdiff_t nrc_t;
    int32_T i;
    int32_T ma;
    int32_T na;
    b_st.site = &ae_emlrtRSI;
    c_st.site = &ub_emlrtRSI;
    Y.set_size(&md_emlrtRTEI, &c_st, B.size(0));
    na = B.size(0);
    for (i = 0; i < na; i++) {
      Y[i] = B[i];
    }
    int32_T mb;
    d_st.site = &ce_emlrtRSI;
    e_st.site = &de_emlrtRSI;
    ma = A.size(0);
    na = A.size(1);
    mb = B.size(0);
    i = muIntScalarMin_sint32(ma, na);
    ma = muIntScalarMin_sint32(mb, i);
    f_st.site = &ee_emlrtRSI;
    b_A.set_size(&nd_emlrtRTEI, &f_st, A.size(0), A.size(1));
    na = A.size(0) * A.size(1);
    for (i = 0; i < na; i++) {
      b_A[i] = A[i];
    }
    g_st.site = &ge_emlrtRSI;
    nrc_t = (ptrdiff_t)0.0;
    r.set_size(&vc_emlrtRTEI, &g_st, ma);
    for (i = 0; i < ma; i++) {
      r[i] = nrc_t;
    }
    IPIV.set_size(&od_emlrtRTEI, &f_st, r.size(0));
    nrc_t = (ptrdiff_t)ma;
    LDA = (ptrdiff_t)b_A.size(0);
    INFO = LAPACKE_dgetrf_work(102, nrc_t, nrc_t, &(b_A.data())[0], LDA,
                               &(IPIV.data())[0]);
    g_st.site = &fe_emlrtRSI;
    if ((int32_T)INFO < 0) {
      if ((int32_T)INFO == -1010) {
        emlrtErrorWithMessageIdR2018a(&g_st, &e_emlrtRTEI, "MATLAB:nomem",
                                      "MATLAB:nomem", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&g_st, &d_emlrtRTEI,
                                      "Coder:toolbox:LAPACKCallErrorInfo",
                                      "Coder:toolbox:LAPACKCallErrorInfo", 5, 4,
                                      19, &cv1[0], 12, (int32_T)INFO);
      }
    }
    LAPACKE_dgetrs_work(102, 'N', nrc_t, (ptrdiff_t)1, &(b_A.data())[0], LDA,
                        &(IPIV.data())[0], &(Y.data())[0],
                        (ptrdiff_t)B.size(0));
    if (((A.size(0) != 1) || (A.size(1) != 1)) && ((int32_T)INFO > 0)) {
      d_st.site = &wb_emlrtRSI;
      e_st.site = &mc_emlrtRSI;
      internal::warning(e_st);
    }
  } else {
    int32_T i;
    int32_T ma;
    int32_T mb;
    int32_T na;
    b_st.site = &be_emlrtRSI;
    b_A.set_size(&wc_emlrtRTEI, &b_st, A.size(0), A.size(1));
    na = A.size(0) * A.size(1);
    for (i = 0; i < na; i++) {
      b_A[i] = A[i];
    }
    c_st.site = &nc_emlrtRSI;
    internal::lapack::xgeqp3(c_st, b_A, tau, jpvt);
    c_st.site = &oc_emlrtRSI;
    mb = internal::rankFromQR(c_st, b_A);
    c_st.site = &pc_emlrtRSI;
    b_B.set_size(&ld_emlrtRTEI, &c_st, B.size(0));
    na = B.size(0);
    for (i = 0; i < na; i++) {
      b_B[i] = B[i];
    }
    Y.set_size(&md_emlrtRTEI, &c_st, b_A.size(1));
    na = b_A.size(1);
    for (i = 0; i < na; i++) {
      Y[i] = 0.0;
    }
    d_st.site = &cd_emlrtRSI;
    e_st.site = &gd_emlrtRSI;
    if ((b_A.size(0) != 0) && (b_A.size(1) != 0)) {
      ptrdiff_t nrc_t;
      nrc_t = (ptrdiff_t)b_B.size(0);
      i = b_A.size(0);
      na = b_A.size(1);
      nrc_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)1,
                             (ptrdiff_t)muIntScalarMin_sint32(i, na),
                             &(b_A.data())[0], (ptrdiff_t)b_A.size(0),
                             &(tau.data())[0], &(b_B.data())[0], nrc_t);
      f_st.site = &hd_emlrtRSI;
      if (internal::lapack::infocheck(f_st, (int32_T)nrc_t)) {
        ma = b_B.size(0);
        b_B.set_size(&yc_emlrtRTEI, &e_st, ma);
        for (i = 0; i < ma; i++) {
          b_B[i] = rtNaN;
        }
      }
    }
    d_st.site = &ed_emlrtRSI;
    if (mb > 2147483646) {
      e_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(e_st);
    }
    for (ma = 0; ma < mb; ma++) {
      Y[jpvt[ma] - 1] = b_B[ma];
    }
    for (na = mb; na >= 1; na--) {
      i = jpvt[na - 1];
      Y[i - 1] = Y[i - 1] / b_A[(na + b_A.size(0) * (na - 1)) - 1];
      d_st.site = &fd_emlrtRSI;
      for (ma = 0; ma <= na - 2; ma++) {
        Y[jpvt[ma] - 1] =
            Y[jpvt[ma] - 1] - Y[i - 1] * b_A[ma + b_A.size(0) * (na - 1)];
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace coder

// End of code generation (mldivide.cpp)
