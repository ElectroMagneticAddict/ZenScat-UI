//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Launch_RCWA_S_types.h
//
// Code generation for function 'Launch_RCWA_S'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"

// Type Definitions
struct struct0_T {
  coder::array<real_T, 2U> Lam0;
  coder::array<real_T, 2U> Theta;
  char_T distribution[3];
  creal_T urR;
  creal_T erR;
  creal_T urT;
  creal_T erT;
  creal_T erSub;
  coder::array<creal_T, 2U> erIdx;
  real_T h;
  real_T Lx;
  real_T Lz;
  real_T Nx;
  real_T Nz;
  real_T dz;
  real_T qx;
  real_T qz;
  coder::array<real_T, 2U> x;
  coder::array<real_T, 2U> Length;
  real_T delta;
  real_T layer_num;
};

struct struct1_T {
  coder::array<creal_T, 2U> ER;
  coder::array<creal_T, 2U> eps;
  coder::array<creal_T, 3U> ERC;
  coder::array<real_T, 2U> sub_L;
};

struct struct2_T {
  coder::array<real_T, 2U> minus_1;
  coder::array<real_T, 2U> plus_1;
  coder::array<real_T, 2U> TRN0;
  coder::array<real_T, 2U> sum;
};

struct struct3_T {
  coder::array<real_T, 2U> minus_1;
  coder::array<real_T, 2U> plus_1;
  coder::array<real_T, 2U> REF0;
  coder::array<real_T, 2U> sum;
};

// End of code generation (Launch_RCWA_S_types.h)
