//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// isschur.cpp
//
// Code generation for function 'isschur'
//

// Include files
#include "isschur.h"
#include "Launch_RCWA_S_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo ii_emlrtRSI{
    41,        // lineNo
    "isschur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\isschur"
    ".m" // pathName
};

static emlrtRSInfo ji_emlrtRSI{
    19,       // lineNo
    "istriu", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\istriu.m" // pathName
};

static emlrtRSInfo ki_emlrtRSI{
    20,       // lineNo
    "istriu", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\istriu.m" // pathName
};

// Function Definitions
namespace coder {
boolean_T isschur(const emlrtStack &sp, const array<creal_T, 2U> &T)
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  boolean_T y;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  if ((T.size(0) == 1) && (T.size(1) == 1)) {
    y = true;
  } else if (T.size(0) != T.size(1)) {
    y = false;
  } else {
    boolean_T b;
    boolean_T b1;
    st.site = &ii_emlrtRSI;
    y = true;
    b = (T.size(0) == 0);
    b1 = (T.size(1) == 0);
    if ((!b) && (!b1)) {
      int32_T j;
      int32_T minmn;
      boolean_T exitg2;
      minmn = T.size(0);
      j = T.size(1);
      minmn = muIntScalarMin_sint32(minmn, j);
      b_st.site = &ji_emlrtRSI;
      if (minmn > 2147483646) {
        c_st.site = &eb_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      j = 0;
      exitg2 = false;
      while ((!exitg2) && (j <= minmn - 1)) {
        int32_T exitg1;
        int32_T i;
        b_st.site = &ki_emlrtRSI;
        if ((j + 2 <= T.size(0)) && (T.size(0) > 2147483646)) {
          c_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(c_st);
        }
        i = j + 2;
        do {
          exitg1 = 0;
          if (i <= T.size(0)) {
            if ((!(T[(i + T.size(0) * j) - 1].re == 0.0)) ||
                (!(T[(i + T.size(0) * j) - 1].im == 0.0))) {
              y = false;
              exitg1 = 1;
            } else {
              i++;
            }
          } else {
            j++;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    }
  }
  return y;
}

} // namespace coder

// End of code generation (isschur.cpp)
