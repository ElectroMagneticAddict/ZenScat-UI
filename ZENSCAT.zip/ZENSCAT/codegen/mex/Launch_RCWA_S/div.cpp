//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// div.cpp
//
// Code generation for function 'div'
//

// Include files
#include "div.h"
#include "Launch_RCWA_S_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Function Definitions
void binary_expand_op_5(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                        const coder::array<real_T, 2U> &in2, const creal_T in3)
{
  coder::array<creal_T, 2U> b_in1;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(&of_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      real_T ai;
      real_T ar;
      int32_T ar_tmp;
      ar_tmp = i1 * stride_0_0;
      ar = in1[ar_tmp + in1.size(0) * aux_0_1].re -
           in2[i1 * stride_1_0 + in2.size(0) * aux_1_1];
      ai = in1[ar_tmp + in1.size(0) * aux_0_1].im;
      if (in3.im == 0.0) {
        if (ai == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = ar / in3.re;
          b_in1[i1 + b_in1.size(0) * i].im = 0.0;
        } else if (ar == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = 0.0;
          b_in1[i1 + b_in1.size(0) * i].im = ai / in3.re;
        } else {
          b_in1[i1 + b_in1.size(0) * i].re = ar / in3.re;
          b_in1[i1 + b_in1.size(0) * i].im = ai / in3.re;
        }
      } else if (in3.re == 0.0) {
        if (ar == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = ai / in3.im;
          b_in1[i1 + b_in1.size(0) * i].im = 0.0;
        } else if (ai == 0.0) {
          b_in1[i1 + b_in1.size(0) * i].re = 0.0;
          b_in1[i1 + b_in1.size(0) * i].im = -(ar / in3.im);
        } else {
          b_in1[i1 + b_in1.size(0) * i].re = ai / in3.im;
          b_in1[i1 + b_in1.size(0) * i].im = -(ar / in3.im);
        }
      } else {
        real_T bim;
        real_T brm;
        brm = muDoubleScalarAbs(in3.re);
        bim = muDoubleScalarAbs(in3.im);
        if (brm > bim) {
          real_T d;
          bim = in3.im / in3.re;
          d = in3.re + bim * in3.im;
          b_in1[i1 + b_in1.size(0) * i].re = (ar + bim * ai) / d;
          b_in1[i1 + b_in1.size(0) * i].im = (ai - bim * ar) / d;
        } else if (bim == brm) {
          real_T d;
          if (in3.re > 0.0) {
            bim = 0.5;
          } else {
            bim = -0.5;
          }
          if (in3.im > 0.0) {
            d = 0.5;
          } else {
            d = -0.5;
          }
          b_in1[i1 + b_in1.size(0) * i].re = (ar * bim + ai * d) / brm;
          b_in1[i1 + b_in1.size(0) * i].im = (ai * bim - ar * d) / brm;
        } else {
          real_T d;
          bim = in3.re / in3.im;
          d = in3.im + bim * in3.re;
          b_in1[i1 + b_in1.size(0) * i].re = (bim * ar + ai) / d;
          b_in1[i1 + b_in1.size(0) * i].im = (bim * ai - ar) / d;
        }
      }
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(&of_emlrtRTEI, &sp, b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

// End of code generation (div.cpp)
