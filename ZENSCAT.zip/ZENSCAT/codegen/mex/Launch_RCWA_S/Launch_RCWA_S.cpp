//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Launch_RCWA_S.cpp
//
// Code generation for function 'Launch_RCWA_S'
//

// Include files
#include "Launch_RCWA_S.h"
#include "Launch_RCWA_S_data.h"
#include "Launch_RCWA_S_types.h"
#include "abs.h"
#include "asin.h"
#include "calcFreeSpace.h"
#include "calcK.h"
#include "calcLayer.h"
#include "calcReflectionSide.h"
#include "calcTransmissionSide.h"
#include "eml_mtimes_helper.h"
#include "eye.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "sqrt1.h"
#include "star.h"
#include "sum.h"
#include "sumMatrixIncludeNaN.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Type Definitions
struct struct_T {
  coder::array<creal_T, 2U> S11;
  coder::array<creal_T, 2U> S12;
  coder::array<creal_T, 2U> S21;
  coder::array<creal_T, 2U> S22;
};

// Variable Definitions
static emlrtRSInfo emlrtRSI{
    5,                                                          // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo b_emlrtRSI{
    6,                                                          // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo c_emlrtRSI{
    32,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo d_emlrtRSI{
    33,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo e_emlrtRSI{
    34,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo f_emlrtRSI{
    35,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo g_emlrtRSI{
    39,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo h_emlrtRSI{
    40,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo i_emlrtRSI{
    43,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo j_emlrtRSI{
    44,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo k_emlrtRSI{
    46,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo l_emlrtRSI{
    48,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo m_emlrtRSI{
    49,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo n_emlrtRSI{
    51,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo o_emlrtRSI{
    55,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo p_emlrtRSI{
    57,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo q_emlrtRSI{
    58,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo r_emlrtRSI{
    62,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo s_emlrtRSI{
    66,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo t_emlrtRSI{
    68,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo u_emlrtRSI{
    70,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo v_emlrtRSI{
    74,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo w_emlrtRSI{
    76,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo x_emlrtRSI{
    80,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo y_emlrtRSI{
    82,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo ab_emlrtRSI{
    88,                                                         // lineNo
    "Launch_RCWA_S",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pathName
};

static emlrtRSInfo lb_emlrtRSI{
    3,                                                          // lineNo
    "calcFreeSpace",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pathName
};

static emlrtRSInfo mb_emlrtRSI{
    4,                                                          // lineNo
    "calcFreeSpace",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pathName
};

static emlrtRSInfo nb_emlrtRSI{
    5,                                                          // lineNo
    "calcFreeSpace",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pathName
};

static emlrtRSInfo ob_emlrtRSI{
    7,                                                          // lineNo
    "calcFreeSpace",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pathName
};

static emlrtRSInfo pb_emlrtRSI{
    9,                                                          // lineNo
    "calcFreeSpace",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pathName
};

static emlrtRSInfo qb_emlrtRSI{
    10,                                                         // lineNo
    "calcFreeSpace",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pathName
};

static emlrtDCInfo emlrtDCI{
    11,                                                          // lineNo
    24,                                                          // colNo
    "calcFreeSpace",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m", // pName
    1                                                            // checkKind
};

static emlrtECInfo emlrtECI{
    2,                                                          // nDims
    4,                                                          // lineNo
    10,                                                         // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtECInfo b_emlrtECI{
    1,                                                          // nDims
    4,                                                          // lineNo
    10,                                                         // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtECInfo c_emlrtECI{
    2,                                                          // nDims
    3,                                                          // lineNo
    24,                                                         // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtECInfo d_emlrtECI{
    1,                                                          // nDims
    3,                                                          // lineNo
    24,                                                         // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtBCInfo emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    8,                                                           // lineNo
    12,                                                          // colNo
    "S",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo b_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    14,                                                          // lineNo
    5,                                                           // colNo
    "src",                                                       // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtRTEInfo b_emlrtRTEI{
    37,                                                         // lineNo
    24,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtBCInfo c_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    30,                                                          // lineNo
    31,                                                          // colNo
    "grid.Theta",                                                // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtDCInfo b_emlrtDCI{
    7,                                                           // lineNo
    24,                                                          // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo c_emlrtDCI{
    4,                                                           // lineNo
    24,                                                          // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo d_emlrtDCI{
    4,                                                           // lineNo
    24,                                                          // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    4                                                            // checkKind
};

static emlrtDCInfo e_emlrtDCI{
    4,                                                           // lineNo
    26,                                                          // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo f_emlrtDCI{
    8,                                                           // lineNo
    24,                                                          // colNo
    "calcFreeSpace",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo g_emlrtDCI{
    8,                                                           // lineNo
    26,                                                          // colNo
    "calcFreeSpace",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo h_emlrtDCI{
    8,                                                           // lineNo
    12,                                                          // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo i_emlrtDCI{
    8,                                                           // lineNo
    12,                                                          // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    4                                                            // checkKind
};

static emlrtDCInfo j_emlrtDCI{
    4,                                                           // lineNo
    1,                                                           // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    1                                                            // checkKind
};

static emlrtDCInfo k_emlrtDCI{
    13,                                                          // lineNo
    1,                                                           // colNo
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    1                                                            // checkKind
};

static emlrtBCInfo d_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    11,                                                          // lineNo
    7,                                                           // colNo
    "S",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo e_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    28,                                                          // lineNo
    26,                                                          // colNo
    "grid.Lam0",                                                 // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtDCInfo l_emlrtDCI{
    8,                                                           // lineNo
    1,                                                           // colNo
    "calcFreeSpace",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m", // pName
    1                                                            // checkKind
};

static emlrtBCInfo f_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    52,                                                          // lineNo
    33,                                                          // colNo
    "R",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo g_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    52,                                                          // lineNo
    24,                                                          // colNo
    "REF.minus_1",                                               // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo h_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    52,                                                          // lineNo
    26,                                                          // colNo
    "REF.minus_1",                                               // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo i_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    53,                                                          // lineNo
    32,                                                          // colNo
    "R",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo j_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    53,                                                          // lineNo
    23,                                                          // colNo
    "REF.plus_1",                                                // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo k_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    53,                                                          // lineNo
    25,                                                          // colNo
    "REF.plus_1",                                                // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo l_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    54,                                                          // lineNo
    30,                                                          // colNo
    "R",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo m_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    54,                                                          // lineNo
    21,                                                          // colNo
    "REF.REF0",                                                  // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo n_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    54,                                                          // lineNo
    23,                                                          // colNo
    "REF.REF0",                                                  // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo o_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    55,                                                          // lineNo
    20,                                                          // colNo
    "REF.sum",                                                   // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo p_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    55,                                                          // lineNo
    22,                                                          // colNo
    "REF.sum",                                                   // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo q_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    85,                                                          // lineNo
    33,                                                          // colNo
    "T",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo r_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    85,                                                          // lineNo
    24,                                                          // colNo
    "TRN.minus_1",                                               // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo s_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    85,                                                          // lineNo
    26,                                                          // colNo
    "TRN.minus_1",                                               // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo t_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    86,                                                          // lineNo
    32,                                                          // colNo
    "T",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo u_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    86,                                                          // lineNo
    23,                                                          // colNo
    "TRN.plus_1",                                                // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo v_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    86,                                                          // lineNo
    25,                                                          // colNo
    "TRN.plus_1",                                                // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo w_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    87,                                                          // lineNo
    30,                                                          // colNo
    "T",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo x_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    87,                                                          // lineNo
    21,                                                          // colNo
    "TRN.TRN0",                                                  // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo y_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    87,                                                          // lineNo
    23,                                                          // colNo
    "TRN.TRN0",                                                  // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo ab_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    88,                                                          // lineNo
    20,                                                          // colNo
    "TRN.sum",                                                   // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo bb_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    88,                                                          // lineNo
    22,                                                          // colNo
    "TRN.sum",                                                   // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo cb_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    76,                                                          // lineNo
    48,                                                          // colNo
    "T",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtBCInfo db_emlrtBCI{
    -1,                                                          // iFirst
    -1,                                                          // iLast
    68,                                                          // lineNo
    48,                                                          // colNo
    "T",                                                         // aName
    "Launch_RCWA_S",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m", // pName
    0                                                            // checkKind
};

static emlrtRTEInfo s_emlrtRTEI{
    13,     // lineNo
    9,      // colNo
    "sqrt", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\elfun\\sqrt.m" // pName
};

static emlrtRTEInfo t_emlrtRTEI{
    4,                                                          // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo u_emlrtRTEI{
    5,                                                          // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo v_emlrtRTEI{
    6,                                                          // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo w_emlrtRTEI{
    7,                                                          // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo x_emlrtRTEI{
    1,                                                          // lineNo
    22,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo y_emlrtRTEI{
    13,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo ab_emlrtRTEI{
    17,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo bb_emlrtRTEI{
    18,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo cb_emlrtRTEI{
    19,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo db_emlrtRTEI{
    20,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo eb_emlrtRTEI{
    22,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo fb_emlrtRTEI{
    23,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo gb_emlrtRTEI{
    24,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo hb_emlrtRTEI{
    25,                                                         // lineNo
    1,                                                          // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo ib_emlrtRTEI{
    3,                                                          // lineNo
    33,                                                         // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtRTEInfo jb_emlrtRTEI{
    3,                                                          // lineNo
    11,                                                         // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtRTEInfo kb_emlrtRTEI{
    8,                                                          // lineNo
    1,                                                          // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtRTEInfo lb_emlrtRTEI{
    9,                                                          // lineNo
    1,                                                          // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtRTEInfo mb_emlrtRTEI{
    10,                                                         // lineNo
    1,                                                          // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtRTEInfo nb_emlrtRTEI{
    11,                                                         // lineNo
    1,                                                          // colNo
    "calcFreeSpace",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcFreeSpace.m" // pName
};

static emlrtRTEInfo ob_emlrtRTEI{
    33,                                                         // lineNo
    13,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo pb_emlrtRTEI{
    40,                                                         // lineNo
    27,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo qb_emlrtRTEI{
    43,                                                         // lineNo
    17,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo rb_emlrtRTEI{
    44,                                                         // lineNo
    17,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo
    sb_emlrtRTEI{
        88,                  // lineNo
        13,                  // colNo
        "eml_mtimes_helper", // fName
        "C:\\Program "
        "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_"
        "helper.m" // pName
    };

static emlrtRTEInfo
    tb_emlrtRTEI{
        88,                  // lineNo
        9,                   // colNo
        "eml_mtimes_helper", // fName
        "C:\\Program "
        "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_"
        "helper.m" // pName
    };

static emlrtRTEInfo ub_emlrtRTEI{
    51,                                                         // lineNo
    16,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo vb_emlrtRTEI{
    82,                                                         // lineNo
    24,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo wb_emlrtRTEI{
    82,                                                         // lineNo
    77,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo xb_emlrtRTEI{
    80,                                                         // lineNo
    24,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo yb_emlrtRTEI{
    80,                                                         // lineNo
    66,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo ac_emlrtRTEI{
    70,                                                         // lineNo
    24,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo bc_emlrtRTEI{
    70,                                                         // lineNo
    77,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo cc_emlrtRTEI{
    62,                                                         // lineNo
    24,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

static emlrtRTEInfo dc_emlrtRTEI{
    62,                                                         // lineNo
    66,                                                         // colNo
    "Launch_RCWA_S",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\Launch_RCWA_S.m" // pName
};

// Function Declarations
static void binary_expand_op_1(const emlrtStack &sp,
                               coder::array<creal_T, 2U> &in1,
                               const coder::array<real_T, 2U> &in2,
                               const coder::array<creal_T, 2U> &in3);

// Function Definitions
static void binary_expand_op_1(const emlrtStack &sp,
                               coder::array<creal_T, 2U> &in1,
                               const coder::array<real_T, 2U> &in2,
                               const coder::array<creal_T, 2U> &in3)
{
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(&jb_emlrtRTEI, &sp, loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(&jb_emlrtRTEI, &sp, in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      i2 = i1 * stride_1_0;
      in1[i1 + in1.size(0) * i].re =
          in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] -
          in3[i2 + in3.size(0) * aux_1_1].re;
      in1[i1 + in1.size(0) * i].im = 0.0 - in3[i2 + in3.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

void Launch_RCWA_S(const emlrtStack *sp, real_T NH, const struct0_T *grid,
                   const struct1_T *device, char_T Mode, boolean_T Calc_Fresnel,
                   struct2_T *TRN, struct3_T *REF)
{
  coder::array<struct_T, 2U> S;
  coder::array<creal_T, 2U> Kx;
  coder::array<creal_T, 2U> Kz;
  coder::array<creal_T, 2U> KzR;
  coder::array<creal_T, 2U> KzT;
  coder::array<creal_T, 2U> Omega2;
  coder::array<creal_T, 2U> Sref_S12;
  coder::array<creal_T, 2U> Sref_S21;
  coder::array<creal_T, 2U> Sref_S22;
  coder::array<creal_T, 2U> Strn_S11;
  coder::array<creal_T, 2U> Strn_S12;
  coder::array<creal_T, 2U> Strn_S21;
  coder::array<creal_T, 2U> Strn_S22;
  coder::array<creal_T, 2U> V0;
  coder::array<creal_T, 2U> b_expl_temp;
  coder::array<creal_T, 2U> c_expl_temp;
  coder::array<creal_T, 2U> d_expl_temp;
  coder::array<creal_T, 2U> e_expl_temp;
  coder::array<creal_T, 2U> expl_temp_S11;
  coder::array<creal_T, 2U> expl_temp_S12;
  coder::array<creal_T, 2U> expl_temp_S21;
  coder::array<creal_T, 2U> expl_temp_S22;
  coder::array<creal_T, 1U> b_Kx;
  coder::array<creal_T, 1U> b_csrc;
  coder::array<cuint8_T, 2U> SG_S11;
  coder::array<cuint8_T, 2U> SG_S22;
  coder::array<real_T, 2U> W0;
  coder::array<real_T, 2U> Wref;
  coder::array<real_T, 2U> Wtrn;
  coder::array<real_T, 1U> R;
  coder::array<real_T, 1U> T;
  coder::array<real_T, 1U> csrc;
  coder::array<real_T, 1U> src;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  struct_T expl_temp;
  creal_T b_dc;
  creal_T b_dc1;
  creal_T kzInc;
  creal_T theta_i;
  creal_T varargout_1;
  creal_T z;
  real_T N;
  real_T varargout_1_tmp;
  int32_T b_loop_ub;
  int32_T i;
  int32_T i1;
  int32_T i2;
  int32_T i3;
  int32_T loop_ub;
  int32_T loop_ub_tmp;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)sp);
  //  Define variables
  N = 2.0 * NH + 1.0;
  if (!(N >= 0.0)) {
    emlrtNonNegativeCheckR2012b(N, &d_emlrtDCI, (emlrtConstCTX)sp);
  }
  i = static_cast<int32_T>(muDoubleScalarFloor(N));
  if (N != i) {
    emlrtIntegerCheckR2012b(N, &c_emlrtDCI, (emlrtConstCTX)sp);
  }
  expl_temp.S11.set_size(&t_emlrtRTEI, sp, static_cast<int32_T>(N),
                         expl_temp.S11.size(1));
  if (N != i) {
    emlrtIntegerCheckR2012b(N, &e_emlrtDCI, (emlrtConstCTX)sp);
  }
  loop_ub = static_cast<int32_T>(N);
  expl_temp.S11.set_size(&t_emlrtRTEI, sp, expl_temp.S11.size(0),
                         static_cast<int32_T>(N));
  if (static_cast<int32_T>(N) != i) {
    emlrtIntegerCheckR2012b(N, &j_emlrtDCI, (emlrtConstCTX)sp);
  }
  loop_ub_tmp = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    expl_temp.S11[i1].re = 0.0;
    expl_temp.S11[i1].im = 0.0;
  }
  st.site = &emlrtRSI;
  coder::eye(st, N, Wref);
  expl_temp.S12.set_size(&u_emlrtRTEI, sp, Wref.size(0), Wref.size(1));
  b_loop_ub = Wref.size(0) * Wref.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    expl_temp.S12[i1].re = Wref[i1];
    expl_temp.S12[i1].im = 0.0;
  }
  st.site = &b_emlrtRSI;
  coder::eye(st, N, Wref);
  expl_temp.S21.set_size(&v_emlrtRTEI, sp, Wref.size(0), Wref.size(1));
  b_loop_ub = Wref.size(0) * Wref.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    expl_temp.S21[i1].re = Wref[i1];
    expl_temp.S21[i1].im = 0.0;
  }
  if (static_cast<int32_T>(N) != i) {
    emlrtIntegerCheckR2012b(N, &b_emlrtDCI, (emlrtConstCTX)sp);
  }
  expl_temp.S22.set_size(&w_emlrtRTEI, sp, static_cast<int32_T>(N),
                         static_cast<int32_T>(N));
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    expl_temp.S22[i1].re = 0.0;
    expl_temp.S22[i1].im = 0.0;
  }
  varargout_1_tmp = 4.0 * grid->layer_num + 2.0;
  if (!(varargout_1_tmp >= 0.0)) {
    emlrtNonNegativeCheckR2012b(varargout_1_tmp, &i_emlrtDCI,
                                (emlrtConstCTX)sp);
  }
  if (varargout_1_tmp !=
      static_cast<int32_T>(muDoubleScalarFloor(varargout_1_tmp))) {
    emlrtIntegerCheckR2012b(varargout_1_tmp, &h_emlrtDCI, (emlrtConstCTX)sp);
  }
  b_loop_ub = static_cast<int32_T>(varargout_1_tmp);
  S.set_size(&x_emlrtRTEI, sp, 1, b_loop_ub);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    if (i1 > S.size(1) - 1) {
      emlrtDynamicBoundsCheckR2012b(i1, 0, S.size(1) - 1, &emlrtBCI,
                                    (emlrtConstCTX)sp);
    }
    S[S.size(0) * i1].S11.set_size(&x_emlrtRTEI, sp, 0, 0);
    S[S.size(0) * i1].S12.set_size(&x_emlrtRTEI, sp, 0, 0);
    S[S.size(0) * i1].S21.set_size(&x_emlrtRTEI, sp, 0, 0);
    S[S.size(0) * i1].S22.set_size(&x_emlrtRTEI, sp, 0, 0);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b((emlrtConstCTX)sp);
    }
  }
  i1 = S.size(1);
  for (int32_T b_i{0}; b_i < i1; b_i++) {
    if (b_i > S.size(1) - 1) {
      emlrtDynamicBoundsCheckR2012b(b_i, 0, S.size(1) - 1, &d_emlrtBCI,
                                    (emlrtConstCTX)sp);
    }
    S[b_i] = expl_temp;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b((emlrtConstCTX)sp);
    }
  }
  if (static_cast<int32_T>(N) != i) {
    emlrtIntegerCheckR2012b(N, &k_emlrtDCI, (emlrtConstCTX)sp);
  }
  src.set_size(&y_emlrtRTEI, sp, static_cast<int32_T>(N));
  if (static_cast<int32_T>(N) != i) {
    emlrtIntegerCheckR2012b(N, &k_emlrtDCI, (emlrtConstCTX)sp);
  }
  for (i1 = 0; i1 < loop_ub; i1++) {
    src[i1] = 0.0;
  }
  i1 = static_cast<int32_T>(muDoubleScalarFloor(N / 2.0)) + 1;
  if (i1 > static_cast<int32_T>(N)) {
    emlrtDynamicBoundsCheckR2012b(i1, 1, static_cast<int32_T>(N), &b_emlrtBCI,
                                  (emlrtConstCTX)sp);
  }
  src[i1 - 1] = 1.0;
  //  Transmission profiles
  TRN->minus_1.set_size(&ab_emlrtRTEI, sp, grid->Lam0.size(1),
                        grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->minus_1[i1] = 0.0;
  }
  TRN->plus_1.set_size(&bb_emlrtRTEI, sp, grid->Lam0.size(1),
                       grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->plus_1[i1] = 0.0;
  }
  TRN->TRN0.set_size(&cb_emlrtRTEI, sp, grid->Lam0.size(1),
                     grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->TRN0[i1] = 0.0;
  }
  TRN->sum.set_size(&db_emlrtRTEI, sp, grid->Lam0.size(1), grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->sum[i1] = 0.0;
  }
  //  Reflection profiles
  REF->minus_1.set_size(&eb_emlrtRTEI, sp, grid->Lam0.size(1),
                        grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->minus_1[i1] = 0.0;
  }
  REF->plus_1.set_size(&fb_emlrtRTEI, sp, grid->Lam0.size(1),
                       grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->plus_1[i1] = 0.0;
  }
  REF->REF0.set_size(&gb_emlrtRTEI, sp, grid->Lam0.size(1),
                     grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->REF0[i1] = 0.0;
  }
  REF->sum.set_size(&hb_emlrtRTEI, sp, grid->Lam0.size(1), grid->Theta.size(1));
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->sum[i1] = 0.0;
  }
  i1 = grid->Lam0.size(1);
  if (i1 - 1 >= 0) {
    i2 = grid->Theta.size(1);
    if (i2 - 1 >= 0) {
      i3 = static_cast<int32_T>(grid->layer_num);
    }
  }
  for (int32_T b_i{0}; b_i < i1; b_i++) {
    real_T lam0;
    if (b_i + 1 > grid->Lam0.size(1)) {
      emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, grid->Lam0.size(1), &e_emlrtBCI,
                                    (emlrtConstCTX)sp);
    }
    lam0 = grid->Lam0[b_i];
    for (int32_T j{0}; j < i2; j++) {
      real_T Omega2_re_tmp;
      real_T ai;
      real_T ar;
      real_T b_Omega2_re_tmp;
      real_T b_kzInc_tmp;
      real_T brm;
      real_T c_kzInc_tmp;
      real_T kzInc_tmp;
      real_T re_tmp;
      int32_T i4;
      int32_T sub_layer;
      if (j + 1 > grid->Theta.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, grid->Theta.size(1),
                                      &c_emlrtBCI, (emlrtConstCTX)sp);
      }
      //            %% Kx, Kz and eigen-modes of outer regions
      st.site = &c_emlrtRSI;
      calcK(st, grid->urR, grid->erR, grid->urT, grid->erT, grid->Lx, lam0,
            grid->Theta[j], NH, Kx, KzT, KzR);
      st.site = &d_emlrtRSI;
      //  Free space propagation
      b_st.site = &lb_emlrtRSI;
      coder::eye(b_st, N, Wref);
      Omega2.set_size(&ib_emlrtRTEI, &st, Kx.size(0), Kx.size(1));
      loop_ub = Kx.size(0) * Kx.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        kzInc = Kx[i4];
        varargout_1.re = kzInc.re * kzInc.re - kzInc.im * kzInc.im;
        varargout_1_tmp = kzInc.re * kzInc.im;
        varargout_1.im = varargout_1_tmp + varargout_1_tmp;
        Omega2[i4] = varargout_1;
      }
      if ((Wref.size(0) != Omega2.size(0)) &&
          ((Wref.size(0) != 1) && (Omega2.size(0) != 1))) {
        emlrtDimSizeImpxCheckR2021b(Wref.size(0), Omega2.size(0), &d_emlrtECI,
                                    &st);
      }
      if ((Wref.size(1) != Omega2.size(1)) &&
          ((Wref.size(1) != 1) && (Omega2.size(1) != 1))) {
        emlrtDimSizeImpxCheckR2021b(Wref.size(1), Omega2.size(1), &c_emlrtECI,
                                    &st);
      }
      if ((Wref.size(0) == Omega2.size(0)) &&
          (Wref.size(1) == Omega2.size(1))) {
        Kz.set_size(&jb_emlrtRTEI, &st, Wref.size(0), Wref.size(1));
        loop_ub = Wref.size(0) * Wref.size(1);
        for (i4 = 0; i4 < loop_ub; i4++) {
          Kz[i4].re = Wref[i4] - Omega2[i4].re;
          Kz[i4].im = 0.0 - Omega2[i4].im;
        }
      } else {
        binary_expand_op_1(st, Kz, Wref, Omega2);
      }
      b_st.site = &lb_emlrtRSI;
      coder::b_sqrt(b_st, Kz);
      b_loop_ub = Kz.size(0) * Kz.size(1);
      for (i4 = 0; i4 < b_loop_ub; i4++) {
        Kz[i4].re = Kz[i4].re;
        Kz[i4].im = -Kz[i4].im;
      }
      b_st.site = &mb_emlrtRSI;
      coder::eye(b_st, N, Wref);
      if ((Omega2.size(0) != Wref.size(0)) &&
          ((Omega2.size(0) != 1) && (Wref.size(0) != 1))) {
        emlrtDimSizeImpxCheckR2021b(Omega2.size(0), Wref.size(0), &b_emlrtECI,
                                    &st);
      }
      if ((Omega2.size(1) != Wref.size(1)) &&
          ((Omega2.size(1) != 1) && (Wref.size(1) != 1))) {
        emlrtDimSizeImpxCheckR2021b(Omega2.size(1), Wref.size(1), &emlrtECI,
                                    &st);
      }
      if ((Omega2.size(0) == Wref.size(0)) &&
          (Omega2.size(1) == Wref.size(1))) {
        loop_ub = Omega2.size(0) * Omega2.size(1);
        for (i4 = 0; i4 < loop_ub; i4++) {
          Omega2[i4].re = Omega2[i4].re - Wref[i4];
          Omega2[i4].im = Omega2[i4].im;
        }
      } else {
        b_st.site = &mb_emlrtRSI;
        binary_expand_op(b_st, Omega2, Wref);
      }
      b_st.site = &nb_emlrtRSI;
      coder::eye(b_st, N, W0);
      for (i4 = 0; i4 < b_loop_ub; i4++) {
        varargout_1_tmp = Kz[i4].im;
        re_tmp = Kz[i4].re;
        Kz[i4].re = 0.0 * re_tmp - varargout_1_tmp;
        Kz[i4].im = 0.0 * varargout_1_tmp + re_tmp;
      }
      b_st.site = &ob_emlrtRSI;
      if (Kz.size(1) != Omega2.size(1)) {
        emlrtErrorWithMessageIdR2018a(&b_st, &emlrtRTEI, "MATLAB:dimagree",
                                      "MATLAB:dimagree", 0);
      }
      c_st.site = &rb_emlrtRSI;
      coder::internal::mrdiv(c_st, Omega2, Kz, V0);
      if (static_cast<int32_T>(N) != i) {
        emlrtIntegerCheckR2012b(N, &f_emlrtDCI, &st);
      }
      SG_S11.set_size(&kb_emlrtRTEI, &st, static_cast<int32_T>(N),
                      SG_S11.size(1));
      if (static_cast<int32_T>(N) != i) {
        emlrtIntegerCheckR2012b(N, &g_emlrtDCI, &st);
      }
      SG_S11.set_size(&kb_emlrtRTEI, &st, SG_S11.size(0),
                      static_cast<int32_T>(N));
      if (static_cast<int32_T>(N) != i) {
        emlrtIntegerCheckR2012b(N, &l_emlrtDCI, &st);
      }
      for (i4 = 0; i4 < loop_ub_tmp; i4++) {
        SG_S11[i4].re = 0U;
        SG_S11[i4].im = 0U;
      }
      b_st.site = &pb_emlrtRSI;
      coder::eye(b_st, N, Wref);
      expl_temp.S12.set_size(&lb_emlrtRTEI, &st, Wref.size(0), Wref.size(1));
      loop_ub = Wref.size(0) * Wref.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        expl_temp.S12[i4].re = Wref[i4];
        expl_temp.S12[i4].im = 0.0;
      }
      b_st.site = &qb_emlrtRSI;
      coder::eye(b_st, N, Wref);
      expl_temp.S21.set_size(&mb_emlrtRTEI, &st, Wref.size(0), Wref.size(1));
      loop_ub = Wref.size(0) * Wref.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        expl_temp.S21[i4].re = Wref[i4];
        expl_temp.S21[i4].im = 0.0;
      }
      if (static_cast<int32_T>(N) != i) {
        emlrtIntegerCheckR2012b(N, &emlrtDCI, &st);
      }
      SG_S22.set_size(&nb_emlrtRTEI, &st, static_cast<int32_T>(N),
                      static_cast<int32_T>(N));
      for (i4 = 0; i4 < loop_ub_tmp; i4++) {
        SG_S22[i4].re = 0U;
        SG_S22[i4].im = 0U;
      }
      expl_temp.S11.set_size(&ob_emlrtRTEI, sp, SG_S11.size(0), SG_S11.size(1));
      loop_ub = SG_S11.size(0) * SG_S11.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        expl_temp.S11[i4].re = 0.0;
        expl_temp.S11[i4].im = SG_S11[i4].im;
      }
      expl_temp.S22.set_size(&ob_emlrtRTEI, sp, SG_S22.size(0), SG_S22.size(1));
      for (i4 = 0; i4 < loop_ub_tmp; i4++) {
        expl_temp.S22[i4].re = 0.0;
        expl_temp.S22[i4].im = SG_S22[i4].im;
      }
      st.site = &e_emlrtRSI;
      calcReflectionSide(st, Kx, KzR, N, W0, V0, grid->urR, grid->erR, Mode,
                         Wref, Omega2, Sref_S12, Sref_S21, Sref_S22);
      st.site = &f_emlrtRSI;
      calcTransmissionSide(st, Kx, KzT, N, W0, V0, grid->urT, grid->erT, Mode,
                           Wtrn, Strn_S11, Strn_S12, Strn_S21, Strn_S22);
      //            %% S matrices for a device
      emlrtForLoopVectorCheckR2021a(1.0, 1.0, grid->layer_num, mxDOUBLE_CLASS,
                                    static_cast<int32_T>(grid->layer_num),
                                    &b_emlrtRTEI, (emlrtConstCTX)sp);
      for (b_loop_ub = 0; b_loop_ub < i3; b_loop_ub++) {
        i4 = device->sub_L.size(1);
        for (sub_layer = 0; sub_layer < i4; sub_layer++) {
          st.site = &g_emlrtRSI;
          calcLayer(st, Kx, lam0, N, W0, V0, device->ERC, device->sub_L,
                    static_cast<real_T>(b_loop_ub) + 1.0,
                    static_cast<real_T>(sub_layer) + 1.0, Mode, expl_temp_S11,
                    expl_temp_S12, expl_temp_S21, expl_temp_S22);
          b_expl_temp.set_size(&pb_emlrtRTEI, sp, expl_temp.S11.size(0),
                               expl_temp.S11.size(1));
          loop_ub = expl_temp.S11.size(0) * expl_temp.S11.size(1) - 1;
          for (int32_T i5{0}; i5 <= loop_ub; i5++) {
            b_expl_temp[i5] = expl_temp.S11[i5];
          }
          c_expl_temp.set_size(&pb_emlrtRTEI, sp, expl_temp.S12.size(0),
                               expl_temp.S12.size(1));
          loop_ub = expl_temp.S12.size(0) * expl_temp.S12.size(1) - 1;
          for (int32_T i5{0}; i5 <= loop_ub; i5++) {
            c_expl_temp[i5] = expl_temp.S12[i5];
          }
          d_expl_temp.set_size(&pb_emlrtRTEI, sp, expl_temp.S21.size(0),
                               expl_temp.S21.size(1));
          loop_ub = expl_temp.S21.size(0) * expl_temp.S21.size(1) - 1;
          for (int32_T i5{0}; i5 <= loop_ub; i5++) {
            d_expl_temp[i5] = expl_temp.S21[i5];
          }
          e_expl_temp.set_size(&pb_emlrtRTEI, sp, expl_temp.S22.size(0),
                               expl_temp.S22.size(1));
          loop_ub = expl_temp.S22.size(0) * expl_temp.S22.size(1) - 1;
          for (int32_T i5{0}; i5 <= loop_ub; i5++) {
            e_expl_temp[i5] = expl_temp.S22[i5];
          }
          st.site = &h_emlrtRSI;
          star(st, b_expl_temp, c_expl_temp, d_expl_temp, e_expl_temp,
               expl_temp_S11, expl_temp_S12, expl_temp_S21, expl_temp_S22,
               expl_temp.S11, expl_temp.S12, expl_temp.S21, expl_temp.S22);
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b((emlrtConstCTX)sp);
          }
        }
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b((emlrtConstCTX)sp);
        }
      }
      b_expl_temp.set_size(&qb_emlrtRTEI, sp, expl_temp.S11.size(0),
                           expl_temp.S11.size(1));
      loop_ub = expl_temp.S11.size(0) * expl_temp.S11.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        b_expl_temp[i4] = expl_temp.S11[i4];
      }
      c_expl_temp.set_size(&qb_emlrtRTEI, sp, expl_temp.S12.size(0),
                           expl_temp.S12.size(1));
      loop_ub = expl_temp.S12.size(0) * expl_temp.S12.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        c_expl_temp[i4] = expl_temp.S12[i4];
      }
      d_expl_temp.set_size(&qb_emlrtRTEI, sp, expl_temp.S21.size(0),
                           expl_temp.S21.size(1));
      loop_ub = expl_temp.S21.size(0) * expl_temp.S21.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        d_expl_temp[i4] = expl_temp.S21[i4];
      }
      e_expl_temp.set_size(&qb_emlrtRTEI, sp, expl_temp.S22.size(0),
                           expl_temp.S22.size(1));
      loop_ub = expl_temp.S22.size(0) * expl_temp.S22.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        e_expl_temp[i4] = expl_temp.S22[i4];
      }
      st.site = &i_emlrtRSI;
      star(st, Omega2, Sref_S12, Sref_S21, Sref_S22, b_expl_temp, c_expl_temp,
           d_expl_temp, e_expl_temp, expl_temp.S11, expl_temp.S12,
           expl_temp.S21, expl_temp.S22);
      b_expl_temp.set_size(&rb_emlrtRTEI, sp, expl_temp.S11.size(0),
                           expl_temp.S11.size(1));
      loop_ub = expl_temp.S11.size(0) * expl_temp.S11.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        b_expl_temp[i4] = expl_temp.S11[i4];
      }
      c_expl_temp.set_size(&rb_emlrtRTEI, sp, expl_temp.S12.size(0),
                           expl_temp.S12.size(1));
      loop_ub = expl_temp.S12.size(0) * expl_temp.S12.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        c_expl_temp[i4] = expl_temp.S12[i4];
      }
      d_expl_temp.set_size(&rb_emlrtRTEI, sp, expl_temp.S21.size(0),
                           expl_temp.S21.size(1));
      loop_ub = expl_temp.S21.size(0) * expl_temp.S21.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        d_expl_temp[i4] = expl_temp.S21[i4];
      }
      e_expl_temp.set_size(&rb_emlrtRTEI, sp, expl_temp.S22.size(0),
                           expl_temp.S22.size(1));
      loop_ub = expl_temp.S22.size(0) * expl_temp.S22.size(1) - 1;
      for (i4 = 0; i4 <= loop_ub; i4++) {
        e_expl_temp[i4] = expl_temp.S22[i4];
      }
      st.site = &j_emlrtRSI;
      star(st, b_expl_temp, c_expl_temp, d_expl_temp, e_expl_temp, Strn_S11,
           Strn_S12, Strn_S21, Strn_S22, expl_temp.S11, expl_temp.S12,
           expl_temp.S21, expl_temp.S22);
      //            %% Calculate Source Mode Coefficients
      st.site = &k_emlrtRSI;
      coder::mldivide(st, Wref, src, csrc);
      //            %% REFLECTED FIELDS
      st.site = &l_emlrtRSI;
      b_st.site = &te_emlrtRSI;
      coder::dynamic_size_checks(b_st, Wref, expl_temp.S11, Wref.size(1),
                                 expl_temp.S11.size(0));
      Omega2.set_size(&sb_emlrtRTEI, &st, Wref.size(0), Wref.size(1));
      loop_ub = Wref.size(0) * Wref.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        Omega2[i4].re = Wref[i4];
        Omega2[i4].im = 0.0;
      }
      Kx.set_size(&tb_emlrtRTEI, &st, Omega2.size(0), expl_temp.S11.size(1));
      loop_ub = Omega2.size(0);
      for (i4 = 0; i4 < loop_ub; i4++) {
        b_loop_ub = expl_temp.S11.size(1);
        for (int32_T i5{0}; i5 < b_loop_ub; i5++) {
          Kx[i4 + Kx.size(0) * i5].re = 0.0;
          Kx[i4 + Kx.size(0) * i5].im = 0.0;
          sub_layer = Omega2.size(1);
          for (int32_T i6{0}; i6 < sub_layer; i6++) {
            varargout_1_tmp = Omega2[i4 + Omega2.size(0) * i6].re;
            re_tmp = expl_temp.S11[i6 + expl_temp.S11.size(0) * i5].im;
            Omega2_re_tmp = Omega2[i4 + Omega2.size(0) * i6].im;
            b_Omega2_re_tmp = expl_temp.S11[i6 + expl_temp.S11.size(0) * i5].re;
            Kx[i4 + Kx.size(0) * i5].re =
                Kx[i4 + Kx.size(0) * i5].re +
                (varargout_1_tmp * b_Omega2_re_tmp - Omega2_re_tmp * re_tmp);
            Kx[i4 + Kx.size(0) * i5].im =
                Kx[i4 + Kx.size(0) * i5].im +
                (varargout_1_tmp * re_tmp + Omega2_re_tmp * b_Omega2_re_tmp);
          }
        }
      }
      st.site = &l_emlrtRSI;
      b_st.site = &te_emlrtRSI;
      coder::dynamic_size_checks(b_st, Kx, csrc, Kx.size(1), csrc.size(0));
      st.site = &m_emlrtRSI;
      b_csrc.set_size(&sb_emlrtRTEI, &st, csrc.size(0));
      loop_ub = csrc.size(0);
      for (i4 = 0; i4 < loop_ub; i4++) {
        b_csrc[i4].re = csrc[i4];
        b_csrc[i4].im = 0.0;
      }
      loop_ub = Kx.size(0);
      b_Kx.set_size(&sb_emlrtRTEI, &st, Kx.size(0));
      for (i4 = 0; i4 < loop_ub; i4++) {
        b_Kx[i4].re = 0.0;
        b_Kx[i4].im = 0.0;
        b_loop_ub = Kx.size(1);
        for (int32_T i5{0}; i5 < b_loop_ub; i5++) {
          varargout_1_tmp = Kx[i4 + Kx.size(0) * i5].re;
          re_tmp = b_csrc[i5].im;
          Omega2_re_tmp = Kx[i4 + Kx.size(0) * i5].im;
          b_Omega2_re_tmp = b_csrc[i5].re;
          b_Kx[i4].re = b_Kx[i4].re + (varargout_1_tmp * b_Omega2_re_tmp -
                                       Omega2_re_tmp * re_tmp);
          b_Kx[i4].im = b_Kx[i4].im + (varargout_1_tmp * re_tmp +
                                       Omega2_re_tmp * b_Omega2_re_tmp);
        }
      }
      b_st.site = &m_emlrtRSI;
      coder::b_abs(b_st, b_Kx, T);
      b_st.site = &og_emlrtRSI;
      loop_ub = T.size(0);
      for (i4 = 0; i4 < loop_ub; i4++) {
        varargout_1_tmp = T[i4];
        T[i4] = varargout_1_tmp * varargout_1_tmp;
      }
      b_dc.re = grid->erR.re * grid->urR.re - grid->erR.im * grid->urR.im;
      b_dc.im = grid->erR.re * grid->urR.im + grid->erR.im * grid->urR.re;
      coder::internal::scalar::c_sqrt(&b_dc);
      kzInc_tmp = muDoubleScalarCos(grid->Theta[j]);
      b_kzInc_tmp = kzInc_tmp * b_dc.re;
      c_kzInc_tmp = kzInc_tmp * b_dc.im;
      st.site = &n_emlrtRSI;
      Wref.set_size(&ub_emlrtRTEI, &st, KzR.size(0), KzR.size(1));
      loop_ub = KzR.size(0) * KzR.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        ar = -KzR[i4].re;
        ai = -KzR[i4].im;
        if (c_kzInc_tmp == 0.0) {
          if (ai == 0.0) {
            varargout_1_tmp = ar / b_kzInc_tmp;
          } else if (ar == 0.0) {
            varargout_1_tmp = 0.0;
          } else {
            varargout_1_tmp = ar / b_kzInc_tmp;
          }
        } else if (b_kzInc_tmp == 0.0) {
          if (ar == 0.0) {
            varargout_1_tmp = ai / c_kzInc_tmp;
          } else if (ai == 0.0) {
            varargout_1_tmp = 0.0;
          } else {
            varargout_1_tmp = ai / c_kzInc_tmp;
          }
        } else {
          brm = muDoubleScalarAbs(b_kzInc_tmp);
          b_Omega2_re_tmp = muDoubleScalarAbs(c_kzInc_tmp);
          if (brm > b_Omega2_re_tmp) {
            b_Omega2_re_tmp = c_kzInc_tmp / b_kzInc_tmp;
            varargout_1_tmp = (ar + b_Omega2_re_tmp * ai) /
                              (b_kzInc_tmp + b_Omega2_re_tmp * c_kzInc_tmp);
          } else if (b_Omega2_re_tmp == brm) {
            if (b_kzInc_tmp > 0.0) {
              re_tmp = 0.5;
            } else {
              re_tmp = -0.5;
            }
            if (c_kzInc_tmp > 0.0) {
              b_Omega2_re_tmp = 0.5;
            } else {
              b_Omega2_re_tmp = -0.5;
            }
            varargout_1_tmp = (ar * re_tmp + ai * b_Omega2_re_tmp) / brm;
          } else {
            b_Omega2_re_tmp = b_kzInc_tmp / c_kzInc_tmp;
            varargout_1_tmp = (b_Omega2_re_tmp * ar + ai) /
                              (c_kzInc_tmp + b_Omega2_re_tmp * b_kzInc_tmp);
          }
        }
        Wref[i4] = varargout_1_tmp;
      }
      b_st.site = &te_emlrtRSI;
      coder::dynamic_size_checks(b_st, Wref, T, Wref.size(1), T.size(0));
      b_st.site = &se_emlrtRSI;
      coder::internal::blas::mtimes(b_st, Wref, T, R);
      i4 = static_cast<int32_T>(
          muDoubleScalarFloor(static_cast<real_T>(R.size(0)) / 2.0));
      if ((i4 < 1) || (i4 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i4, 1, R.size(0), &f_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (b_i + 1 > REF->minus_1.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->minus_1.size(0),
                                      &g_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > REF->minus_1.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->minus_1.size(1),
                                      &h_emlrtBCI, (emlrtConstCTX)sp);
      }
      REF->minus_1[b_i + REF->minus_1.size(0) * j] = R[i4 - 1];
      if (i4 + 2 > R.size(0)) {
        emlrtDynamicBoundsCheckR2012b(i4 + 2, 1, R.size(0), &i_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (b_i + 1 > REF->plus_1.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->plus_1.size(0),
                                      &j_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > REF->plus_1.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->plus_1.size(1),
                                      &k_emlrtBCI, (emlrtConstCTX)sp);
      }
      REF->plus_1[b_i + REF->plus_1.size(0) * j] = R[i4 + 1];
      if (i4 + 1 > R.size(0)) {
        emlrtDynamicBoundsCheckR2012b(i4 + 1, 1, R.size(0), &l_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (b_i + 1 > REF->REF0.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->REF0.size(0),
                                      &m_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > REF->REF0.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->REF0.size(1), &n_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      REF->REF0[b_i + REF->REF0.size(0) * j] = R[i4];
      st.site = &o_emlrtRSI;
      varargout_1_tmp = coder::sum(st, R);
      if (b_i + 1 > REF->sum.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->sum.size(0), &o_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (j + 1 > REF->sum.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->sum.size(1), &p_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      REF->sum[b_i + REF->sum.size(0) * j] =
          muDoubleScalarAbs(coder::sumColumnB(varargout_1_tmp));
      //  all reflection orders
      //            %% TRANSMITTED FIELDS
      st.site = &p_emlrtRSI;
      b_st.site = &te_emlrtRSI;
      coder::dynamic_size_checks(b_st, Wtrn, expl_temp.S21, Wtrn.size(1),
                                 expl_temp.S21.size(0));
      Omega2.set_size(&sb_emlrtRTEI, &st, Wtrn.size(0), Wtrn.size(1));
      loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i4 = 0; i4 < loop_ub; i4++) {
        Omega2[i4].re = Wtrn[i4];
        Omega2[i4].im = 0.0;
      }
      Kx.set_size(&tb_emlrtRTEI, &st, Omega2.size(0), expl_temp.S21.size(1));
      loop_ub = Omega2.size(0);
      for (i4 = 0; i4 < loop_ub; i4++) {
        b_loop_ub = expl_temp.S21.size(1);
        for (int32_T i5{0}; i5 < b_loop_ub; i5++) {
          Kx[i4 + Kx.size(0) * i5].re = 0.0;
          Kx[i4 + Kx.size(0) * i5].im = 0.0;
          sub_layer = Omega2.size(1);
          for (int32_T i6{0}; i6 < sub_layer; i6++) {
            varargout_1_tmp = Omega2[i4 + Omega2.size(0) * i6].re;
            re_tmp = expl_temp.S21[i6 + expl_temp.S21.size(0) * i5].im;
            Omega2_re_tmp = Omega2[i4 + Omega2.size(0) * i6].im;
            b_Omega2_re_tmp = expl_temp.S21[i6 + expl_temp.S21.size(0) * i5].re;
            Kx[i4 + Kx.size(0) * i5].re =
                Kx[i4 + Kx.size(0) * i5].re +
                (varargout_1_tmp * b_Omega2_re_tmp - Omega2_re_tmp * re_tmp);
            Kx[i4 + Kx.size(0) * i5].im =
                Kx[i4 + Kx.size(0) * i5].im +
                (varargout_1_tmp * re_tmp + Omega2_re_tmp * b_Omega2_re_tmp);
          }
        }
      }
      st.site = &p_emlrtRSI;
      b_st.site = &te_emlrtRSI;
      coder::dynamic_size_checks(b_st, Kx, csrc, Kx.size(1), csrc.size(0));
      st.site = &q_emlrtRSI;
      b_csrc.set_size(&sb_emlrtRTEI, &st, csrc.size(0));
      loop_ub = csrc.size(0);
      for (i4 = 0; i4 < loop_ub; i4++) {
        b_csrc[i4].re = csrc[i4];
        b_csrc[i4].im = 0.0;
      }
      loop_ub = Kx.size(0);
      b_Kx.set_size(&sb_emlrtRTEI, &st, Kx.size(0));
      for (i4 = 0; i4 < loop_ub; i4++) {
        b_Kx[i4].re = 0.0;
        b_Kx[i4].im = 0.0;
        b_loop_ub = Kx.size(1);
        for (int32_T i5{0}; i5 < b_loop_ub; i5++) {
          varargout_1_tmp = Kx[i4 + Kx.size(0) * i5].re;
          re_tmp = b_csrc[i5].im;
          Omega2_re_tmp = Kx[i4 + Kx.size(0) * i5].im;
          b_Omega2_re_tmp = b_csrc[i5].re;
          b_Kx[i4].re = b_Kx[i4].re + (varargout_1_tmp * b_Omega2_re_tmp -
                                       Omega2_re_tmp * re_tmp);
          b_Kx[i4].im = b_Kx[i4].im + (varargout_1_tmp * re_tmp +
                                       Omega2_re_tmp * b_Omega2_re_tmp);
        }
      }
      b_st.site = &q_emlrtRSI;
      coder::b_abs(b_st, b_Kx, T);
      b_st.site = &og_emlrtRSI;
      loop_ub = T.size(0);
      for (i4 = 0; i4 < loop_ub; i4++) {
        varargout_1_tmp = T[i4];
        T[i4] = varargout_1_tmp * varargout_1_tmp;
      }
      if (grid->erSub.im == 0.0) {
        z.re = 1.0 / grid->erSub.re;
        z.im = 0.0;
      } else if (grid->erSub.re == 0.0) {
        z.re = 0.0;
        z.im = -(1.0 / grid->erSub.im);
      } else {
        brm = muDoubleScalarAbs(grid->erSub.re);
        b_Omega2_re_tmp = muDoubleScalarAbs(grid->erSub.im);
        if (brm > b_Omega2_re_tmp) {
          b_Omega2_re_tmp = grid->erSub.im / grid->erSub.re;
          varargout_1_tmp = grid->erSub.re + b_Omega2_re_tmp * grid->erSub.im;
          z.re = (b_Omega2_re_tmp * 0.0 + 1.0) / varargout_1_tmp;
          z.im = (0.0 - b_Omega2_re_tmp) / varargout_1_tmp;
        } else if (b_Omega2_re_tmp == brm) {
          if (grid->erSub.re > 0.0) {
            re_tmp = 0.5;
          } else {
            re_tmp = -0.5;
          }
          if (grid->erSub.im > 0.0) {
            varargout_1_tmp = 0.5;
          } else {
            varargout_1_tmp = -0.5;
          }
          z.re = (re_tmp + 0.0 * varargout_1_tmp) / brm;
          z.im = (0.0 * re_tmp - varargout_1_tmp) / brm;
        } else {
          b_Omega2_re_tmp = grid->erSub.re / grid->erSub.im;
          varargout_1_tmp = grid->erSub.im + b_Omega2_re_tmp * grid->erSub.re;
          z.re = b_Omega2_re_tmp / varargout_1_tmp;
          z.im = (b_Omega2_re_tmp * 0.0 - 1.0) / varargout_1_tmp;
        }
      }
      re_tmp = z.re * z.im;
      varargout_1_tmp = muDoubleScalarSin(grid->Theta[j]);
      theta_i.re = varargout_1_tmp * (z.re * z.re - z.im * z.im);
      theta_i.im = varargout_1_tmp * (re_tmp + re_tmp);
      coder::b_asin(theta_i);
      //  from grating equation - zeroth mode
      if (Calc_Fresnel) {
        if (Mode == 'E') {
          if (grid->urT.im == 0.0) {
            if (grid->urR.im == 0.0) {
              z.re = grid->urR.re / grid->urT.re;
              z.im = 0.0;
            } else if (grid->urR.re == 0.0) {
              z.re = 0.0;
              z.im = grid->urR.im / grid->urT.re;
            } else {
              z.re = grid->urR.re / grid->urT.re;
              z.im = grid->urR.im / grid->urT.re;
            }
          } else if (grid->urT.re == 0.0) {
            if (grid->urR.re == 0.0) {
              z.re = grid->urR.im / grid->urT.im;
              z.im = 0.0;
            } else if (grid->urR.im == 0.0) {
              z.re = 0.0;
              z.im = -(grid->urR.re / grid->urT.im);
            } else {
              z.re = grid->urR.im / grid->urT.im;
              z.im = -(grid->urR.re / grid->urT.im);
            }
          } else {
            brm = muDoubleScalarAbs(grid->urT.re);
            b_Omega2_re_tmp = muDoubleScalarAbs(grid->urT.im);
            if (brm > b_Omega2_re_tmp) {
              b_Omega2_re_tmp = grid->urT.im / grid->urT.re;
              varargout_1_tmp = grid->urT.re + b_Omega2_re_tmp * grid->urT.im;
              z.re = (grid->urR.re + b_Omega2_re_tmp * grid->urR.im) /
                     varargout_1_tmp;
              z.im = (grid->urR.im - b_Omega2_re_tmp * grid->urR.re) /
                     varargout_1_tmp;
            } else if (b_Omega2_re_tmp == brm) {
              if (grid->urT.re > 0.0) {
                re_tmp = 0.5;
              } else {
                re_tmp = -0.5;
              }
              if (grid->urT.im > 0.0) {
                varargout_1_tmp = 0.5;
              } else {
                varargout_1_tmp = -0.5;
              }
              z.re = (grid->urR.re * re_tmp + grid->urR.im * varargout_1_tmp) /
                     brm;
              z.im = (grid->urR.im * re_tmp - grid->urR.re * varargout_1_tmp) /
                     brm;
            } else {
              b_Omega2_re_tmp = grid->urT.re / grid->urT.im;
              varargout_1_tmp = grid->urT.im + b_Omega2_re_tmp * grid->urT.re;
              z.re = (b_Omega2_re_tmp * grid->urR.re + grid->urR.im) /
                     varargout_1_tmp;
              z.im = (b_Omega2_re_tmp * grid->urR.im - grid->urR.re) /
                     varargout_1_tmp;
            }
          }
          st.site = &r_emlrtRSI;
          Wref.set_size(&cc_emlrtRTEI, &st, KzT.size(0), KzT.size(1));
          loop_ub = KzT.size(0) * KzT.size(1);
          for (i4 = 0; i4 < loop_ub; i4++) {
            varargout_1_tmp = KzT[i4].im;
            re_tmp = KzT[i4].re;
            Omega2_re_tmp = z.re * re_tmp - z.im * varargout_1_tmp;
            varargout_1_tmp = z.re * varargout_1_tmp + z.im * re_tmp;
            if (c_kzInc_tmp == 0.0) {
              if (varargout_1_tmp == 0.0) {
                Omega2_re_tmp /= b_kzInc_tmp;
              } else if (Omega2_re_tmp == 0.0) {
                Omega2_re_tmp = 0.0;
              } else {
                Omega2_re_tmp /= b_kzInc_tmp;
              }
            } else if (b_kzInc_tmp == 0.0) {
              if (Omega2_re_tmp == 0.0) {
                Omega2_re_tmp = varargout_1_tmp / c_kzInc_tmp;
              } else if (varargout_1_tmp == 0.0) {
                Omega2_re_tmp = 0.0;
              } else {
                Omega2_re_tmp = varargout_1_tmp / c_kzInc_tmp;
              }
            } else {
              brm = muDoubleScalarAbs(b_kzInc_tmp);
              b_Omega2_re_tmp = muDoubleScalarAbs(c_kzInc_tmp);
              if (brm > b_Omega2_re_tmp) {
                b_Omega2_re_tmp = c_kzInc_tmp / b_kzInc_tmp;
                Omega2_re_tmp =
                    (Omega2_re_tmp + b_Omega2_re_tmp * varargout_1_tmp) /
                    (b_kzInc_tmp + b_Omega2_re_tmp * c_kzInc_tmp);
              } else if (b_Omega2_re_tmp == brm) {
                if (b_kzInc_tmp > 0.0) {
                  re_tmp = 0.5;
                } else {
                  re_tmp = -0.5;
                }
                if (c_kzInc_tmp > 0.0) {
                  b_Omega2_re_tmp = 0.5;
                } else {
                  b_Omega2_re_tmp = -0.5;
                }
                Omega2_re_tmp = (Omega2_re_tmp * re_tmp +
                                 varargout_1_tmp * b_Omega2_re_tmp) /
                                brm;
              } else {
                b_Omega2_re_tmp = b_kzInc_tmp / c_kzInc_tmp;
                Omega2_re_tmp =
                    (b_Omega2_re_tmp * Omega2_re_tmp + varargout_1_tmp) /
                    (c_kzInc_tmp + b_Omega2_re_tmp * b_kzInc_tmp);
              }
            }
            Wref[i4] = Omega2_re_tmp;
          }
          b_st.site = &te_emlrtRSI;
          coder::dynamic_size_checks(b_st, Wref, T, Wref.size(1), T.size(0));
          csrc.set_size(&dc_emlrtRTEI, &st, T.size(0));
          loop_ub = T.size(0) - 1;
          for (i4 = 0; i4 <= loop_ub; i4++) {
            csrc[i4] = T[i4];
          }
          b_st.site = &se_emlrtRSI;
          coder::internal::blas::mtimes(b_st, Wref, csrc, T);
          //                    %% Fresnel formula for transmission - s pol
          if (theta_i.im == 0.0) {
            kzInc_tmp = muDoubleScalarCos(theta_i.re);
            varargout_1.re = kzInc_tmp;
            varargout_1.im = 0.0;
            z.re = muDoubleScalarSin(theta_i.re);
            z.im = 0.0;
            brm = 0.0;
            varargout_1_tmp = theta_i.re;
            theta_i.re = muDoubleScalarSin(varargout_1_tmp);
            theta_i.im = 0.0;
          } else if (theta_i.re == 0.0) {
            kzInc_tmp = muDoubleScalarCosh(theta_i.im);
            varargout_1.re = kzInc_tmp;
            varargout_1.im = 0.0;
            z.re = 0.0;
            z.im = muDoubleScalarSinh(theta_i.im);
            brm = 0.0;
            varargout_1_tmp = theta_i.im;
            theta_i.re = 0.0;
            theta_i.im = muDoubleScalarSinh(varargout_1_tmp);
          } else {
            varargout_1_tmp = muDoubleScalarCosh(theta_i.im);
            re_tmp = muDoubleScalarCos(theta_i.re);
            kzInc_tmp = re_tmp * varargout_1_tmp;
            varargout_1.re = kzInc_tmp;
            Omega2_re_tmp = muDoubleScalarSin(theta_i.re);
            b_Omega2_re_tmp = muDoubleScalarSinh(theta_i.im);
            brm = -Omega2_re_tmp * b_Omega2_re_tmp;
            varargout_1.im = brm;
            z.re = Omega2_re_tmp * varargout_1_tmp;
            z.im = re_tmp * b_Omega2_re_tmp;
            varargout_1_tmp = theta_i.re;
            re_tmp = theta_i.im;
            theta_i.re =
                muDoubleScalarSin(varargout_1_tmp) * muDoubleScalarCosh(re_tmp);
            theta_i.im =
                muDoubleScalarCos(varargout_1_tmp) * muDoubleScalarSinh(re_tmp);
          }
          //  s Fresnel coeff for reflection
          b_dc = grid->erSub;
          coder::internal::scalar::c_sqrt(&b_dc);
          Omega2_re_tmp = z.re * z.re - z.im * z.im;
          re_tmp = z.re * z.im;
          varargout_1_tmp = re_tmp + re_tmp;
          b_dc1.re = 1.0 - (grid->erSub.re * Omega2_re_tmp -
                            grid->erSub.im * varargout_1_tmp);
          b_dc1.im = 0.0 - (grid->erSub.re * varargout_1_tmp +
                            grid->erSub.im * Omega2_re_tmp);
          coder::internal::scalar::c_sqrt(&b_dc1);
          z = grid->erSub;
          coder::internal::scalar::c_sqrt(&z);
          re_tmp = theta_i.re * theta_i.re - theta_i.im * theta_i.im;
          varargout_1_tmp = theta_i.re * theta_i.im;
          varargout_1_tmp += varargout_1_tmp;
          kzInc.re = 1.0 - (grid->erSub.re * re_tmp -
                            grid->erSub.im * varargout_1_tmp);
          kzInc.im = 0.0 - (grid->erSub.re * varargout_1_tmp +
                            grid->erSub.im * re_tmp);
          coder::internal::scalar::c_sqrt(&kzInc);
          ar = (b_dc.re * varargout_1.re - b_dc.im * varargout_1.im) - b_dc1.re;
          ai = (b_dc.re * varargout_1.im + b_dc.im * varargout_1.re) - b_dc1.im;
          re_tmp = (z.re * kzInc_tmp - z.im * brm) + kzInc.re;
          varargout_1_tmp = (z.re * brm + z.im * kzInc_tmp) + kzInc.im;
          if (varargout_1_tmp == 0.0) {
            if (ai == 0.0) {
              Omega2_re_tmp = ar / re_tmp;
              varargout_1_tmp = 0.0;
            } else if (ar == 0.0) {
              Omega2_re_tmp = 0.0;
              varargout_1_tmp = ai / re_tmp;
            } else {
              Omega2_re_tmp = ar / re_tmp;
              varargout_1_tmp = ai / re_tmp;
            }
          } else if (re_tmp == 0.0) {
            if (ar == 0.0) {
              Omega2_re_tmp = ai / varargout_1_tmp;
              varargout_1_tmp = 0.0;
            } else if (ai == 0.0) {
              Omega2_re_tmp = 0.0;
              varargout_1_tmp = -(ar / varargout_1_tmp);
            } else {
              Omega2_re_tmp = ai / varargout_1_tmp;
              varargout_1_tmp = -(ar / varargout_1_tmp);
            }
          } else {
            brm = muDoubleScalarAbs(re_tmp);
            b_Omega2_re_tmp = muDoubleScalarAbs(varargout_1_tmp);
            if (brm > b_Omega2_re_tmp) {
              b_Omega2_re_tmp = varargout_1_tmp / re_tmp;
              varargout_1_tmp = re_tmp + b_Omega2_re_tmp * varargout_1_tmp;
              Omega2_re_tmp = (ar + b_Omega2_re_tmp * ai) / varargout_1_tmp;
              varargout_1_tmp = (ai - b_Omega2_re_tmp * ar) / varargout_1_tmp;
            } else if (b_Omega2_re_tmp == brm) {
              if (re_tmp > 0.0) {
                re_tmp = 0.5;
              } else {
                re_tmp = -0.5;
              }
              if (varargout_1_tmp > 0.0) {
                varargout_1_tmp = 0.5;
              } else {
                varargout_1_tmp = -0.5;
              }
              Omega2_re_tmp = (ar * re_tmp + ai * varargout_1_tmp) / brm;
              varargout_1_tmp = (ai * re_tmp - ar * varargout_1_tmp) / brm;
            } else {
              b_Omega2_re_tmp = re_tmp / varargout_1_tmp;
              varargout_1_tmp += b_Omega2_re_tmp * re_tmp;
              Omega2_re_tmp = (b_Omega2_re_tmp * ar + ai) / varargout_1_tmp;
              varargout_1_tmp = (b_Omega2_re_tmp * ai - ar) / varargout_1_tmp;
            }
          }
          st.site = &s_emlrtRSI;
          varargout_1_tmp = muDoubleScalarHypot(Omega2_re_tmp, varargout_1_tmp);
          b_st.site = &og_emlrtRSI;
          varargout_1_tmp = 1.0 - varargout_1_tmp * varargout_1_tmp;
          st.site = &t_emlrtRSI;
          if (varargout_1_tmp < 0.0) {
            emlrtErrorWithMessageIdR2018a(
                &st, &s_emlrtRTEI, "Coder:toolbox:ElFunDomainError",
                "Coder:toolbox:ElFunDomainError", 3, 4, 4, "sqrt");
          }
          varargout_1_tmp = muDoubleScalarSqrt(varargout_1_tmp);
          i4 = static_cast<int32_T>(
                   muDoubleScalarFloor(static_cast<real_T>(T.size(0)) / 2.0)) +
               1;
          if (i4 > T.size(0)) {
            emlrtDynamicBoundsCheckR2012b(i4, 1, T.size(0), &db_emlrtBCI,
                                          (emlrtConstCTX)sp);
          }
          T[i4 - 1] = T[i4 - 1] * varargout_1_tmp;
          //  zeroth diff. order is observed in the air
        } else if (Mode == 'H') {
          varargout_1 = grid->erR;
          coder::internal::scalar::c_sqrt(&varargout_1);
          b_kzInc_tmp = kzInc_tmp * grid->erT.re;
          kzInc_tmp *= grid->erT.im;
          st.site = &u_emlrtRSI;
          Wref.set_size(&ac_emlrtRTEI, &st, KzT.size(0), KzT.size(1));
          loop_ub = KzT.size(0) * KzT.size(1);
          for (i4 = 0; i4 < loop_ub; i4++) {
            varargout_1_tmp = KzT[i4].re;
            re_tmp = KzT[i4].im;
            Omega2_re_tmp =
                varargout_1_tmp * varargout_1.re - re_tmp * varargout_1.im;
            varargout_1_tmp =
                varargout_1_tmp * varargout_1.im + re_tmp * varargout_1.re;
            if (kzInc_tmp == 0.0) {
              if (varargout_1_tmp == 0.0) {
                Omega2_re_tmp /= b_kzInc_tmp;
              } else if (Omega2_re_tmp == 0.0) {
                Omega2_re_tmp = 0.0;
              } else {
                Omega2_re_tmp /= b_kzInc_tmp;
              }
            } else if (b_kzInc_tmp == 0.0) {
              if (Omega2_re_tmp == 0.0) {
                Omega2_re_tmp = varargout_1_tmp / kzInc_tmp;
              } else if (varargout_1_tmp == 0.0) {
                Omega2_re_tmp = 0.0;
              } else {
                Omega2_re_tmp = varargout_1_tmp / kzInc_tmp;
              }
            } else {
              brm = muDoubleScalarAbs(b_kzInc_tmp);
              b_Omega2_re_tmp = muDoubleScalarAbs(kzInc_tmp);
              if (brm > b_Omega2_re_tmp) {
                b_Omega2_re_tmp = kzInc_tmp / b_kzInc_tmp;
                Omega2_re_tmp =
                    (Omega2_re_tmp + b_Omega2_re_tmp * varargout_1_tmp) /
                    (b_kzInc_tmp + b_Omega2_re_tmp * kzInc_tmp);
              } else if (b_Omega2_re_tmp == brm) {
                if (b_kzInc_tmp > 0.0) {
                  re_tmp = 0.5;
                } else {
                  re_tmp = -0.5;
                }
                if (kzInc_tmp > 0.0) {
                  b_Omega2_re_tmp = 0.5;
                } else {
                  b_Omega2_re_tmp = -0.5;
                }
                Omega2_re_tmp = (Omega2_re_tmp * re_tmp +
                                 varargout_1_tmp * b_Omega2_re_tmp) /
                                brm;
              } else {
                b_Omega2_re_tmp = b_kzInc_tmp / kzInc_tmp;
                Omega2_re_tmp =
                    (b_Omega2_re_tmp * Omega2_re_tmp + varargout_1_tmp) /
                    (kzInc_tmp + b_Omega2_re_tmp * b_kzInc_tmp);
              }
            }
            Wref[i4] = Omega2_re_tmp;
          }
          b_st.site = &te_emlrtRSI;
          coder::dynamic_size_checks(b_st, Wref, T, Wref.size(1), T.size(0));
          csrc.set_size(&bc_emlrtRTEI, &st, T.size(0));
          loop_ub = T.size(0) - 1;
          for (i4 = 0; i4 <= loop_ub; i4++) {
            csrc[i4] = T[i4];
          }
          b_st.site = &se_emlrtRSI;
          coder::internal::blas::mtimes(b_st, Wref, csrc, T);
          //                    %% Fresnel formula for transmission - p pol
          varargout_1 = grid->erSub;
          coder::internal::scalar::c_sqrt(&varargout_1);
          if (theta_i.im == 0.0) {
            kzInc.re = muDoubleScalarCos(theta_i.re);
            kzInc.im = 0.0;
            varargout_1_tmp = muDoubleScalarSin(theta_i.re);
            z.re = varargout_1_tmp;
            z.im = 0.0;
            theta_i.re = varargout_1_tmp;
            theta_i.im = 0.0;
          } else if (theta_i.re == 0.0) {
            kzInc.re = muDoubleScalarCosh(theta_i.im);
            kzInc.im = 0.0;
            z.re = 0.0;
            z.im = muDoubleScalarSinh(theta_i.im);
            varargout_1_tmp = theta_i.im;
            theta_i.re = 0.0;
            theta_i.im = muDoubleScalarSinh(varargout_1_tmp);
          } else {
            kzInc.re =
                muDoubleScalarCos(theta_i.re) * muDoubleScalarCosh(theta_i.im);
            kzInc.im =
                -muDoubleScalarSin(theta_i.re) * muDoubleScalarSinh(theta_i.im);
            z.re =
                muDoubleScalarSin(theta_i.re) * muDoubleScalarCosh(theta_i.im);
            z.im =
                muDoubleScalarCos(theta_i.re) * muDoubleScalarSinh(theta_i.im);
            varargout_1_tmp = theta_i.re;
            re_tmp = theta_i.im;
            theta_i.re =
                muDoubleScalarSin(varargout_1_tmp) * muDoubleScalarCosh(re_tmp);
            theta_i.im =
                muDoubleScalarCos(varargout_1_tmp) * muDoubleScalarSinh(re_tmp);
          }
          Omega2_re_tmp = z.re * z.re - z.im * z.im;
          re_tmp = z.re * z.im;
          varargout_1_tmp = re_tmp + re_tmp;
          b_dc.re = 1.0 - (grid->erSub.re * Omega2_re_tmp -
                           grid->erSub.im * varargout_1_tmp);
          b_dc.im = 0.0 - (grid->erSub.re * varargout_1_tmp +
                           grid->erSub.im * Omega2_re_tmp);
          coder::internal::scalar::c_sqrt(&b_dc);
          re_tmp = theta_i.re * theta_i.re - theta_i.im * theta_i.im;
          varargout_1_tmp = theta_i.re * theta_i.im;
          varargout_1_tmp += varargout_1_tmp;
          b_dc1.re = 1.0 - (grid->erSub.re * re_tmp -
                            grid->erSub.im * varargout_1_tmp);
          b_dc1.im = 0.0 - (grid->erSub.re * varargout_1_tmp +
                            grid->erSub.im * re_tmp);
          coder::internal::scalar::c_sqrt(&b_dc1);
          ar = (varargout_1.re * b_dc.re - varargout_1.im * b_dc.im) - kzInc.re;
          ai = (varargout_1.re * b_dc.im + varargout_1.im * b_dc.re) - kzInc.im;
          re_tmp = (varargout_1.re * b_dc1.re - varargout_1.im * b_dc1.im) +
                   kzInc.re;
          varargout_1_tmp =
              (varargout_1.re * b_dc1.im + varargout_1.im * b_dc1.re) +
              kzInc.im;
          if (varargout_1_tmp == 0.0) {
            if (ai == 0.0) {
              Omega2_re_tmp = ar / re_tmp;
              varargout_1_tmp = 0.0;
            } else if (ar == 0.0) {
              Omega2_re_tmp = 0.0;
              varargout_1_tmp = ai / re_tmp;
            } else {
              Omega2_re_tmp = ar / re_tmp;
              varargout_1_tmp = ai / re_tmp;
            }
          } else if (re_tmp == 0.0) {
            if (ar == 0.0) {
              Omega2_re_tmp = ai / varargout_1_tmp;
              varargout_1_tmp = 0.0;
            } else if (ai == 0.0) {
              Omega2_re_tmp = 0.0;
              varargout_1_tmp = -(ar / varargout_1_tmp);
            } else {
              Omega2_re_tmp = ai / varargout_1_tmp;
              varargout_1_tmp = -(ar / varargout_1_tmp);
            }
          } else {
            brm = muDoubleScalarAbs(re_tmp);
            b_Omega2_re_tmp = muDoubleScalarAbs(varargout_1_tmp);
            if (brm > b_Omega2_re_tmp) {
              b_Omega2_re_tmp = varargout_1_tmp / re_tmp;
              varargout_1_tmp = re_tmp + b_Omega2_re_tmp * varargout_1_tmp;
              Omega2_re_tmp = (ar + b_Omega2_re_tmp * ai) / varargout_1_tmp;
              varargout_1_tmp = (ai - b_Omega2_re_tmp * ar) / varargout_1_tmp;
            } else if (b_Omega2_re_tmp == brm) {
              if (re_tmp > 0.0) {
                re_tmp = 0.5;
              } else {
                re_tmp = -0.5;
              }
              if (varargout_1_tmp > 0.0) {
                varargout_1_tmp = 0.5;
              } else {
                varargout_1_tmp = -0.5;
              }
              Omega2_re_tmp = (ar * re_tmp + ai * varargout_1_tmp) / brm;
              varargout_1_tmp = (ai * re_tmp - ar * varargout_1_tmp) / brm;
            } else {
              b_Omega2_re_tmp = re_tmp / varargout_1_tmp;
              varargout_1_tmp += b_Omega2_re_tmp * re_tmp;
              Omega2_re_tmp = (b_Omega2_re_tmp * ar + ai) / varargout_1_tmp;
              varargout_1_tmp = (b_Omega2_re_tmp * ai - ar) / varargout_1_tmp;
            }
          }
          st.site = &v_emlrtRSI;
          varargout_1_tmp = muDoubleScalarHypot(Omega2_re_tmp, varargout_1_tmp);
          b_st.site = &og_emlrtRSI;
          varargout_1_tmp = 1.0 - varargout_1_tmp * varargout_1_tmp;
          st.site = &w_emlrtRSI;
          if (varargout_1_tmp < 0.0) {
            emlrtErrorWithMessageIdR2018a(
                &st, &s_emlrtRTEI, "Coder:toolbox:ElFunDomainError",
                "Coder:toolbox:ElFunDomainError", 3, 4, 4, "sqrt");
          }
          varargout_1_tmp = muDoubleScalarSqrt(varargout_1_tmp);
          i4 = static_cast<int32_T>(
                   muDoubleScalarFloor(static_cast<real_T>(T.size(0)) / 2.0)) +
               1;
          if (i4 > T.size(0)) {
            emlrtDynamicBoundsCheckR2012b(i4, 1, T.size(0), &cb_emlrtBCI,
                                          (emlrtConstCTX)sp);
          }
          T[i4 - 1] = T[i4 - 1] * varargout_1_tmp;
          //  zeroth diff. order is observed in the air
        }
      } else if (Mode == 'E') {
        if (grid->urT.im == 0.0) {
          if (grid->urR.im == 0.0) {
            z.re = grid->urR.re / grid->urT.re;
            z.im = 0.0;
          } else if (grid->urR.re == 0.0) {
            z.re = 0.0;
            z.im = grid->urR.im / grid->urT.re;
          } else {
            z.re = grid->urR.re / grid->urT.re;
            z.im = grid->urR.im / grid->urT.re;
          }
        } else if (grid->urT.re == 0.0) {
          if (grid->urR.re == 0.0) {
            z.re = grid->urR.im / grid->urT.im;
            z.im = 0.0;
          } else if (grid->urR.im == 0.0) {
            z.re = 0.0;
            z.im = -(grid->urR.re / grid->urT.im);
          } else {
            z.re = grid->urR.im / grid->urT.im;
            z.im = -(grid->urR.re / grid->urT.im);
          }
        } else {
          brm = muDoubleScalarAbs(grid->urT.re);
          b_Omega2_re_tmp = muDoubleScalarAbs(grid->urT.im);
          if (brm > b_Omega2_re_tmp) {
            b_Omega2_re_tmp = grid->urT.im / grid->urT.re;
            varargout_1_tmp = grid->urT.re + b_Omega2_re_tmp * grid->urT.im;
            z.re = (grid->urR.re + b_Omega2_re_tmp * grid->urR.im) /
                   varargout_1_tmp;
            z.im = (grid->urR.im - b_Omega2_re_tmp * grid->urR.re) /
                   varargout_1_tmp;
          } else if (b_Omega2_re_tmp == brm) {
            if (grid->urT.re > 0.0) {
              re_tmp = 0.5;
            } else {
              re_tmp = -0.5;
            }
            if (grid->urT.im > 0.0) {
              varargout_1_tmp = 0.5;
            } else {
              varargout_1_tmp = -0.5;
            }
            z.re =
                (grid->urR.re * re_tmp + grid->urR.im * varargout_1_tmp) / brm;
            z.im =
                (grid->urR.im * re_tmp - grid->urR.re * varargout_1_tmp) / brm;
          } else {
            b_Omega2_re_tmp = grid->urT.re / grid->urT.im;
            varargout_1_tmp = grid->urT.im + b_Omega2_re_tmp * grid->urT.re;
            z.re = (b_Omega2_re_tmp * grid->urR.re + grid->urR.im) /
                   varargout_1_tmp;
            z.im = (b_Omega2_re_tmp * grid->urR.im - grid->urR.re) /
                   varargout_1_tmp;
          }
        }
        st.site = &x_emlrtRSI;
        Wref.set_size(&xb_emlrtRTEI, &st, KzT.size(0), KzT.size(1));
        loop_ub = KzT.size(0) * KzT.size(1);
        for (i4 = 0; i4 < loop_ub; i4++) {
          varargout_1_tmp = KzT[i4].im;
          re_tmp = KzT[i4].re;
          Omega2_re_tmp = z.re * re_tmp - z.im * varargout_1_tmp;
          varargout_1_tmp = z.re * varargout_1_tmp + z.im * re_tmp;
          if (c_kzInc_tmp == 0.0) {
            if (varargout_1_tmp == 0.0) {
              Omega2_re_tmp /= b_kzInc_tmp;
            } else if (Omega2_re_tmp == 0.0) {
              Omega2_re_tmp = 0.0;
            } else {
              Omega2_re_tmp /= b_kzInc_tmp;
            }
          } else if (b_kzInc_tmp == 0.0) {
            if (Omega2_re_tmp == 0.0) {
              Omega2_re_tmp = varargout_1_tmp / c_kzInc_tmp;
            } else if (varargout_1_tmp == 0.0) {
              Omega2_re_tmp = 0.0;
            } else {
              Omega2_re_tmp = varargout_1_tmp / c_kzInc_tmp;
            }
          } else {
            brm = muDoubleScalarAbs(b_kzInc_tmp);
            b_Omega2_re_tmp = muDoubleScalarAbs(c_kzInc_tmp);
            if (brm > b_Omega2_re_tmp) {
              b_Omega2_re_tmp = c_kzInc_tmp / b_kzInc_tmp;
              Omega2_re_tmp =
                  (Omega2_re_tmp + b_Omega2_re_tmp * varargout_1_tmp) /
                  (b_kzInc_tmp + b_Omega2_re_tmp * c_kzInc_tmp);
            } else if (b_Omega2_re_tmp == brm) {
              if (b_kzInc_tmp > 0.0) {
                re_tmp = 0.5;
              } else {
                re_tmp = -0.5;
              }
              if (c_kzInc_tmp > 0.0) {
                b_Omega2_re_tmp = 0.5;
              } else {
                b_Omega2_re_tmp = -0.5;
              }
              Omega2_re_tmp =
                  (Omega2_re_tmp * re_tmp + varargout_1_tmp * b_Omega2_re_tmp) /
                  brm;
            } else {
              b_Omega2_re_tmp = b_kzInc_tmp / c_kzInc_tmp;
              Omega2_re_tmp =
                  (b_Omega2_re_tmp * Omega2_re_tmp + varargout_1_tmp) /
                  (c_kzInc_tmp + b_Omega2_re_tmp * b_kzInc_tmp);
            }
          }
          Wref[i4] = Omega2_re_tmp;
        }
        b_st.site = &te_emlrtRSI;
        coder::dynamic_size_checks(b_st, Wref, T, Wref.size(1), T.size(0));
        csrc.set_size(&yb_emlrtRTEI, &st, T.size(0));
        loop_ub = T.size(0) - 1;
        for (i4 = 0; i4 <= loop_ub; i4++) {
          csrc[i4] = T[i4];
        }
        b_st.site = &se_emlrtRSI;
        coder::internal::blas::mtimes(b_st, Wref, csrc, T);
      } else if (Mode == 'H') {
        varargout_1 = grid->erR;
        coder::internal::scalar::c_sqrt(&varargout_1);
        b_kzInc_tmp = kzInc_tmp * grid->erT.re;
        kzInc_tmp *= grid->erT.im;
        st.site = &y_emlrtRSI;
        Wref.set_size(&vb_emlrtRTEI, &st, KzT.size(0), KzT.size(1));
        loop_ub = KzT.size(0) * KzT.size(1);
        for (i4 = 0; i4 < loop_ub; i4++) {
          varargout_1_tmp = KzT[i4].re;
          re_tmp = KzT[i4].im;
          Omega2_re_tmp =
              varargout_1_tmp * varargout_1.re - re_tmp * varargout_1.im;
          varargout_1_tmp =
              varargout_1_tmp * varargout_1.im + re_tmp * varargout_1.re;
          if (kzInc_tmp == 0.0) {
            if (varargout_1_tmp == 0.0) {
              Omega2_re_tmp /= b_kzInc_tmp;
            } else if (Omega2_re_tmp == 0.0) {
              Omega2_re_tmp = 0.0;
            } else {
              Omega2_re_tmp /= b_kzInc_tmp;
            }
          } else if (b_kzInc_tmp == 0.0) {
            if (Omega2_re_tmp == 0.0) {
              Omega2_re_tmp = varargout_1_tmp / kzInc_tmp;
            } else if (varargout_1_tmp == 0.0) {
              Omega2_re_tmp = 0.0;
            } else {
              Omega2_re_tmp = varargout_1_tmp / kzInc_tmp;
            }
          } else {
            brm = muDoubleScalarAbs(b_kzInc_tmp);
            b_Omega2_re_tmp = muDoubleScalarAbs(kzInc_tmp);
            if (brm > b_Omega2_re_tmp) {
              b_Omega2_re_tmp = kzInc_tmp / b_kzInc_tmp;
              Omega2_re_tmp =
                  (Omega2_re_tmp + b_Omega2_re_tmp * varargout_1_tmp) /
                  (b_kzInc_tmp + b_Omega2_re_tmp * kzInc_tmp);
            } else if (b_Omega2_re_tmp == brm) {
              if (b_kzInc_tmp > 0.0) {
                re_tmp = 0.5;
              } else {
                re_tmp = -0.5;
              }
              if (kzInc_tmp > 0.0) {
                b_Omega2_re_tmp = 0.5;
              } else {
                b_Omega2_re_tmp = -0.5;
              }
              Omega2_re_tmp =
                  (Omega2_re_tmp * re_tmp + varargout_1_tmp * b_Omega2_re_tmp) /
                  brm;
            } else {
              b_Omega2_re_tmp = b_kzInc_tmp / kzInc_tmp;
              Omega2_re_tmp =
                  (b_Omega2_re_tmp * Omega2_re_tmp + varargout_1_tmp) /
                  (kzInc_tmp + b_Omega2_re_tmp * b_kzInc_tmp);
            }
          }
          Wref[i4] = Omega2_re_tmp;
        }
        b_st.site = &te_emlrtRSI;
        coder::dynamic_size_checks(b_st, Wref, T, Wref.size(1), T.size(0));
        csrc.set_size(&wb_emlrtRTEI, &st, T.size(0));
        loop_ub = T.size(0) - 1;
        for (i4 = 0; i4 <= loop_ub; i4++) {
          csrc[i4] = T[i4];
        }
        b_st.site = &se_emlrtRSI;
        coder::internal::blas::mtimes(b_st, Wref, csrc, T);
      }
      i4 = static_cast<int32_T>(
          muDoubleScalarFloor(static_cast<real_T>(T.size(0)) / 2.0));
      if ((i4 < 1) || (i4 > T.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i4, 1, T.size(0), &q_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (b_i + 1 > TRN->minus_1.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->minus_1.size(0),
                                      &r_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > TRN->minus_1.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->minus_1.size(1),
                                      &s_emlrtBCI, (emlrtConstCTX)sp);
      }
      TRN->minus_1[b_i + TRN->minus_1.size(0) * j] = T[i4 - 1];
      if (i4 + 2 > T.size(0)) {
        emlrtDynamicBoundsCheckR2012b(i4 + 2, 1, T.size(0), &t_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (b_i + 1 > TRN->plus_1.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->plus_1.size(0),
                                      &u_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > TRN->plus_1.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->plus_1.size(1),
                                      &v_emlrtBCI, (emlrtConstCTX)sp);
      }
      TRN->plus_1[b_i + TRN->plus_1.size(0) * j] = T[i4 + 1];
      if (i4 + 1 > T.size(0)) {
        emlrtDynamicBoundsCheckR2012b(i4 + 1, 1, T.size(0), &w_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      if (b_i + 1 > TRN->TRN0.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->TRN0.size(0),
                                      &x_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > TRN->TRN0.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->TRN0.size(1), &y_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      TRN->TRN0[b_i + TRN->TRN0.size(0) * j] = T[i4];
      st.site = &ab_emlrtRSI;
      varargout_1_tmp = coder::sum(st, T);
      if (b_i + 1 > TRN->sum.size(0)) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->sum.size(0),
                                      &ab_emlrtBCI, (emlrtConstCTX)sp);
      }
      if (j + 1 > TRN->sum.size(1)) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->sum.size(1), &bb_emlrtBCI,
                                      (emlrtConstCTX)sp);
      }
      TRN->sum[b_i + TRN->sum.size(0) * j] =
          muDoubleScalarAbs(coder::sumColumnB(varargout_1_tmp));
      //  all diffraction orders
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b((emlrtConstCTX)sp);
      }
    }
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b((emlrtConstCTX)sp);
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)sp);
}

// End of code generation (Launch_RCWA_S.cpp)
