//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// eig.cpp
//
// Code generation for function 'eig'
//

// Include files
#include "eig.h"
#include "Launch_RCWA_S_data.h"
#include "anyNonFinite.h"
#include "eml_int_forloop_overflow_check.h"
#include "ishermitian.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xsyheev.h"
#include "coder_array.h"
#include "lapacke.h"
#include <cstddef>

// Variable Definitions
static emlrtRSInfo ag_emlrtRSI{
    81,    // lineNo
    "eig", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pathName
};

static emlrtRSInfo bg_emlrtRSI{
    90,    // lineNo
    "eig", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pathName
};

static emlrtRSInfo cg_emlrtRSI{
    125,   // lineNo
    "eig", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pathName
};

static emlrtRSInfo dg_emlrtRSI{
    133,   // lineNo
    "eig", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pathName
};

static emlrtRSInfo eg_emlrtRSI{
    141,   // lineNo
    "eig", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pathName
};

static emlrtRSInfo ig_emlrtRSI{
    27,                     // lineNo
    "eigHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHerm"
    "itianStandard.m" // pathName
};

static emlrtRSInfo jg_emlrtRSI{
    29,                     // lineNo
    "eigHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHerm"
    "itianStandard.m" // pathName
};

static emlrtRSInfo kg_emlrtRSI{
    40,                     // lineNo
    "eigHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHerm"
    "itianStandard.m" // pathName
};

static emlrtRSInfo pg_emlrtRSI{
    20,                         // lineNo
    "eigSkewHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigSkew"
    "HermitianStandard.m" // pathName
};

static emlrtRSInfo qg_emlrtRSI{
    32,                                // lineNo
    "eigComplexSkewHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigComp"
    "lexSkewHermitianStandard.m" // pathName
};

static emlrtRSInfo rg_emlrtRSI{
    40,                                // lineNo
    "eigComplexSkewHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigComp"
    "lexSkewHermitianStandard.m" // pathName
};

static emlrtRSInfo sg_emlrtRSI{
    52,                                // lineNo
    "eigComplexSkewHermitianStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigComp"
    "lexSkewHermitianStandard.m" // pathName
};

static emlrtRSInfo tg_emlrtRSI{
    26,            // lineNo
    "eigStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStan"
    "dard.m" // pathName
};

static emlrtRSInfo ug_emlrtRSI{
    28,            // lineNo
    "eigStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStan"
    "dard.m" // pathName
};

static emlrtRSInfo vg_emlrtRSI{
    45,            // lineNo
    "eigStandard", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStan"
    "dard.m" // pathName
};

static emlrtRSInfo wg_emlrtRSI{
    40,      // lineNo
    "xgeev", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeev.m" // pathName
};

static emlrtRSInfo xg_emlrtRSI{
    198,           // lineNo
    "ceval_xgeev", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeev.m" // pathName
};

static emlrtRTEInfo k_emlrtRTEI{
    50,    // lineNo
    27,    // colNo
    "eig", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pName
};

static emlrtRTEInfo re_emlrtRTEI{
    56,    // lineNo
    24,    // colNo
    "eig", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pName
};

static emlrtRTEInfo se_emlrtRTEI{
    60,    // lineNo
    28,    // colNo
    "eig", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pName
};

static emlrtRTEInfo te_emlrtRTEI{
    40,      // lineNo
    37,      // colNo
    "xgeev", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeev.m" // pName
};

static emlrtRTEInfo ue_emlrtRTEI{
    99,      // lineNo
    24,      // colNo
    "xgeev", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeev.m" // pName
};

static emlrtRTEInfo ve_emlrtRTEI{
    102,     // lineNo
    21,      // colNo
    "xgeev", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeev.m" // pName
};

static emlrtRTEInfo we_emlrtRTEI{
    106,     // lineNo
    29,      // colNo
    "xgeev", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeev.m" // pName
};

static emlrtRTEInfo xe_emlrtRTEI{
    27,            // lineNo
    13,            // colNo
    "eigStandard", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStan"
    "dard.m" // pName
};

static emlrtRTEInfo ye_emlrtRTEI{
    16,                                // lineNo
    1,                                 // colNo
    "eigComplexSkewHermitianStandard", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigComp"
    "lexSkewHermitianStandard.m" // pName
};

static emlrtRTEInfo af_emlrtRTEI{
    32,                                // lineNo
    13,                                // colNo
    "eigComplexSkewHermitianStandard", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigComp"
    "lexSkewHermitianStandard.m" // pName
};

static emlrtRTEInfo bf_emlrtRTEI{
    39,                                // lineNo
    9,                                 // colNo
    "eigComplexSkewHermitianStandard", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigComp"
    "lexSkewHermitianStandard.m" // pName
};

static emlrtRTEInfo cf_emlrtRTEI{
    27,                     // lineNo
    18,                     // colNo
    "eigHermitianStandard", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHerm"
    "itianStandard.m" // pName
};

static emlrtRTEInfo df_emlrtRTEI{
    28,                     // lineNo
    9,                      // colNo
    "eigHermitianStandard", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHerm"
    "itianStandard.m" // pName
};

static emlrtRTEInfo ef_emlrtRTEI{
    85,    // lineNo
    9,     // colNo
    "eig", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pName
};

static emlrtRTEInfo ff_emlrtRTEI{
    89,    // lineNo
    13,    // colNo
    "eig", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m" // pName
};

// Function Definitions
namespace coder {
void eig(const emlrtStack &sp, const array<creal_T, 2U> &A,
         array<creal_T, 2U> &V, array<creal_T, 2U> &D)
{
  static const char_T fname[14]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                '_', 'z', 'g', 'e', 'e', 'v', 'x'};
  ptrdiff_t ihi_t;
  ptrdiff_t ilo_t;
  array<creal_T, 2U> b_A;
  array<creal_T, 1U> W;
  array<real_T, 1U> scale;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack st;
  real_T abnrm;
  real_T rconde;
  real_T rcondv;
  int32_T n;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  n = A.size(0);
  if (A.size(0) != A.size(1)) {
    emlrtErrorWithMessageIdR2018a(&sp, &k_emlrtRTEI,
                                  "MATLAB:eig:inputMustBeSquareStandard",
                                  "MATLAB:eig:inputMustBeSquareStandard", 0);
  }
  V.set_size(&re_emlrtRTEI, &sp, A.size(0), A.size(0));
  D.set_size(&se_emlrtRTEI, &sp, A.size(0), A.size(0));
  if ((A.size(0) != 0) && (A.size(1) != 0)) {
    st.site = &ag_emlrtRSI;
    if (internal::anyNonFinite(st, A)) {
      int32_T j;
      V.set_size(&ef_emlrtRTEI, &sp, A.size(0), A.size(0));
      j = A.size(0) * A.size(0);
      for (int32_T i{0}; i < j; i++) {
        V[i].re = rtNaN;
        V[i].im = 0.0;
      }
      D.set_size(&ff_emlrtRTEI, &sp, A.size(0), A.size(0));
      for (int32_T i{0}; i < j; i++) {
        D[i].re = 0.0;
        D[i].im = 0.0;
      }
      st.site = &bg_emlrtRSI;
      if (A.size(0) > 2147483646) {
        b_st.site = &eb_emlrtRSI;
        check_forloop_overflow_error(b_st);
      }
      for (j = 0; j < n; j++) {
        D[j + D.size(0) * j].re = rtNaN;
        D[j + D.size(0) * j].im = 0.0;
      }
    } else if (ishermitian(A)) {
      int32_T info;
      int32_T j;
      st.site = &cg_emlrtRSI;
      n = A.size(0);
      V.set_size(&cf_emlrtRTEI, &st, A.size(0), A.size(1));
      j = A.size(0) * A.size(1);
      for (int32_T i{0}; i < j; i++) {
        V[i] = A[i];
      }
      b_st.site = &ig_emlrtRSI;
      info = internal::lapack::xsyheev(b_st, V, scale);
      D.set_size(&df_emlrtRTEI, &st, A.size(0), A.size(0));
      j = A.size(0) * A.size(0);
      for (int32_T i{0}; i < j; i++) {
        D[i].re = 0.0;
        D[i].im = 0.0;
      }
      b_st.site = &jg_emlrtRSI;
      if (A.size(0) > 2147483646) {
        c_st.site = &eb_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      for (int32_T i{0}; i < n; i++) {
        D[i + D.size(0) * i].re = scale[i];
        D[i + D.size(0) * i].im = 0.0;
      }
      if (info != 0) {
        b_st.site = &kg_emlrtRSI;
        internal::b_warning(b_st);
      }
    } else {
      int32_T i;
      int32_T j;
      boolean_T p;
      p = (A.size(0) == A.size(1));
      if (p) {
        boolean_T exitg2;
        j = 0;
        exitg2 = false;
        while ((!exitg2) && (j <= A.size(1) - 1)) {
          int32_T exitg1;
          i = 0;
          do {
            exitg1 = 0;
            if (i <= j) {
              if ((!(A[i + A.size(0) * j].re == -A[j + A.size(0) * i].re)) ||
                  (!(A[i + A.size(0) * j].im == A[j + A.size(0) * i].im))) {
                p = false;
                exitg1 = 1;
              } else {
                i++;
              }
            } else {
              j++;
              exitg1 = 2;
            }
          } while (exitg1 == 0);
          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      }
      if (p) {
        int32_T info;
        st.site = &dg_emlrtRSI;
        b_st.site = &pg_emlrtRSI;
        b_A.set_size(&ye_emlrtRTEI, &b_st, A.size(0), A.size(1));
        j = A.size(0) * A.size(1);
        for (i = 0; i < j; i++) {
          abnrm = A[i].im;
          rconde = A[i].re;
          b_A[i].re = 0.0 * rconde - abnrm;
          b_A[i].im = 0.0 * abnrm + rconde;
        }
        n = b_A.size(0);
        V.set_size(&af_emlrtRTEI, &b_st, b_A.size(0), b_A.size(1));
        for (i = 0; i < j; i++) {
          V[i] = b_A[i];
        }
        c_st.site = &qg_emlrtRSI;
        info = internal::lapack::xsyheev(c_st, V, scale);
        D.set_size(&bf_emlrtRTEI, &b_st, b_A.size(0), b_A.size(0));
        j = b_A.size(0) * b_A.size(0);
        for (i = 0; i < j; i++) {
          D[i].re = 0.0;
          D[i].im = 0.0;
        }
        c_st.site = &rg_emlrtRSI;
        if (b_A.size(0) > 2147483646) {
          d_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(d_st);
        }
        for (i = 0; i < n; i++) {
          D[i + D.size(0) * i].re = 0.0;
          D[i + D.size(0) * i].im = -scale[i];
        }
        if (info != 0) {
          c_st.site = &sg_emlrtRSI;
          internal::b_warning(c_st);
        }
      } else {
        ptrdiff_t info_t;
        st.site = &eg_emlrtRSI;
        n = A.size(0);
        b_st.site = &tg_emlrtRSI;
        c_st.site = &wg_emlrtRSI;
        b_A.set_size(&te_emlrtRTEI, &c_st, A.size(0), A.size(1));
        j = A.size(0) * A.size(1);
        for (i = 0; i < j; i++) {
          b_A[i] = A[i];
        }
        creal_T vl;
        scale.set_size(&ue_emlrtRTEI, &c_st, A.size(1));
        W.set_size(&ve_emlrtRTEI, &c_st, A.size(1));
        V.set_size(&we_emlrtRTEI, &c_st, A.size(1), A.size(1));
        info_t = LAPACKE_zgeevx(
            102, 'B', 'N', 'V', 'N', (ptrdiff_t)A.size(1),
            (lapack_complex_double *)&(b_A.data())[0], (ptrdiff_t)A.size(0),
            (lapack_complex_double *)&(W.data())[0],
            (lapack_complex_double *)&vl, (ptrdiff_t)1,
            (lapack_complex_double *)&(V.data())[0], (ptrdiff_t)A.size(1),
            &ilo_t, &ihi_t, &(scale.data())[0], &abnrm, &rconde, &rcondv);
        d_st.site = &xg_emlrtRSI;
        if ((int32_T)info_t < 0) {
          if ((int32_T)info_t == -1010) {
            emlrtErrorWithMessageIdR2018a(&d_st, &e_emlrtRTEI, "MATLAB:nomem",
                                          "MATLAB:nomem", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(
                &d_st, &d_emlrtRTEI, "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, &fname[0], 12,
                (int32_T)info_t);
          }
        }
        D.set_size(&xe_emlrtRTEI, &st, A.size(0), A.size(0));
        j = A.size(0) * A.size(0);
        for (i = 0; i < j; i++) {
          D[i].re = 0.0;
          D[i].im = 0.0;
        }
        b_st.site = &ug_emlrtRSI;
        if (A.size(0) > 2147483646) {
          c_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(c_st);
        }
        for (j = 0; j < n; j++) {
          D[j + D.size(0) * j] = W[j];
        }
        if ((int32_T)info_t != 0) {
          b_st.site = &vg_emlrtRSI;
          internal::b_warning(b_st);
        }
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace coder

// End of code generation (eig.cpp)
