//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// expm.cpp
//
// Code generation for function 'expm'
//

// Include files
#include "expm.h"
#include "Launch_RCWA_S_data.h"
#include "abs.h"
#include "anyNonFinite.h"
#include "eml_int_forloop_overflow_check.h"
#include "eml_mtimes_helper.h"
#include "ishermitian.h"
#include "isschur.h"
#include "log2.h"
#include "lusolve.h"
#include "mpower.h"
#include "mtimes.h"
#include "norm.h"
#include "rt_nonfinite.h"
#include "schur.h"
#include "blas.h"
#include "coder_array.h"
#include "mwmathutil.h"
#include <cmath>
#include <cstddef>
#include <emmintrin.h>

// Variable Definitions
static emlrtRSInfo ng_emlrtRSI{
    44,       // lineNo
    "mpower", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\mpower.m" // pathName
};

static emlrtRSInfo yg_emlrtRSI{
    14,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ah_emlrtRSI{
    16,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo bh_emlrtRSI{
    18,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ch_emlrtRSI{
    22,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo dh_emlrtRSI{
    24,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo eh_emlrtRSI{
    26,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo fh_emlrtRSI{
    30,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo gh_emlrtRSI{
    33,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo hh_emlrtRSI{
    34,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ih_emlrtRSI{
    36,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo jh_emlrtRSI{
    37,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo kh_emlrtRSI{
    38,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo lh_emlrtRSI{
    39,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo mh_emlrtRSI{
    42,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo nh_emlrtRSI{
    46,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo oh_emlrtRSI{
    48,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ph_emlrtRSI{
    52,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo qh_emlrtRSI{
    55,     // lineNo
    "expm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo rh_emlrtRSI{
    14,       // lineNo
    "isdiag", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\isdiag.m" // pathName
};

static emlrtRSInfo sh_emlrtRSI{
    15,       // lineNo
    "isdiag", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\isdiag.m" // pathName
};

static emlrtRSInfo li_emlrtRSI{
    86,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo mi_emlrtRSI{
    87,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ni_emlrtRSI{
    88,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo oi_emlrtRSI{
    89,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo pi_emlrtRSI{
    90,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo qi_emlrtRSI{
    92,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ri_emlrtRSI{
    97,              // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo si_emlrtRSI{
    102,             // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ti_emlrtRSI{
    105,             // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ui_emlrtRSI{
    110,             // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo vi_emlrtRSI{
    115,             // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo wi_emlrtRSI{
    118,             // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo xi_emlrtRSI{
    119,             // lineNo
    "getExpmParams", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo yi_emlrtRSI{
    281,   // lineNo
    "ell", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo aj_emlrtRSI{
    282,   // lineNo
    "ell", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo bj_emlrtRSI{
    283,   // lineNo
    "ell", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ej_emlrtRSI{
    286,      // lineNo
    "normAm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo fj_emlrtRSI{
    127,                             // lineNo
    "matrix_to_small_integer_power", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo gj_emlrtRSI{
    122,                             // lineNo
    "matrix_to_small_integer_power", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo hj_emlrtRSI{
    148,                             // lineNo
    "matrix_to_small_integer_power", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo ij_emlrtRSI{
    223,  // lineNo
    "aa", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo jj_emlrtRSI{
    203,  // lineNo
    "ca", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo kj_emlrtRSI{
    221,  // lineNo
    "aa", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo lj_emlrtRSI{
    207,  // lineNo
    "ca", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo mj_emlrtRSI{
    201,  // lineNo
    "ca", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

static emlrtRSInfo nj_emlrtRSI{
    177,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo oj_emlrtRSI{
    180,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo pj_emlrtRSI{
    185,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo qj_emlrtRSI{
    188,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo rj_emlrtRSI{
    193,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo sj_emlrtRSI{
    196,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo tj_emlrtRSI{
    200,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo uj_emlrtRSI{
    202,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo vj_emlrtRSI{
    205,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo wj_emlrtRSI{
    210,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo xj_emlrtRSI{
    213,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo yj_emlrtRSI{
    214,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ak_emlrtRSI{
    217,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo bk_emlrtRSI{
    225,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRSInfo ck_emlrtRSI{
    226,                 // lineNo
    "padeApproximation", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pathName
};

static emlrtRTEInfo l_emlrtRTEI{
    8,      // lineNo
    23,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo m_emlrtRTEI{
    51,     // lineNo
    13,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo n_emlrtRTEI{
    16,           // lineNo
    1,            // colNo
    "qtriStruct", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\qtriStr"
    "uct.m" // pName
};

static emlrtRTEInfo gf_emlrtRTEI{
    11,     // lineNo
    20,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo hf_emlrtRTEI{
    44,     // lineNo
    37,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo if_emlrtRTEI{
    42,     // lineNo
    8,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo jf_emlrtRTEI{
    52,     // lineNo
    13,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo kf_emlrtRTEI{
    52,     // lineNo
    15,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo lf_emlrtRTEI{
    23,     // lineNo
    9,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo mf_emlrtRTEI{
    178,      // lineNo
    59,       // colNo
    "mtimes", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "blas\\mtimes.m" // pName
};

static emlrtRTEInfo nf_emlrtRTEI{
    30,     // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo pf_emlrtRTEI{
    31,     // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo qf_emlrtRTEI{
    17,     // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo rf_emlrtRTEI{
    15,     // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo eg_emlrtRTEI{
    209,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo fg_emlrtRTEI{
    213,    // lineNo
    16,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo gg_emlrtRTEI{
    214,    // lineNo
    13,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo hg_emlrtRTEI{
    201,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo ig_emlrtRTEI{
    205,    // lineNo
    11,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo jg_emlrtRTEI{
    192,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo kg_emlrtRTEI{
    196,    // lineNo
    11,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo lg_emlrtRTEI{
    197,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo mg_emlrtRTEI{
    184,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo ng_emlrtRTEI{
    188,    // lineNo
    11,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo og_emlrtRTEI{
    189,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo pg_emlrtRTEI{
    176,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo qg_emlrtRTEI{
    180,    // lineNo
    11,     // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

static emlrtRTEInfo rg_emlrtRTEI{
    181,    // lineNo
    5,      // colNo
    "expm", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m" // pName
};

// Function Declarations
namespace coder {
static real_T b_ell(const emlrtStack &sp, const array<creal_T, 2U> &T);

static real_T c_ell(const emlrtStack &sp, const array<creal_T, 2U> &T);

static real_T ell(const emlrtStack &sp, const array<creal_T, 2U> &T);

static int32_T getExpmParams(const emlrtStack &sp, const array<creal_T, 2U> &A,
                             array<creal_T, 2U> &A2, array<creal_T, 2U> &A4,
                             array<creal_T, 2U> &A6, real_T &s);

static void padeApproximation(const emlrtStack &sp, const array<creal_T, 2U> &A,
                              const array<creal_T, 2U> &A2,
                              const array<creal_T, 2U> &A4,
                              const array<creal_T, 2U> &A6, int32_T m,
                              array<creal_T, 2U> &F);

static void recomputeBlockDiag(const array<creal_T, 2U> &A,
                               array<creal_T, 2U> &F,
                               const array<int32_T, 1U> &blockFormat);

} // namespace coder

// Function Definitions
namespace coder {
static real_T b_ell(const emlrtStack &sp, const array<creal_T, 2U> &T)
{
  array<real_T, 2U> b_scaledT;
  array<real_T, 2U> c;
  array<real_T, 2U> cBuffer;
  array<real_T, 2U> scaledT;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack st;
  real_T t;
  real_T varargin_1;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  uint32_T unnamed_idx_0;
  uint32_T unnamed_idx_1;
  boolean_T b;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  st.site = &yi_emlrtRSI;
  b_st.site = &og_emlrtRSI;
  st.site = &yi_emlrtRSI;
  b_abs(st, T, scaledT);
  loop_ub = scaledT.size(0) * scaledT.size(1);
  scalarLB = (loop_ub / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int32_T i{0}; i <= vectorUB; i += 2) {
    __m128d r;
    r = _mm_loadu_pd(&scaledT[i]);
    _mm_storeu_pd(&scaledT[i],
                  _mm_mul_pd(_mm_set1_pd(0.071467735648795785), r));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    scaledT[i] = 0.071467735648795785 * scaledT[i];
  }
  st.site = &aj_emlrtRSI;
  b_st.site = &ej_emlrtRSI;
  b = (scaledT.size(0) == scaledT.size(1));
  if (!b) {
    emlrtErrorWithMessageIdR2018a(&b_st, &j_emlrtRTEI, "MATLAB:square",
                                  "MATLAB:square", 0);
  }
  c_st.site = &vf_emlrtRSI;
  d_st.site = &wf_emlrtRSI;
  e_st.site = &xf_emlrtRSI;
  unnamed_idx_0 = static_cast<uint32_T>(scaledT.size(0));
  unnamed_idx_1 = static_cast<uint32_T>(scaledT.size(1));
  f_st.site = &fj_emlrtRSI;
  g_st.site = &ij_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != scaledT.size(1)) {
    b = ((scaledT.size(0) == 1) && (scaledT.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, scaledT, scaledT, c);
  f_st.site = &gj_emlrtRSI;
  g_st.site = &jj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (static_cast<int32_T>(unnamed_idx_1) != c.size(0)) {
    if (((static_cast<int32_T>(unnamed_idx_0) == 1) &&
         (static_cast<int32_T>(unnamed_idx_1) == 1)) ||
        ((c.size(0) == 1) && (c.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  loop_ub = static_cast<int32_T>(unnamed_idx_0);
  scalarLB = static_cast<int32_T>(unnamed_idx_1);
  b_scaledT = scaledT.reshape(loop_ub, scalarLB);
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, b_scaledT, c, cBuffer);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &kj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (c.size(0) != c.size(1)) {
    b = ((c.size(0) == 1) && (c.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, c, c, scaledT);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &ij_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != scaledT.size(1)) {
    b = ((scaledT.size(0) == 1) && (scaledT.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, scaledT, scaledT, c);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &kj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (c.size(0) != c.size(1)) {
    b = ((c.size(0) == 1) && (c.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, c, c, scaledT);
  f_st.site = &hj_emlrtRSI;
  g_st.site = &lj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != cBuffer.size(1)) {
    if (((cBuffer.size(0) == 1) && (cBuffer.size(1) == 1)) ||
        ((scaledT.size(0) == 1) && (scaledT.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, cBuffer, scaledT, c);
  st.site = &bj_emlrtRSI;
  varargin_1 =
      b_log2(st, 2.0 * (b_norm(c) / b_norm(T)) / 2.2204460492503131E-16) / 18.0;
  t = muDoubleScalarMax(muDoubleScalarCeil(varargin_1), 0.0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
  return t;
}

static real_T c_ell(const emlrtStack &sp, const array<creal_T, 2U> &T)
{
  array<real_T, 2U> aBuffer;
  array<real_T, 2U> b_scaledT;
  array<real_T, 2U> c;
  array<real_T, 2U> cBuffer;
  array<real_T, 2U> scaledT;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack st;
  real_T t;
  real_T varargin_1;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  uint32_T unnamed_idx_0;
  uint32_T unnamed_idx_1;
  boolean_T b;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  st.site = &yi_emlrtRSI;
  b_st.site = &og_emlrtRSI;
  st.site = &yi_emlrtRSI;
  b_abs(st, T, scaledT);
  loop_ub = scaledT.size(0) * scaledT.size(1);
  scalarLB = (loop_ub / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int32_T i{0}; i <= vectorUB; i += 2) {
    __m128d r;
    r = _mm_loadu_pd(&scaledT[i]);
    _mm_storeu_pd(&scaledT[i], _mm_mul_pd(_mm_set1_pd(0.05031554467093536), r));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    scaledT[i] = 0.05031554467093536 * scaledT[i];
  }
  st.site = &aj_emlrtRSI;
  b_st.site = &ej_emlrtRSI;
  b = (scaledT.size(0) == scaledT.size(1));
  if (!b) {
    emlrtErrorWithMessageIdR2018a(&b_st, &j_emlrtRTEI, "MATLAB:square",
                                  "MATLAB:square", 0);
  }
  c_st.site = &vf_emlrtRSI;
  d_st.site = &wf_emlrtRSI;
  e_st.site = &xf_emlrtRSI;
  unnamed_idx_0 = static_cast<uint32_T>(scaledT.size(0));
  unnamed_idx_1 = static_cast<uint32_T>(scaledT.size(1));
  f_st.site = &fj_emlrtRSI;
  g_st.site = &ij_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != scaledT.size(1)) {
    b = ((scaledT.size(0) == 1) && (scaledT.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, scaledT, scaledT, aBuffer);
  f_st.site = &gj_emlrtRSI;
  g_st.site = &mj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (static_cast<int32_T>(unnamed_idx_1) != aBuffer.size(0)) {
    if (((static_cast<int32_T>(unnamed_idx_0) == 1) &&
         (static_cast<int32_T>(unnamed_idx_1) == 1)) ||
        ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  loop_ub = static_cast<int32_T>(unnamed_idx_0);
  scalarLB = static_cast<int32_T>(unnamed_idx_1);
  b_scaledT = scaledT.reshape(loop_ub, scalarLB);
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, b_scaledT, aBuffer, c);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &kj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (aBuffer.size(0) != aBuffer.size(1)) {
    b = ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, aBuffer, aBuffer, scaledT);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &ij_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != scaledT.size(1)) {
    b = ((scaledT.size(0) == 1) && (scaledT.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, scaledT, scaledT, aBuffer);
  f_st.site = &gj_emlrtRSI;
  g_st.site = &jj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (aBuffer.size(0) != c.size(1)) {
    if (((c.size(0) == 1) && (c.size(1) == 1)) ||
        ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, c, aBuffer, cBuffer);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &kj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (aBuffer.size(0) != aBuffer.size(1)) {
    b = ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, aBuffer, aBuffer, scaledT);
  f_st.site = &hj_emlrtRSI;
  g_st.site = &lj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != cBuffer.size(1)) {
    if (((cBuffer.size(0) == 1) && (cBuffer.size(1) == 1)) ||
        ((scaledT.size(0) == 1) && (scaledT.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, cBuffer, scaledT, c);
  st.site = &bj_emlrtRSI;
  varargin_1 =
      b_log2(st, 2.0 * (b_norm(c) / b_norm(T)) / 2.2204460492503131E-16) / 26.0;
  t = muDoubleScalarMax(muDoubleScalarCeil(varargin_1), 0.0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
  return t;
}

static real_T ell(const emlrtStack &sp, const array<creal_T, 2U> &T)
{
  array<real_T, 2U> aBuffer;
  array<real_T, 2U> b_scaledT;
  array<real_T, 2U> c;
  array<real_T, 2U> cBuffer;
  array<real_T, 2U> scaledT;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack st;
  real_T t;
  real_T varargin_1;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  uint32_T unnamed_idx_0;
  uint32_T unnamed_idx_1;
  boolean_T b;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  st.site = &yi_emlrtRSI;
  b_st.site = &og_emlrtRSI;
  st.site = &yi_emlrtRSI;
  b_abs(st, T, scaledT);
  loop_ub = scaledT.size(0) * scaledT.size(1);
  scalarLB = (loop_ub / 2) << 1;
  vectorUB = scalarLB - 2;
  for (int32_T i{0}; i <= vectorUB; i += 2) {
    __m128d r;
    r = _mm_loadu_pd(&scaledT[i]);
    _mm_storeu_pd(&scaledT[i],
                  _mm_mul_pd(_mm_set1_pd(0.090475336558796943), r));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    scaledT[i] = 0.090475336558796943 * scaledT[i];
  }
  st.site = &aj_emlrtRSI;
  b_st.site = &ej_emlrtRSI;
  b = (scaledT.size(0) == scaledT.size(1));
  if (!b) {
    emlrtErrorWithMessageIdR2018a(&b_st, &j_emlrtRTEI, "MATLAB:square",
                                  "MATLAB:square", 0);
  }
  c_st.site = &vf_emlrtRSI;
  d_st.site = &wf_emlrtRSI;
  e_st.site = &xf_emlrtRSI;
  unnamed_idx_0 = static_cast<uint32_T>(scaledT.size(0));
  unnamed_idx_1 = static_cast<uint32_T>(scaledT.size(1));
  f_st.site = &fj_emlrtRSI;
  g_st.site = &ij_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != scaledT.size(1)) {
    b = ((scaledT.size(0) == 1) && (scaledT.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, scaledT, scaledT, aBuffer);
  f_st.site = &gj_emlrtRSI;
  g_st.site = &mj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (static_cast<int32_T>(unnamed_idx_1) != aBuffer.size(0)) {
    if (((static_cast<int32_T>(unnamed_idx_0) == 1) &&
         (static_cast<int32_T>(unnamed_idx_1) == 1)) ||
        ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  loop_ub = static_cast<int32_T>(unnamed_idx_0);
  scalarLB = static_cast<int32_T>(unnamed_idx_1);
  b_scaledT = scaledT.reshape(loop_ub, scalarLB);
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, b_scaledT, aBuffer, c);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &kj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (aBuffer.size(0) != aBuffer.size(1)) {
    b = ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, aBuffer, aBuffer, scaledT);
  f_st.site = &gj_emlrtRSI;
  g_st.site = &jj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != c.size(1)) {
    if (((c.size(0) == 1) && (c.size(1) == 1)) ||
        ((scaledT.size(0) == 1) && (scaledT.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, c, scaledT, cBuffer);
  f_st.site = &fj_emlrtRSI;
  g_st.site = &ij_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (scaledT.size(0) != scaledT.size(1)) {
    b = ((scaledT.size(0) == 1) && (scaledT.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, scaledT, scaledT, aBuffer);
  f_st.site = &hj_emlrtRSI;
  g_st.site = &lj_emlrtRSI;
  h_st.site = &te_emlrtRSI;
  if (aBuffer.size(0) != cBuffer.size(1)) {
    if (((cBuffer.size(0) == 1) && (cBuffer.size(1) == 1)) ||
        ((aBuffer.size(0) == 1) && (aBuffer.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &h_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&h_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  h_st.site = &se_emlrtRSI;
  internal::blas::mtimes(h_st, cBuffer, aBuffer, c);
  st.site = &bj_emlrtRSI;
  varargin_1 =
      b_log2(st, 2.0 * (b_norm(c) / b_norm(T)) / 2.2204460492503131E-16) / 14.0;
  t = muDoubleScalarMax(muDoubleScalarCeil(varargin_1), 0.0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
  return t;
}

static int32_T getExpmParams(const emlrtStack &sp, const array<creal_T, 2U> &A,
                             array<creal_T, 2U> &A2, array<creal_T, 2U> &A4,
                             array<creal_T, 2U> &A6, real_T &s)
{
  __m128d r;
  array<creal_T, 2U> y;
  array<real_T, 2U> aBuffer;
  array<real_T, 2U> b_scaledT;
  array<real_T, 2U> c;
  array<real_T, 2U> cBuffer;
  array<real_T, 2U> scaledT;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  emlrtStack st;
  real_T d6;
  real_T d8;
  real_T eta1;
  int32_T eint;
  int32_T loop_ub;
  int32_T m;
  int32_T scalarLB;
  int32_T vectorUB;
  uint32_T unnamed_idx_0;
  uint32_T unnamed_idx_1;
  boolean_T b;
  boolean_T guard1;
  boolean_T guard2;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  s = 0.0;
  st.site = &li_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  dynamic_size_checks(b_st, A, A, A.size(1), A.size(0));
  b_st.site = &se_emlrtRSI;
  internal::blas::mtimes(b_st, A, A, A2);
  st.site = &mi_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  dynamic_size_checks(b_st, A2, A2, A2.size(1), A2.size(0));
  b_st.site = &se_emlrtRSI;
  internal::blas::mtimes(b_st, A2, A2, A4);
  st.site = &ni_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  dynamic_size_checks(b_st, A4, A2, A4.size(1), A2.size(0));
  b_st.site = &se_emlrtRSI;
  internal::blas::mtimes(b_st, A4, A2, A6);
  st.site = &oi_emlrtRSI;
  b_st.site = &og_emlrtRSI;
  st.site = &pi_emlrtRSI;
  b_st.site = &og_emlrtRSI;
  d6 = muDoubleScalarPower(b_norm(A6), 0.16666666666666666);
  eta1 = muDoubleScalarMax(muDoubleScalarPower(b_norm(A4), 0.25), d6);
  guard1 = false;
  guard2 = false;
  if (eta1 <= 0.01495585217958292) {
    st.site = &qi_emlrtRSI;
    b_st.site = &yi_emlrtRSI;
    c_st.site = &og_emlrtRSI;
    b_st.site = &yi_emlrtRSI;
    b_abs(b_st, A, scaledT);
    loop_ub = scaledT.size(0) * scaledT.size(1);
    scalarLB = (loop_ub / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int32_T i{0}; i <= vectorUB; i += 2) {
      r = _mm_loadu_pd(&scaledT[i]);
      _mm_storeu_pd(&scaledT[i],
                    _mm_mul_pd(_mm_set1_pd(0.19285012468241128), r));
    }
    for (int32_T i{scalarLB}; i < loop_ub; i++) {
      scaledT[i] = 0.19285012468241128 * scaledT[i];
    }
    b_st.site = &aj_emlrtRSI;
    c_st.site = &ej_emlrtRSI;
    b = (scaledT.size(0) == scaledT.size(1));
    if (!b) {
      emlrtErrorWithMessageIdR2018a(&c_st, &j_emlrtRTEI, "MATLAB:square",
                                    "MATLAB:square", 0);
    }
    d_st.site = &vf_emlrtRSI;
    e_st.site = &wf_emlrtRSI;
    f_st.site = &xf_emlrtRSI;
    unnamed_idx_0 = static_cast<uint32_T>(scaledT.size(0));
    unnamed_idx_1 = static_cast<uint32_T>(scaledT.size(1));
    g_st.site = &fj_emlrtRSI;
    h_st.site = &ij_emlrtRSI;
    i_st.site = &te_emlrtRSI;
    dynamic_size_checks(i_st, scaledT, scaledT, scaledT.size(1),
                        scaledT.size(0));
    i_st.site = &se_emlrtRSI;
    internal::blas::mtimes(i_st, scaledT, scaledT, aBuffer);
    g_st.site = &gj_emlrtRSI;
    h_st.site = &jj_emlrtRSI;
    scalarLB = static_cast<int32_T>(unnamed_idx_0);
    loop_ub = static_cast<int32_T>(unnamed_idx_1);
    b_scaledT = scaledT.reshape(scalarLB, loop_ub);
    i_st.site = &te_emlrtRSI;
    dynamic_size_checks(i_st, b_scaledT, aBuffer,
                        static_cast<int32_T>(unnamed_idx_1), aBuffer.size(0));
    b_scaledT = scaledT.reshape(scalarLB, loop_ub);
    i_st.site = &se_emlrtRSI;
    internal::blas::mtimes(i_st, b_scaledT, aBuffer, cBuffer);
    g_st.site = &fj_emlrtRSI;
    h_st.site = &kj_emlrtRSI;
    i_st.site = &te_emlrtRSI;
    dynamic_size_checks(i_st, aBuffer, aBuffer, aBuffer.size(1),
                        aBuffer.size(0));
    i_st.site = &se_emlrtRSI;
    internal::blas::mtimes(i_st, aBuffer, aBuffer, scaledT);
    g_st.site = &hj_emlrtRSI;
    h_st.site = &lj_emlrtRSI;
    i_st.site = &te_emlrtRSI;
    dynamic_size_checks(i_st, cBuffer, scaledT, cBuffer.size(1),
                        scaledT.size(0));
    i_st.site = &se_emlrtRSI;
    internal::blas::mtimes(i_st, cBuffer, scaledT, c);
    b_st.site = &bj_emlrtRSI;
    d8 = b_log2(b_st, 2.0 * (b_norm(c) / b_norm(A)) / 2.2204460492503131E-16) /
         6.0;
    if (muDoubleScalarMax(muDoubleScalarCeil(d8), 0.0) == 0.0) {
      m = 3;
    } else {
      guard2 = true;
    }
  } else {
    guard2 = true;
  }
  if (guard2) {
    if (eta1 <= 0.253939833006323) {
      st.site = &ri_emlrtRSI;
      b_st.site = &yi_emlrtRSI;
      c_st.site = &og_emlrtRSI;
      b_st.site = &yi_emlrtRSI;
      b_abs(b_st, A, scaledT);
      loop_ub = scaledT.size(0) * scaledT.size(1);
      scalarLB = (loop_ub / 2) << 1;
      vectorUB = scalarLB - 2;
      for (int32_T i{0}; i <= vectorUB; i += 2) {
        r = _mm_loadu_pd(&scaledT[i]);
        _mm_storeu_pd(&scaledT[i],
                      _mm_mul_pd(_mm_set1_pd(0.12321872304378752), r));
      }
      for (int32_T i{scalarLB}; i < loop_ub; i++) {
        scaledT[i] = 0.12321872304378752 * scaledT[i];
      }
      b_st.site = &aj_emlrtRSI;
      c_st.site = &ej_emlrtRSI;
      b = (scaledT.size(0) == scaledT.size(1));
      if (!b) {
        emlrtErrorWithMessageIdR2018a(&c_st, &j_emlrtRTEI, "MATLAB:square",
                                      "MATLAB:square", 0);
      }
      d_st.site = &vf_emlrtRSI;
      e_st.site = &wf_emlrtRSI;
      f_st.site = &xf_emlrtRSI;
      unnamed_idx_0 = static_cast<uint32_T>(scaledT.size(0));
      unnamed_idx_1 = static_cast<uint32_T>(scaledT.size(1));
      g_st.site = &fj_emlrtRSI;
      h_st.site = &ij_emlrtRSI;
      i_st.site = &te_emlrtRSI;
      dynamic_size_checks(i_st, scaledT, scaledT, scaledT.size(1),
                          scaledT.size(0));
      i_st.site = &se_emlrtRSI;
      internal::blas::mtimes(i_st, scaledT, scaledT, aBuffer);
      g_st.site = &gj_emlrtRSI;
      h_st.site = &jj_emlrtRSI;
      scalarLB = static_cast<int32_T>(unnamed_idx_0);
      loop_ub = static_cast<int32_T>(unnamed_idx_1);
      b_scaledT = scaledT.reshape(scalarLB, loop_ub);
      i_st.site = &te_emlrtRSI;
      dynamic_size_checks(i_st, b_scaledT, aBuffer,
                          static_cast<int32_T>(unnamed_idx_1), aBuffer.size(0));
      loop_ub = static_cast<int32_T>(unnamed_idx_1);
      b_scaledT = scaledT.reshape(scalarLB, loop_ub);
      i_st.site = &se_emlrtRSI;
      internal::blas::mtimes(i_st, b_scaledT, aBuffer, cBuffer);
      g_st.site = &fj_emlrtRSI;
      h_st.site = &kj_emlrtRSI;
      i_st.site = &te_emlrtRSI;
      dynamic_size_checks(i_st, aBuffer, aBuffer, aBuffer.size(1),
                          aBuffer.size(0));
      i_st.site = &se_emlrtRSI;
      internal::blas::mtimes(i_st, aBuffer, aBuffer, scaledT);
      g_st.site = &fj_emlrtRSI;
      h_st.site = &ij_emlrtRSI;
      i_st.site = &te_emlrtRSI;
      dynamic_size_checks(i_st, scaledT, scaledT, scaledT.size(1),
                          scaledT.size(0));
      i_st.site = &se_emlrtRSI;
      internal::blas::mtimes(i_st, scaledT, scaledT, aBuffer);
      g_st.site = &hj_emlrtRSI;
      h_st.site = &lj_emlrtRSI;
      i_st.site = &te_emlrtRSI;
      dynamic_size_checks(i_st, cBuffer, aBuffer, cBuffer.size(1),
                          aBuffer.size(0));
      i_st.site = &se_emlrtRSI;
      internal::blas::mtimes(i_st, cBuffer, aBuffer, c);
      b_st.site = &bj_emlrtRSI;
      d8 =
          b_log2(b_st, 2.0 * (b_norm(c) / b_norm(A)) / 2.2204460492503131E-16) /
          10.0;
      if (muDoubleScalarMax(muDoubleScalarCeil(d8), 0.0) == 0.0) {
        m = 5;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }
  }
  if (guard1) {
    st.site = &si_emlrtRSI;
    b_st.site = &si_emlrtRSI;
    c_st.site = &ej_emlrtRSI;
    mpower(c_st, A4, y);
    b_st.site = &og_emlrtRSI;
    d8 = muDoubleScalarPower(b_norm(y), 0.125);
    eta1 = muDoubleScalarMax(d6, d8);
    st.site = &ti_emlrtRSI;
    if ((eta1 <= 0.95041789961629319) && (ell(st, A) == 0.0)) {
      m = 7;
    } else {
      st.site = &ui_emlrtRSI;
      if ((eta1 <= 2.097847961257068) && (b_ell(st, A) == 0.0)) {
        m = 9;
      } else {
        st.site = &vi_emlrtRSI;
        b_st.site = &te_emlrtRSI;
        dynamic_size_checks(b_st, A4, A6, A4.size(1), A6.size(0));
        b_st.site = &se_emlrtRSI;
        internal::blas::mtimes(b_st, A4, A6, y);
        st.site = &vi_emlrtRSI;
        b_st.site = &og_emlrtRSI;
        st.site = &wi_emlrtRSI;
        d8 = b_log2(st, muDoubleScalarMin(
                            eta1, muDoubleScalarMax(d8, muDoubleScalarPower(
                                                            b_norm(y), 0.1))) /
                            5.3719203511481517);
        s = muDoubleScalarMax(muDoubleScalarCeil(d8), 0.0);
        st.site = &xi_emlrtRSI;
        b_st.site = &ng_emlrtRSI;
        c_st.site = &og_emlrtRSI;
        eta1 = muDoubleScalarPower(2.0, s);
        y.set_size(&of_emlrtRTEI, &sp, A.size(0), A.size(1));
        loop_ub = A.size(0) * A.size(1);
        for (int32_T i{0}; i < loop_ub; i++) {
          d8 = A[i].re;
          d6 = A[i].im;
          if (d6 == 0.0) {
            y[i].re = d8 / eta1;
            y[i].im = 0.0;
          } else if (d8 == 0.0) {
            y[i].re = 0.0;
            y[i].im = d6 / eta1;
          } else {
            y[i].re = d8 / eta1;
            y[i].im = d6 / eta1;
          }
        }
        st.site = &xi_emlrtRSI;
        s += c_ell(st, y);
        if (muDoubleScalarIsInf(s)) {
          eta1 = b_norm(A) / 5.3719203511481517;
          if ((!muDoubleScalarIsInf(eta1)) && (!muDoubleScalarIsNaN(eta1))) {
            eta1 = std::frexp(eta1, &eint);
          } else {
            eint = 0;
          }
          s = eint;
          if (eta1 == 0.5) {
            s = static_cast<real_T>(eint) - 1.0;
          }
        }
        m = 13;
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
  return m;
}

static void padeApproximation(const emlrtStack &sp, const array<creal_T, 2U> &A,
                              const array<creal_T, 2U> &A2,
                              const array<creal_T, 2U> &A4,
                              const array<creal_T, 2U> &A6, int32_T m,
                              array<creal_T, 2U> &F)
{
  array<creal_T, 2U> U;
  array<creal_T, 2U> V;
  array<creal_T, 2U> b;
  emlrtStack b_st;
  emlrtStack st;
  real_T d;
  int32_T i;
  int32_T k;
  int32_T n;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  n = A.size(0) - 1;
  if (m == 3) {
    int32_T loop_ub_tmp;
    U.set_size(&pg_emlrtRTEI, &sp, A2.size(0), A2.size(1));
    loop_ub_tmp = A2.size(0) * A2.size(1);
    for (i = 0; i < loop_ub_tmp; i++) {
      U[i] = A2[i];
    }
    st.site = &nj_emlrtRSI;
    if (A.size(0) > 2147483646) {
      b_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(b_st);
    }
    for (k = 0; k <= n; k++) {
      U[k + U.size(0) * k].re = U[k + U.size(0) * k].re + 60.0;
    }
    st.site = &oj_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    if (U.size(0) != A.size(1)) {
      if (((A.size(0) == 1) && (A.size(1) == 1)) ||
          ((U.size(0) == 1) && (U.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b.set_size(&qg_emlrtRTEI, &st, U.size(0), U.size(1));
    k = U.size(0) * U.size(1) - 1;
    for (i = 0; i <= k; i++) {
      b[i] = U[i];
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A, b, U);
    V.set_size(&rg_emlrtRTEI, &sp, A2.size(0), A2.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      V[i].re = 12.0 * A2[i].re;
      V[i].im = 12.0 * A2[i].im;
    }
    d = 120.0;
  } else if (m == 5) {
    int32_T loop_ub_tmp;
    U.set_size(&mg_emlrtRTEI, &sp, A4.size(0), A4.size(1));
    loop_ub_tmp = A4.size(0) * A4.size(1);
    for (i = 0; i < loop_ub_tmp; i++) {
      U[i].re = A4[i].re + 420.0 * A2[i].re;
      U[i].im = A4[i].im + 420.0 * A2[i].im;
    }
    st.site = &pj_emlrtRSI;
    if (A.size(0) > 2147483646) {
      b_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(b_st);
    }
    for (k = 0; k <= n; k++) {
      U[k + U.size(0) * k].re = U[k + U.size(0) * k].re + 15120.0;
    }
    st.site = &qj_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    if (U.size(0) != A.size(1)) {
      if (((A.size(0) == 1) && (A.size(1) == 1)) ||
          ((U.size(0) == 1) && (U.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b.set_size(&ng_emlrtRTEI, &st, U.size(0), U.size(1));
    k = U.size(0) * U.size(1) - 1;
    for (i = 0; i <= k; i++) {
      b[i] = U[i];
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A, b, U);
    V.set_size(&og_emlrtRTEI, &sp, A4.size(0), A4.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      V[i].re = 30.0 * A4[i].re + 3360.0 * A2[i].re;
      V[i].im = 30.0 * A4[i].im + 3360.0 * A2[i].im;
    }
    d = 30240.0;
  } else if (m == 7) {
    int32_T loop_ub_tmp;
    U.set_size(&jg_emlrtRTEI, &sp, A6.size(0), A6.size(1));
    loop_ub_tmp = A6.size(0) * A6.size(1);
    for (i = 0; i < loop_ub_tmp; i++) {
      U[i].re = (A6[i].re + 1512.0 * A4[i].re) + 277200.0 * A2[i].re;
      U[i].im = (A6[i].im + 1512.0 * A4[i].im) + 277200.0 * A2[i].im;
    }
    st.site = &rj_emlrtRSI;
    if (A.size(0) > 2147483646) {
      b_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(b_st);
    }
    for (k = 0; k <= n; k++) {
      U[k + U.size(0) * k].re = U[k + U.size(0) * k].re + 8.64864E+6;
    }
    st.site = &sj_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    if (U.size(0) != A.size(1)) {
      if (((A.size(0) == 1) && (A.size(1) == 1)) ||
          ((U.size(0) == 1) && (U.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b.set_size(&kg_emlrtRTEI, &st, U.size(0), U.size(1));
    k = U.size(0) * U.size(1) - 1;
    for (i = 0; i <= k; i++) {
      b[i] = U[i];
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A, b, U);
    V.set_size(&lg_emlrtRTEI, &sp, A6.size(0), A6.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      V[i].re = (56.0 * A6[i].re + 25200.0 * A4[i].re) + 1.99584E+6 * A2[i].re;
      V[i].im = (56.0 * A6[i].im + 25200.0 * A4[i].im) + 1.99584E+6 * A2[i].im;
    }
    d = 1.729728E+7;
  } else if (m == 9) {
    int32_T loop_ub_tmp;
    st.site = &tj_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    if (A2.size(0) != A6.size(1)) {
      if (((A6.size(0) == 1) && (A6.size(1) == 1)) ||
          ((A2.size(0) == 1) && (A2.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A6, A2, V);
    U.set_size(&hg_emlrtRTEI, &sp, V.size(0), V.size(1));
    loop_ub_tmp = V.size(0) * V.size(1);
    for (i = 0; i < loop_ub_tmp; i++) {
      U[i].re = ((V[i].re + 3960.0 * A6[i].re) + 2.16216E+6 * A4[i].re) +
                3.027024E+8 * A2[i].re;
      U[i].im = ((V[i].im + 3960.0 * A6[i].im) + 2.16216E+6 * A4[i].im) +
                3.027024E+8 * A2[i].im;
    }
    st.site = &uj_emlrtRSI;
    if (A.size(0) > 2147483646) {
      b_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(b_st);
    }
    for (k = 0; k <= n; k++) {
      U[k + U.size(0) * k].re = U[k + U.size(0) * k].re + 8.8216128E+9;
    }
    st.site = &vj_emlrtRSI;
    b_st.site = &te_emlrtRSI;
    if (U.size(0) != A.size(1)) {
      if (((A.size(0) == 1) && (A.size(1) == 1)) ||
          ((U.size(0) == 1) && (U.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b.set_size(&ig_emlrtRTEI, &st, U.size(0), U.size(1));
    k = U.size(0) * U.size(1) - 1;
    for (i = 0; i <= k; i++) {
      b[i] = U[i];
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A, b, U);
    for (i = 0; i < loop_ub_tmp; i++) {
      V[i].re =
          ((90.0 * V[i].re + 110880.0 * A6[i].re) + 3.027024E+7 * A4[i].re) +
          2.0756736E+9 * A2[i].re;
      V[i].im =
          ((90.0 * V[i].im + 110880.0 * A6[i].im) + 3.027024E+7 * A4[i].im) +
          2.0756736E+9 * A2[i].im;
    }
    d = 1.76432256E+10;
  } else {
    int32_T loop_ub_tmp;
    boolean_T b_b;
    U.set_size(&eg_emlrtRTEI, &sp, A6.size(0), A6.size(1));
    loop_ub_tmp = A6.size(0) * A6.size(1);
    for (i = 0; i < loop_ub_tmp; i++) {
      U[i].re = (3.352212864E+10 * A6[i].re + 1.05594705216E+13 * A4[i].re) +
                1.1873537964288E+15 * A2[i].re;
      U[i].im = (3.352212864E+10 * A6[i].im + 1.05594705216E+13 * A4[i].im) +
                1.1873537964288E+15 * A2[i].im;
    }
    st.site = &wj_emlrtRSI;
    if (A.size(0) > 2147483646) {
      b_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(b_st);
    }
    for (k = 0; k <= n; k++) {
      U[k + U.size(0) * k].re = U[k + U.size(0) * k].re + 3.238237626624E+16;
    }
    st.site = &xj_emlrtRSI;
    b.set_size(&fg_emlrtRTEI, &st, A6.size(0), A6.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      b[i].re = (A6[i].re + 16380.0 * A4[i].re) + 4.08408E+7 * A2[i].re;
      b[i].im = (A6[i].im + 16380.0 * A4[i].im) + 4.08408E+7 * A2[i].im;
    }
    b_st.site = &te_emlrtRSI;
    if (b.size(0) != A6.size(1)) {
      b_b = ((A6.size(0) == 1) && (A6.size(1) == 1));
      if (b_b) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A6, b, V);
    st.site = &xj_emlrtRSI;
    k = V.size(0) * V.size(1);
    for (i = 0; i < k; i++) {
      V[i].re = V[i].re + U[i].re;
      V[i].im = V[i].im + U[i].im;
    }
    b_st.site = &te_emlrtRSI;
    if (V.size(0) != A.size(1)) {
      if (((A.size(0) == 1) && (A.size(1) == 1)) ||
          ((V.size(0) == 1) && (V.size(1) == 1))) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A, V, U);
    st.site = &yj_emlrtRSI;
    b.set_size(&gg_emlrtRTEI, &st, A6.size(0), A6.size(1));
    for (i = 0; i < loop_ub_tmp; i++) {
      b[i].re =
          (182.0 * A6[i].re + 960960.0 * A4[i].re) + 1.32324192E+9 * A2[i].re;
      b[i].im =
          (182.0 * A6[i].im + 960960.0 * A4[i].im) + 1.32324192E+9 * A2[i].im;
    }
    b_st.site = &te_emlrtRSI;
    if (b.size(0) != A6.size(1)) {
      b_b = ((A6.size(0) == 1) && (A6.size(1) == 1));
      if (b_b) {
        emlrtErrorWithMessageIdR2018a(
            &b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                      "MATLAB:innerdim", 0);
      }
    }
    b_st.site = &se_emlrtRSI;
    internal::blas::mtimes(b_st, A6, b, V);
    k = V.size(0) * V.size(1);
    for (i = 0; i < k; i++) {
      V[i].re = ((V[i].re + 6.704425728E+11 * A6[i].re) +
                 1.29060195264E+14 * A4[i].re) +
                7.7717703038976E+15 * A2[i].re;
      V[i].im = ((V[i].im + 6.704425728E+11 * A6[i].im) +
                 1.29060195264E+14 * A4[i].im) +
                7.7717703038976E+15 * A2[i].im;
    }
    d = 6.476475253248E+16;
  }
  st.site = &ak_emlrtRSI;
  for (k = 0; k <= n; k++) {
    V[k + V.size(0) * k].re = V[k + V.size(0) * k].re + d;
  }
  i = U.size(0) * U.size(1);
  for (k = 0; k < i; k++) {
    d = U[k].re;
    V[k].re = V[k].re - d;
    V[k].im = V[k].im - U[k].im;
    U[k].re = 2.0 * d;
    U[k].im = 2.0 * U[k].im;
  }
  st.site = &bk_emlrtRSI;
  internal::lusolve(st, V, U, F);
  st.site = &ck_emlrtRSI;
  for (k = 0; k <= n; k++) {
    F[k + F.size(0) * k].re = F[k + F.size(0) * k].re + 1.0;
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void recomputeBlockDiag(const array<creal_T, 2U> &A,
                               array<creal_T, 2U> &F,
                               const array<int32_T, 1U> &blockFormat)
{
  real_T expa11_re_tmp;
  real_T r;
  int32_T i;
  i = A.size(0);
  for (int32_T j{0}; j <= i - 2; j++) {
    if (blockFormat[j] == 1) {
      real_T ai_tmp;
      real_T ar_tmp;
      real_T avg_im;
      real_T avg_re;
      real_T b_ar_tmp;
      real_T expa11_im;
      real_T expa11_re;
      real_T expa22_im;
      real_T expa22_re;
      real_T x12_im;
      real_T x12_re;
      boolean_T p;
      if (A[j + A.size(0) * j].re == 0.0) {
        expa11_re_tmp = A[j + A.size(0) * j].im;
        expa11_re = muDoubleScalarCos(expa11_re_tmp);
        expa11_im = muDoubleScalarSin(expa11_re_tmp);
      } else if (A[j + A.size(0) * j].im == 0.0) {
        expa11_re = muDoubleScalarExp(A[j + A.size(0) * j].re);
        expa11_im = 0.0;
      } else if (muDoubleScalarIsInf(A[j + A.size(0) * j].im) &&
                 muDoubleScalarIsInf(A[j + A.size(0) * j].re) &&
                 (A[j + A.size(0) * j].re < 0.0)) {
        expa11_re = 0.0;
        expa11_im = 0.0;
      } else {
        r = muDoubleScalarExp(A[j + A.size(0) * j].re / 2.0);
        expa11_re_tmp = A[j + A.size(0) * j].im;
        expa11_re = r * (r * muDoubleScalarCos(expa11_re_tmp));
        expa11_im = r * (r * muDoubleScalarSin(expa11_re_tmp));
      }
      if (A[(j + A.size(0) * (j + 1)) + 1].re == 0.0) {
        expa11_re_tmp = A[(j + A.size(0) * (j + 1)) + 1].im;
        expa22_re = muDoubleScalarCos(expa11_re_tmp);
        expa22_im = muDoubleScalarSin(expa11_re_tmp);
      } else if (A[(j + A.size(0) * (j + 1)) + 1].im == 0.0) {
        expa22_re = muDoubleScalarExp(A[(j + A.size(0) * (j + 1)) + 1].re);
        expa22_im = 0.0;
      } else if (muDoubleScalarIsInf(A[(j + A.size(0) * (j + 1)) + 1].im) &&
                 muDoubleScalarIsInf(A[(j + A.size(0) * (j + 1)) + 1].re) &&
                 (A[(j + A.size(0) * (j + 1)) + 1].re < 0.0)) {
        expa22_re = 0.0;
        expa22_im = 0.0;
      } else {
        r = muDoubleScalarExp(A[(j + A.size(0) * (j + 1)) + 1].re / 2.0);
        expa11_re_tmp = A[(j + A.size(0) * (j + 1)) + 1].im;
        expa22_re = r * (r * muDoubleScalarCos(expa11_re_tmp));
        expa22_im = r * (r * muDoubleScalarSin(expa11_re_tmp));
      }
      ar_tmp = A[j + A.size(0) * j].re;
      b_ar_tmp = A[(j + A.size(0) * (j + 1)) + 1].re;
      expa11_re_tmp = ar_tmp + b_ar_tmp;
      x12_im = A[j + A.size(0) * j].im;
      ai_tmp = A[(j + A.size(0) * (j + 1)) + 1].im;
      r = x12_im + ai_tmp;
      if (r == 0.0) {
        avg_re = expa11_re_tmp / 2.0;
        avg_im = 0.0;
      } else if (expa11_re_tmp == 0.0) {
        avg_re = 0.0;
        avg_im = r / 2.0;
      } else {
        avg_re = expa11_re_tmp / 2.0;
        avg_im = r / 2.0;
      }
      x12_re = muDoubleScalarHypot(ar_tmp - b_ar_tmp, x12_im - ai_tmp) / 2.0;
      if (muDoubleScalarIsNaN(x12_re)) {
        p = false;
      } else if (muDoubleScalarIsNaN(avg_re) || muDoubleScalarIsNaN(avg_im)) {
        p = true;
      } else {
        if ((muDoubleScalarAbs(avg_re) > 8.9884656743115785E+307) ||
            (muDoubleScalarAbs(avg_im) > 8.9884656743115785E+307)) {
          expa11_re_tmp = muDoubleScalarHypot(avg_re / 2.0, avg_im / 2.0);
          r = x12_re / 2.0;
        } else {
          expa11_re_tmp = muDoubleScalarHypot(avg_re, avg_im);
          r = x12_re;
        }
        if (expa11_re_tmp == r) {
          expa11_re_tmp = muDoubleScalarAtan2(avg_im, avg_re);
          r = muDoubleScalarAtan2(0.0, x12_re);
          if (expa11_re_tmp == r) {
            if (avg_re != x12_re) {
              if (expa11_re_tmp >= 0.0) {
                expa11_re_tmp = x12_re;
                r = avg_re;
              } else {
                expa11_re_tmp = avg_re;
                r = x12_re;
              }
            } else {
              expa11_re_tmp = avg_im;
              r = 0.0;
            }
            if (expa11_re_tmp == r) {
              expa11_re_tmp = 0.0;
              r = 0.0;
            }
          }
        }
        p = (expa11_re_tmp < r);
      }
      if (!p) {
        x12_re = avg_re;
      }
      if (x12_re < 709.782712893384) {
        real_T A_im;
        real_T A_re;
        real_T A_re_tmp;
        expa11_re_tmp = b_ar_tmp - ar_tmp;
        r = ai_tmp - x12_im;
        if (r == 0.0) {
          expa11_re_tmp /= 2.0;
          A_im = 0.0;
        } else if (expa11_re_tmp == 0.0) {
          expa11_re_tmp = 0.0;
          A_im = r / 2.0;
        } else {
          expa11_re_tmp /= 2.0;
          A_im = r / 2.0;
        }
        if (avg_re == 0.0) {
          avg_re = muDoubleScalarCos(avg_im);
          avg_im = muDoubleScalarSin(avg_im);
        } else if (avg_im == 0.0) {
          avg_re = muDoubleScalarExp(avg_re);
          avg_im = 0.0;
        } else if (muDoubleScalarIsInf(avg_im) && muDoubleScalarIsInf(avg_re) &&
                   (avg_re < 0.0)) {
          avg_re = 0.0;
          avg_im = 0.0;
        } else {
          r = muDoubleScalarExp(avg_re / 2.0);
          avg_re = r * (r * muDoubleScalarCos(avg_im));
          avg_im = r * (r * muDoubleScalarSin(avg_im));
        }
        if ((expa11_re_tmp == 0.0) && (A_im == 0.0)) {
          x12_re = 1.0;
          x12_im = 0.0;
        } else {
          if (A_im == 0.0) {
            ar_tmp = muDoubleScalarSinh(expa11_re_tmp) / expa11_re_tmp;
            x12_im = 0.0;
          } else {
            x12_re =
                muDoubleScalarSinh(expa11_re_tmp) * muDoubleScalarCos(A_im);
            x12_im =
                muDoubleScalarCosh(expa11_re_tmp) * muDoubleScalarSin(A_im);
            if (expa11_re_tmp == 0.0) {
              if (x12_re == 0.0) {
                ar_tmp = x12_im / A_im;
                x12_im = 0.0;
              } else if (x12_im == 0.0) {
                ar_tmp = 0.0;
                x12_im = -(x12_re / A_im);
              } else {
                ar_tmp = x12_im / A_im;
                x12_im = -(x12_re / A_im);
              }
            } else {
              b_ar_tmp = muDoubleScalarAbs(expa11_re_tmp);
              A_re_tmp = muDoubleScalarAbs(A_im);
              if (b_ar_tmp > A_re_tmp) {
                A_re_tmp = A_im / expa11_re_tmp;
                expa11_re_tmp += A_re_tmp * A_im;
                ar_tmp = (x12_re + A_re_tmp * x12_im) / expa11_re_tmp;
                x12_im = (x12_im - A_re_tmp * x12_re) / expa11_re_tmp;
              } else if (A_re_tmp == b_ar_tmp) {
                if (expa11_re_tmp > 0.0) {
                  r = 0.5;
                } else {
                  r = -0.5;
                }
                if (A_im > 0.0) {
                  expa11_re_tmp = 0.5;
                } else {
                  expa11_re_tmp = -0.5;
                }
                ar_tmp = (x12_re * r + x12_im * expa11_re_tmp) / b_ar_tmp;
                x12_im = (x12_im * r - x12_re * expa11_re_tmp) / b_ar_tmp;
              } else {
                A_re_tmp = expa11_re_tmp / A_im;
                expa11_re_tmp = A_im + A_re_tmp * expa11_re_tmp;
                ar_tmp = (A_re_tmp * x12_re + x12_im) / expa11_re_tmp;
                x12_im = (A_re_tmp * x12_im - x12_re) / expa11_re_tmp;
              }
            }
          }
          x12_re = ar_tmp;
        }
        A_re_tmp = A[j + A.size(0) * (j + 1)].re;
        A_im = A[j + A.size(0) * (j + 1)].im;
        A_re = A_re_tmp * avg_re - A_im * avg_im;
        A_im = A_re_tmp * avg_im + A_im * avg_re;
        ar_tmp = A_re * x12_re - A_im * x12_im;
        x12_im = A_re * x12_im + A_im * x12_re;
        x12_re = ar_tmp;
      } else {
        real_T A_im;
        real_T A_re;
        real_T A_re_tmp;
        expa11_re_tmp = expa22_re - expa11_re;
        r = expa22_im - expa11_im;
        A_re_tmp = A[j + A.size(0) * (j + 1)].re;
        A_im = A[j + A.size(0) * (j + 1)].im;
        A_re = A_re_tmp * expa11_re_tmp - A_im * r;
        A_im = A_re_tmp * r + A_im * expa11_re_tmp;
        r = b_ar_tmp - ar_tmp;
        expa11_re_tmp = ai_tmp - x12_im;
        if (expa11_re_tmp == 0.0) {
          if (A_im == 0.0) {
            x12_re = A_re / r;
            x12_im = 0.0;
          } else if (A_re == 0.0) {
            x12_re = 0.0;
            x12_im = A_im / r;
          } else {
            x12_re = A_re / r;
            x12_im = A_im / r;
          }
        } else if (r == 0.0) {
          if (A_re == 0.0) {
            x12_re = A_im / expa11_re_tmp;
            x12_im = 0.0;
          } else if (A_im == 0.0) {
            x12_re = 0.0;
            x12_im = -(A_re / expa11_re_tmp);
          } else {
            x12_re = A_im / expa11_re_tmp;
            x12_im = -(A_re / expa11_re_tmp);
          }
        } else {
          b_ar_tmp = muDoubleScalarAbs(r);
          A_re_tmp = muDoubleScalarAbs(expa11_re_tmp);
          if (b_ar_tmp > A_re_tmp) {
            A_re_tmp = expa11_re_tmp / r;
            expa11_re_tmp = r + A_re_tmp * expa11_re_tmp;
            x12_re = (A_re + A_re_tmp * A_im) / expa11_re_tmp;
            x12_im = (A_im - A_re_tmp * A_re) / expa11_re_tmp;
          } else if (A_re_tmp == b_ar_tmp) {
            if (r > 0.0) {
              r = 0.5;
            } else {
              r = -0.5;
            }
            if (expa11_re_tmp > 0.0) {
              expa11_re_tmp = 0.5;
            } else {
              expa11_re_tmp = -0.5;
            }
            x12_re = (A_re * r + A_im * expa11_re_tmp) / b_ar_tmp;
            x12_im = (A_im * r - A_re * expa11_re_tmp) / b_ar_tmp;
          } else {
            A_re_tmp = r / expa11_re_tmp;
            expa11_re_tmp += A_re_tmp * r;
            x12_re = (A_re_tmp * A_re + A_im) / expa11_re_tmp;
            x12_im = (A_re_tmp * A_im - A_re) / expa11_re_tmp;
          }
        }
      }
      F[j + F.size(0) * j].re = expa11_re;
      F[j + F.size(0) * j].im = expa11_im;
      F[j + F.size(0) * (j + 1)].re = x12_re;
      F[j + F.size(0) * (j + 1)].im = x12_im;
      F[(j + F.size(0) * (j + 1)) + 1].re = expa22_re;
      F[(j + F.size(0) * (j + 1)) + 1].im = expa22_im;
    }
  }
  if (blockFormat[blockFormat.size(0) - 1] == 0) {
    if (A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].re == 0.0) {
      expa11_re_tmp = A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].im;
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].re =
          muDoubleScalarCos(expa11_re_tmp);
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].im =
          muDoubleScalarSin(expa11_re_tmp);
    } else if (A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].im == 0.0) {
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].re = muDoubleScalarExp(
          A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].re);
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].im = 0.0;
    } else if (muDoubleScalarIsInf(
                   A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].im) &&
               muDoubleScalarIsInf(
                   A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].re) &&
               (A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].re < 0.0)) {
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].re = 0.0;
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].im = 0.0;
    } else {
      r = muDoubleScalarExp(
          A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].re / 2.0);
      expa11_re_tmp = A[(A.size(0) + A.size(0) * (A.size(0) - 1)) - 1].im;
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].re =
          r * (r * muDoubleScalarCos(expa11_re_tmp));
      F[(A.size(0) + F.size(0) * (A.size(0) - 1)) - 1].im =
          r * (r * muDoubleScalarSin(expa11_re_tmp));
    }
  }
}

void expm(const emlrtStack &sp, array<creal_T, 2U> &A, array<creal_T, 2U> &F)
{
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  array<creal_T, 2U> A2;
  array<creal_T, 2U> A4;
  array<creal_T, 2U> A6;
  array<int32_T, 1U> blockFormat;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack st;
  real_T exptj_re;
  int32_T n;
  char_T TRANSA1;
  char_T TRANSB1;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (A.size(0) != A.size(1)) {
    emlrtErrorWithMessageIdR2018a(&sp, &l_emlrtRTEI, "MATLAB:square",
                                  "MATLAB:square", 0);
  }
  n = A.size(0) - 1;
  F.set_size(&gf_emlrtRTEI, &sp, A.size(0), A.size(0));
  if ((A.size(0) != 0) && (A.size(1) != 0)) {
    st.site = &yg_emlrtRSI;
    if (internal::anyNonFinite(st, A)) {
      int32_T i;
      F.set_size(&rf_emlrtRTEI, &sp, A.size(0), A.size(0));
      i = A.size(0) * A.size(0);
      for (int32_T b_i{0}; b_i < i; b_i++) {
        F[b_i].re = rtNaN;
        F[b_i].im = 0.0;
      }
    } else {
      int32_T i;
      int32_T j;
      boolean_T exitg2;
      boolean_T recomputeDiags;
      st.site = &ah_emlrtRSI;
      recomputeDiags = true;
      b_st.site = &rh_emlrtRSI;
      if (A.size(1) > 2147483646) {
        c_st.site = &eb_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      j = 0;
      exitg2 = false;
      while ((!exitg2) && (j <= A.size(1) - 1)) {
        int32_T exitg1;
        b_st.site = &sh_emlrtRSI;
        if (A.size(0) > 2147483646) {
          c_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(c_st);
        }
        i = 0;
        do {
          exitg1 = 0;
          if (i <= A.size(0) - 1) {
            if ((i != j) && ((!(A[i + A.size(0) * j].re == 0.0)) ||
                             (!(A[i + A.size(0) * j].im == 0.0)))) {
              recomputeDiags = false;
              exitg1 = 1;
            } else {
              i++;
            }
          } else {
            j++;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
      if (recomputeDiags) {
        F.set_size(&qf_emlrtRTEI, &sp, A.size(0), A.size(0));
        i = A.size(0) * A.size(0);
        for (int32_T b_i{0}; b_i < i; b_i++) {
          F[b_i] = dc1;
        }
        st.site = &bh_emlrtRSI;
        if (A.size(0) > 2147483646) {
          b_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(b_st);
        }
        for (i = 0; i <= n; i++) {
          if (A[i + A.size(0) * i].re == 0.0) {
            real_T y;
            y = A[i + A.size(0) * i].im;
            F[i + F.size(0) * i].re = muDoubleScalarCos(y);
            F[i + F.size(0) * i].im = muDoubleScalarSin(y);
          } else if (A[i + A.size(0) * i].im == 0.0) {
            F[i + F.size(0) * i].re =
                muDoubleScalarExp(A[i + A.size(0) * i].re);
            F[i + F.size(0) * i].im = 0.0;
          } else if (muDoubleScalarIsInf(A[i + A.size(0) * i].im) &&
                     muDoubleScalarIsInf(A[i + A.size(0) * i].re) &&
                     (A[i + A.size(0) * i].re < 0.0)) {
            F[i + F.size(0) * i] = dc1;
          } else {
            real_T r;
            real_T y;
            r = muDoubleScalarExp(A[i + A.size(0) * i].re / 2.0);
            y = A[i + A.size(0) * i].im;
            F[i + F.size(0) * i].re = r * (r * muDoubleScalarCos(y));
            F[i + F.size(0) * i].im = r * (r * muDoubleScalarSin(y));
          }
        }
      } else if (ishermitian(A)) {
        real_T exptj_im;
        real_T r;
        st.site = &ch_emlrtRSI;
        schur(st, A, A4, A2);
        F.set_size(&lf_emlrtRTEI, &sp, A.size(0), A.size(0));
        st.site = &dh_emlrtRSI;
        if (A.size(0) > 2147483646) {
          b_st.site = &eb_emlrtRSI;
          check_forloop_overflow_error(b_st);
        }
        for (j = 0; j <= n; j++) {
          if (A2[j + A2.size(0) * j].re == 0.0) {
            exptj_im = A2[j + A2.size(0) * j].im;
            exptj_re = muDoubleScalarCos(exptj_im);
            exptj_im = muDoubleScalarSin(exptj_im);
          } else if (A2[j + A2.size(0) * j].im == 0.0) {
            exptj_re = muDoubleScalarExp(A2[j + A2.size(0) * j].re);
            exptj_im = 0.0;
          } else if (muDoubleScalarIsInf(A2[j + A2.size(0) * j].im) &&
                     muDoubleScalarIsInf(A2[j + A2.size(0) * j].re) &&
                     (A2[j + A2.size(0) * j].re < 0.0)) {
            exptj_re = 0.0;
            exptj_im = 0.0;
          } else {
            r = muDoubleScalarExp(A2[j + A2.size(0) * j].re / 2.0);
            exptj_im = A2[j + A2.size(0) * j].im;
            exptj_re = r * (r * muDoubleScalarCos(exptj_im));
            exptj_im = r * (r * muDoubleScalarSin(exptj_im));
          }
          st.site = &eh_emlrtRSI;
          if (n + 1 > 2147483646) {
            b_st.site = &eb_emlrtRSI;
            check_forloop_overflow_error(b_st);
          }
          for (i = 0; i <= n; i++) {
            real_T y;
            y = A4[i + A4.size(0) * j].re;
            r = A4[i + A4.size(0) * j].im;
            F[i + F.size(0) * j].re = y * exptj_re - r * exptj_im;
            F[i + F.size(0) * j].im = y * exptj_im + r * exptj_re;
          }
        }
        st.site = &fh_emlrtRSI;
        b_st.site = &te_emlrtRSI;
        dynamic_size_checks(b_st, F, A4, F.size(1), A4.size(1));
        b_st.site = &se_emlrtRSI;
        n = F.size(0);
        if ((A4.size(0) == 0) || (A4.size(1) == 0)) {
          n = F.size(0);
          F.set_size(&nf_emlrtRTEI, &b_st, n, A4.size(0));
          i = n * A4.size(0);
          for (int32_T b_i{0}; b_i < i; b_i++) {
            F[b_i] = dc1;
          }
        } else {
          c_st.site = &ue_emlrtRSI;
          d_st.site = &ve_emlrtRSI;
          A2.set_size(&mf_emlrtRTEI, &d_st, F.size(0), F.size(1));
          i = F.size(0) * F.size(1);
          for (int32_T b_i{0}; b_i < i; b_i++) {
            A2[b_i] = F[b_i];
          }
          TRANSB1 = 'C';
          TRANSA1 = 'N';
          m_t = (ptrdiff_t)F.size(0);
          n_t = (ptrdiff_t)A4.size(0);
          k_t = (ptrdiff_t)F.size(1);
          lda_t = (ptrdiff_t)F.size(0);
          ldb_t = (ptrdiff_t)A4.size(0);
          ldc_t = (ptrdiff_t)F.size(0);
          F.set_size(&ud_emlrtRTEI, &d_st, n, A4.size(0));
          zgemm(&TRANSA1, &TRANSB1, &m_t, &n_t, &k_t, (real_T *)&dc,
                (real_T *)&(A2.data())[0], &lda_t, (real_T *)&(A4.data())[0],
                &ldb_t, (real_T *)&dc1, (real_T *)&(F.data())[0], &ldc_t);
        }
        A2.set_size(&of_emlrtRTEI, &sp, F.size(0), F.size(1));
        i = F.size(1);
        for (int32_T b_i{0}; b_i < i; b_i++) {
          n = F.size(0);
          for (j = 0; j < n; j++) {
            r = F[j + F.size(0) * b_i].re + F[b_i + F.size(0) * j].re;
            exptj_im = F[j + F.size(0) * b_i].im - F[b_i + F.size(0) * j].im;
            if (exptj_im == 0.0) {
              A2[j + A2.size(0) * b_i].re = r / 2.0;
              A2[j + A2.size(0) * b_i].im = 0.0;
            } else if (r == 0.0) {
              A2[j + A2.size(0) * b_i].re = 0.0;
              A2[j + A2.size(0) * b_i].im = exptj_im / 2.0;
            } else {
              A2[j + A2.size(0) * b_i].re = r / 2.0;
              A2[j + A2.size(0) * b_i].im = exptj_im / 2.0;
            }
          }
        }
        F.set_size(&pf_emlrtRTEI, &sp, A2.size(0), A2.size(1));
        i = A2.size(0) * A2.size(1);
        for (int32_T b_i{0}; b_i < i; b_i++) {
          F[b_i] = A2[b_i];
        }
      } else {
        real_T exptj_im;
        real_T r;
        int32_T b_i;
        st.site = &gh_emlrtRSI;
        recomputeDiags = isschur(st, A);
        st.site = &hh_emlrtRSI;
        n = getExpmParams(st, A, A2, A4, A6, exptj_re);
        if (exptj_re != 0.0) {
          real_T y;
          st.site = &ih_emlrtRSI;
          b_st.site = &og_emlrtRSI;
          y = muDoubleScalarPower(2.0, exptj_re);
          i = A.size(0) * A.size(1);
          for (b_i = 0; b_i < i; b_i++) {
            r = A[b_i].re;
            exptj_im = A[b_i].im;
            if (exptj_im == 0.0) {
              r /= y;
              exptj_im = 0.0;
            } else if (r == 0.0) {
              r = 0.0;
              exptj_im /= y;
            } else {
              r /= y;
              exptj_im /= y;
            }
            A[b_i].re = r;
            A[b_i].im = exptj_im;
          }
          st.site = &jh_emlrtRSI;
          b_st.site = &og_emlrtRSI;
          y = muDoubleScalarPower(2.0, 2.0 * exptj_re);
          i = A2.size(0) * A2.size(1);
          for (b_i = 0; b_i < i; b_i++) {
            r = A2[b_i].re;
            exptj_im = A2[b_i].im;
            if (exptj_im == 0.0) {
              r /= y;
              exptj_im = 0.0;
            } else if (r == 0.0) {
              r = 0.0;
              exptj_im /= y;
            } else {
              r /= y;
              exptj_im /= y;
            }
            A2[b_i].re = r;
            A2[b_i].im = exptj_im;
          }
          st.site = &kh_emlrtRSI;
          b_st.site = &og_emlrtRSI;
          y = muDoubleScalarPower(2.0, 4.0 * exptj_re);
          i = A4.size(0) * A4.size(1);
          for (b_i = 0; b_i < i; b_i++) {
            r = A4[b_i].re;
            exptj_im = A4[b_i].im;
            if (exptj_im == 0.0) {
              r /= y;
              exptj_im = 0.0;
            } else if (r == 0.0) {
              r = 0.0;
              exptj_im /= y;
            } else {
              r /= y;
              exptj_im /= y;
            }
            A4[b_i].re = r;
            A4[b_i].im = exptj_im;
          }
          st.site = &lh_emlrtRSI;
          b_st.site = &og_emlrtRSI;
          y = muDoubleScalarPower(2.0, 6.0 * exptj_re);
          i = A6.size(0) * A6.size(1);
          for (b_i = 0; b_i < i; b_i++) {
            r = A6[b_i].re;
            exptj_im = A6[b_i].im;
            if (exptj_im == 0.0) {
              r /= y;
              exptj_im = 0.0;
            } else if (r == 0.0) {
              r = 0.0;
              exptj_im /= y;
            } else {
              r /= y;
              exptj_im /= y;
            }
            A6[b_i].re = r;
            A6[b_i].im = exptj_im;
          }
        }
        if (recomputeDiags) {
          st.site = &mh_emlrtRSI;
          if ((A.size(0) == 1) && (A.size(1) == 1)) {
            emlrtErrorWithMessageIdR2018a(&st, &n_emlrtRTEI,
                                          "Coder:builtins:AssertionFailed",
                                          "Coder:builtins:AssertionFailed", 0);
          }
          blockFormat.set_size(&if_emlrtRTEI, &st, A.size(0) - 1);
          i = A.size(0);
          for (b_i = 0; b_i <= i - 2; b_i++) {
            blockFormat[b_i] = 0;
          }
          if (A.size(0) == 2) {
            if ((A[1].re == 0.0) && (A[1].im == 0.0)) {
              blockFormat.set_size(&if_emlrtRTEI, &st, 1);
              blockFormat[0] = 1;
            } else {
              blockFormat.set_size(&if_emlrtRTEI, &st, 1);
              blockFormat[0] = 2;
            }
          } else {
            j = 0;
            while (j + 1 < A.size(0) - 1) {
              exptj_im = A[(j + A.size(0) * j) + 1].re;
              r = A[(j + A.size(0) * j) + 1].im;
              if ((exptj_im != 0.0) || (r != 0.0)) {
                blockFormat[j] = 2;
                blockFormat[j + 1] = 0;
                j += 2;
              } else if ((A[(j + A.size(0) * (j + 1)) + 2].re == 0.0) &&
                         (A[(j + A.size(0) * (j + 1)) + 2].im == 0.0)) {
                blockFormat[j] = 1;
                j++;
              } else {
                blockFormat[j] = 0;
                j++;
              }
            }
            if ((A[(A.size(0) + A.size(0) * (A.size(0) - 2)) - 1].re != 0.0) ||
                (A[(A.size(0) + A.size(0) * (A.size(0) - 2)) - 1].im != 0.0)) {
              blockFormat[A.size(0) - 2] = 2;
            } else {
              b_i = blockFormat[A.size(0) - 3];
              if ((b_i == 0) || (b_i == 1)) {
                blockFormat[A.size(0) - 2] = 1;
              }
            }
          }
        } else {
          blockFormat.set_size(&hf_emlrtRTEI, &sp, A.size(0) - 1);
        }
        st.site = &nh_emlrtRSI;
        padeApproximation(st, A, A2, A4, A6, n, F);
        if (recomputeDiags) {
          st.site = &oh_emlrtRSI;
          recomputeBlockDiag(A, F, blockFormat);
        }
        b_i = static_cast<int32_T>(exptj_re);
        emlrtForLoopVectorCheckR2021a(1.0, 1.0, exptj_re, mxDOUBLE_CLASS,
                                      static_cast<int32_T>(exptj_re),
                                      &m_emlrtRTEI, (emlrtConstCTX)&sp);
        for (n = 0; n < b_i; n++) {
          st.site = &ph_emlrtRSI;
          b_st.site = &te_emlrtRSI;
          dynamic_size_checks(b_st, F, F, F.size(1), F.size(0));
          A2.set_size(&jf_emlrtRTEI, &st, F.size(0), F.size(1));
          i = F.size(0) * F.size(1) - 1;
          for (j = 0; j <= i; j++) {
            A2[j] = F[j];
          }
          A4.set_size(&kf_emlrtRTEI, &st, F.size(0), F.size(1));
          i = F.size(0) * F.size(1) - 1;
          for (j = 0; j <= i; j++) {
            A4[j] = F[j];
          }
          b_st.site = &se_emlrtRSI;
          internal::blas::mtimes(b_st, A2, A4, F);
          if (recomputeDiags) {
            i = A.size(0) * A.size(1);
            for (j = 0; j < i; j++) {
              A[j].re = 2.0 * A[j].re;
              A[j].im = 2.0 * A[j].im;
            }
            st.site = &qh_emlrtRSI;
            recomputeBlockDiag(A, F, blockFormat);
          }
        }
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace coder

// End of code generation (expm.cpp)
