//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcReflectionSide.h
//
// Code generation for function 'calcReflectionSide'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void binary_expand_op_3(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                        const coder::array<real_T, 2U> &in2);

void binary_expand_op_4(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                        const coder::array<real_T, 2U> &in2);

void calcReflectionSide(
    const emlrtStack &sp, const coder::array<creal_T, 2U> &Kx,
    const coder::array<creal_T, 2U> &KzR, real_T N,
    const coder::array<real_T, 2U> &W0, const coder::array<creal_T, 2U> &V0,
    const creal_T grid_urR, const creal_T grid_erR, char_T mode,
    coder::array<real_T, 2U> &Wref, coder::array<creal_T, 2U> &Sref_S11,
    coder::array<creal_T, 2U> &Sref_S12, coder::array<creal_T, 2U> &Sref_S21,
    coder::array<creal_T, 2U> &Sref_S22);

// End of code generation (calcReflectionSide.h)
