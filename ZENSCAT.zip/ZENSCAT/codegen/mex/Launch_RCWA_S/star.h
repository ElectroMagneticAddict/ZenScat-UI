//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// star.h
//
// Code generation for function 'star'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void star(const emlrtStack &sp, const coder::array<creal_T, 2U> &SA_S11,
          const coder::array<creal_T, 2U> &SA_S12,
          const coder::array<creal_T, 2U> &SA_S21,
          const coder::array<creal_T, 2U> &SA_S22,
          const coder::array<creal_T, 2U> &SB_S11,
          const coder::array<creal_T, 2U> &SB_S12,
          const coder::array<creal_T, 2U> &SB_S21,
          const coder::array<creal_T, 2U> &SB_S22,
          coder::array<creal_T, 2U> &S_S11, coder::array<creal_T, 2U> &S_S12,
          coder::array<creal_T, 2U> &S_S21, coder::array<creal_T, 2U> &S_S22);

// End of code generation (star.h)
