//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcReflectionSide.cpp
//
// Code generation for function 'calcReflectionSide'
//

// Include files
#include "calcReflectionSide.h"
#include "Launch_RCWA_S_data.h"
#include "Launch_RCWA_S_mexutil.h"
#include "div.h"
#include "eml_mtimes_helper.h"
#include "eye.h"
#include "inv.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo nd_emlrtRSI{
    3,                                                               // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo od_emlrtRSI{
    6,                                                               // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo pd_emlrtRSI{
    8,                                                               // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo qd_emlrtRSI{
    10,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo rd_emlrtRSI{
    12,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo sd_emlrtRSI{
    14,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo td_emlrtRSI{
    15,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo ud_emlrtRSI{
    16,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo vd_emlrtRSI{
    17,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo wd_emlrtRSI{
    18,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtRSInfo xd_emlrtRSI{
    19,                                                              // lineNo
    "calcReflectionSide",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pathName
};

static emlrtDCInfo m_emlrtDCI{
    4,                                                                // lineNo
    22,                                                               // colNo
    "calcReflectionSide",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m", // pName
    1 // checkKind
};

static emlrtECInfo i_emlrtECI{
    1,                                                               // nDims
    6,                                                               // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo j_emlrtECI{
    2,                                                               // nDims
    6,                                                               // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo k_emlrtECI{
    1,                                                               // nDims
    10,                                                              // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo l_emlrtECI{
    2,                                                               // nDims
    10,                                                              // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo m_emlrtECI{
    1,                                                               // nDims
    14,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo n_emlrtECI{
    2,                                                               // nDims
    14,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo o_emlrtECI{
    1,                                                               // nDims
    15,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo p_emlrtECI{
    2,                                                               // nDims
    15,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo q_emlrtECI{
    1,                                                               // nDims
    18,                                                              // lineNo
    17,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtECInfo r_emlrtECI{
    2,                                                               // nDims
    18,                                                              // lineNo
    17,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo ad_emlrtRTEI{
    4,                                                               // lineNo
    1,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo bd_emlrtRTEI{
    10,                                                              // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo cd_emlrtRTEI{
    11,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo dd_emlrtRTEI{
    6,                                                               // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo ed_emlrtRTEI{
    6,                                                               // lineNo
    31,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo fd_emlrtRTEI{
    7,                                                               // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo gd_emlrtRTEI{
    14,                                                              // lineNo
    1,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo hd_emlrtRTEI{
    15,                                                              // lineNo
    1,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo id_emlrtRTEI{
    16,                                                              // lineNo
    12,                                                              // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo jd_emlrtRTEI{
    17,                                                              // lineNo
    1,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo eh_emlrtRTEI{
    15,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRTEInfo fh_emlrtRTEI{
    14,                                                              // lineNo
    5,                                                               // colNo
    "calcReflectionSide",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcReflectionSide.m" // pName
};

static emlrtRSInfo cl_emlrtRSI{
    52,    // lineNo
    "div", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\div.m" // pathName
};

// Function Definitions
void binary_expand_op_3(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                        const coder::array<real_T, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in2;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(&eh_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      i2 = i1 * stride_1_0;
      b_in2[i1 + b_in2.size(0) * i].re =
          in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] -
          in1[i2 + in1.size(0) * aux_1_1].re;
      b_in2[i1 + b_in2.size(0) * i].im =
          0.0 - in1[i2 + in1.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(&eh_emlrtRTEI, &sp, b_in2.size(0), b_in2.size(1));
  loop_ub = b_in2.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in2.size(0);
    for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void binary_expand_op_4(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                        const coder::array<real_T, 2U> &in2)
{
  coder::array<creal_T, 2U> b_in2;
  int32_T aux_0_1;
  int32_T aux_1_1;
  int32_T b_loop_ub;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_0_1;
  int32_T stride_1_0;
  int32_T stride_1_1;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(&fh_emlrtRTEI, &sp, loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int32_T i{0}; i < b_loop_ub; i++) {
    for (int32_T i1{0}; i1 < loop_ub; i1++) {
      int32_T i2;
      i2 = i1 * stride_1_0;
      b_in2[i1 + b_in2.size(0) * i].re =
          in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] +
          in1[i2 + in1.size(0) * aux_1_1].re;
      b_in2[i1 + b_in2.size(0) * i].im = in1[i2 + in1.size(0) * aux_1_1].im;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(&fh_emlrtRTEI, &sp, b_in2.size(0), b_in2.size(1));
  loop_ub = b_in2.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in2.size(0);
    for (int32_T i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void calcReflectionSide(
    const emlrtStack &sp, const coder::array<creal_T, 2U> &Kx,
    const coder::array<creal_T, 2U> &KzR, real_T N,
    const coder::array<real_T, 2U> &W0, const coder::array<creal_T, 2U> &V0,
    const creal_T grid_urR, const creal_T grid_erR, char_T mode,
    coder::array<real_T, 2U> &Wref, coder::array<creal_T, 2U> &Sref_S11,
    coder::array<creal_T, 2U> &Sref_S12, coder::array<creal_T, 2U> &Sref_S21,
    coder::array<creal_T, 2U> &Sref_S22)
{
  coder::array<creal_T, 2U> A;
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> Q;
  coder::array<creal_T, 2U> Vref;
  coder::array<creal_T, 2U> lam;
  coder::array<real_T, 2U> a;
  emlrtStack b_st;
  emlrtStack st;
  int32_T loop_ub;
  int32_T loop_ub_tmp;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  //  Reflected modes from the surface of the device
  st.site = &nd_emlrtRSI;
  coder::eye(st, N, Wref);
  if (N != static_cast<int32_T>(muDoubleScalarFloor(N))) {
    emlrtIntegerCheckR2012b(N, &m_emlrtDCI, (emlrtConstCTX)&sp);
  }
  Vref.set_size(&ad_emlrtRTEI, &sp, static_cast<int32_T>(N),
                static_cast<int32_T>(N));
  loop_ub = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (int32_T i{0}; i < loop_ub; i++) {
    Vref[i].re = 0.0;
    Vref[i].im = 0.0;
  }
  if (mode == 'E') {
    real_T d;
    real_T varargout_1_tmp;
    Q.set_size(&dd_emlrtRTEI, &sp, Kx.size(0), Kx.size(1));
    loop_ub_tmp = Kx.size(0) * Kx.size(1);
    for (int32_T i{0}; i < loop_ub_tmp; i++) {
      creal_T varargin_1;
      real_T im;
      real_T re;
      varargin_1 = Kx[i];
      re = varargin_1.re * varargin_1.re - varargin_1.im * varargin_1.im;
      varargout_1_tmp = varargin_1.re * varargin_1.im;
      im = varargout_1_tmp + varargout_1_tmp;
      if (grid_urR.im == 0.0) {
        if (im == 0.0) {
          Q[i].re = re / grid_urR.re;
          Q[i].im = 0.0;
        } else if (re == 0.0) {
          Q[i].re = 0.0;
          Q[i].im = im / grid_urR.re;
        } else {
          Q[i].re = re / grid_urR.re;
          Q[i].im = im / grid_urR.re;
        }
      } else if (grid_urR.re == 0.0) {
        if (re == 0.0) {
          Q[i].re = im / grid_urR.im;
          Q[i].im = 0.0;
        } else if (im == 0.0) {
          Q[i].re = 0.0;
          Q[i].im = -(re / grid_urR.im);
        } else {
          Q[i].re = im / grid_urR.im;
          Q[i].im = -(re / grid_urR.im);
        }
      } else {
        real_T brm;
        brm = muDoubleScalarAbs(grid_urR.re);
        varargout_1_tmp = muDoubleScalarAbs(grid_urR.im);
        if (brm > varargout_1_tmp) {
          varargout_1_tmp = grid_urR.im / grid_urR.re;
          d = grid_urR.re + varargout_1_tmp * grid_urR.im;
          Q[i].re = (re + varargout_1_tmp * im) / d;
          Q[i].im = (im - varargout_1_tmp * re) / d;
        } else if (varargout_1_tmp == brm) {
          if (grid_urR.re > 0.0) {
            varargout_1_tmp = 0.5;
          } else {
            varargout_1_tmp = -0.5;
          }
          if (grid_urR.im > 0.0) {
            d = 0.5;
          } else {
            d = -0.5;
          }
          Q[i].re = (re * varargout_1_tmp + im * d) / brm;
          Q[i].im = (im * varargout_1_tmp - re * d) / brm;
        } else {
          varargout_1_tmp = grid_urR.re / grid_urR.im;
          d = grid_urR.im + varargout_1_tmp * grid_urR.re;
          Q[i].re = (varargout_1_tmp * re + im) / d;
          Q[i].im = (varargout_1_tmp * im - re) / d;
        }
      }
    }
    st.site = &od_emlrtRSI;
    coder::eye(st, N, a);
    lam.set_size(&ed_emlrtRTEI, &sp, a.size(0), a.size(1));
    loop_ub = a.size(0) * a.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      lam[i].re = a[i] * grid_erR.re;
      lam[i].im = a[i] * grid_erR.im;
    }
    if ((Q.size(0) != lam.size(0)) &&
        ((Q.size(0) != 1) && (lam.size(0) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Q.size(0), lam.size(0), &i_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((Q.size(1) != lam.size(1)) &&
        ((Q.size(1) != 1) && (lam.size(1) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Q.size(1), lam.size(1), &j_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((Q.size(0) == lam.size(0)) && (Q.size(1) == lam.size(1))) {
      for (int32_T i{0}; i < loop_ub_tmp; i++) {
        Q[i].re = Q[i].re - lam[i].re;
        Q[i].im = Q[i].im - lam[i].im;
      }
    } else {
      st.site = &od_emlrtRSI;
      minus(st, Q, lam);
    }
    lam.set_size(&fd_emlrtRTEI, &sp, KzR.size(0), KzR.size(1));
    loop_ub = KzR.size(0) * KzR.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      varargout_1_tmp = KzR[i].im;
      d = KzR[i].re;
      lam[i].re = 0.0 * d - (-varargout_1_tmp);
      lam[i].im = 0.0 * varargout_1_tmp - d;
    }
    st.site = &pd_emlrtRSI;
    if (lam.size(1) != Q.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                    "MATLAB:dimagree", 0);
    }
    b_st.site = &rb_emlrtRSI;
    coder::internal::mrdiv(b_st, Q, lam, Vref);
  } else if (mode == 'H') {
    real_T brm;
    real_T d;
    real_T im;
    real_T re;
    real_T varargout_1_tmp;
    Q.set_size(&bd_emlrtRTEI, &sp, Kx.size(0), Kx.size(1));
    loop_ub_tmp = Kx.size(0) * Kx.size(1);
    for (int32_T i{0}; i < loop_ub_tmp; i++) {
      creal_T varargin_1;
      varargin_1 = Kx[i];
      re = varargin_1.re * varargin_1.re - varargin_1.im * varargin_1.im;
      varargout_1_tmp = varargin_1.re * varargin_1.im;
      im = varargout_1_tmp + varargout_1_tmp;
      if (grid_erR.im == 0.0) {
        if (im == 0.0) {
          Q[i].re = re / grid_erR.re;
          Q[i].im = 0.0;
        } else if (re == 0.0) {
          Q[i].re = 0.0;
          Q[i].im = im / grid_erR.re;
        } else {
          Q[i].re = re / grid_erR.re;
          Q[i].im = im / grid_erR.re;
        }
      } else if (grid_erR.re == 0.0) {
        if (re == 0.0) {
          Q[i].re = im / grid_erR.im;
          Q[i].im = 0.0;
        } else if (im == 0.0) {
          Q[i].re = 0.0;
          Q[i].im = -(re / grid_erR.im);
        } else {
          Q[i].re = im / grid_erR.im;
          Q[i].im = -(re / grid_erR.im);
        }
      } else {
        brm = muDoubleScalarAbs(grid_erR.re);
        varargout_1_tmp = muDoubleScalarAbs(grid_erR.im);
        if (brm > varargout_1_tmp) {
          varargout_1_tmp = grid_erR.im / grid_erR.re;
          d = grid_erR.re + varargout_1_tmp * grid_erR.im;
          Q[i].re = (re + varargout_1_tmp * im) / d;
          Q[i].im = (im - varargout_1_tmp * re) / d;
        } else if (varargout_1_tmp == brm) {
          if (grid_erR.re > 0.0) {
            varargout_1_tmp = 0.5;
          } else {
            varargout_1_tmp = -0.5;
          }
          if (grid_erR.im > 0.0) {
            d = 0.5;
          } else {
            d = -0.5;
          }
          Q[i].re = (re * varargout_1_tmp + im * d) / brm;
          Q[i].im = (im * varargout_1_tmp - re * d) / brm;
        } else {
          varargout_1_tmp = grid_erR.re / grid_erR.im;
          d = grid_erR.im + varargout_1_tmp * grid_erR.re;
          Q[i].re = (varargout_1_tmp * re + im) / d;
          Q[i].im = (varargout_1_tmp * im - re) / d;
        }
      }
    }
    st.site = &qd_emlrtRSI;
    coder::eye(st, N, a);
    if ((Q.size(0) != a.size(0)) && ((Q.size(0) != 1) && (a.size(0) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Q.size(0), a.size(0), &k_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    if ((Q.size(1) != a.size(1)) && ((Q.size(1) != 1) && (a.size(1) != 1))) {
      emlrtDimSizeImpxCheckR2021b(Q.size(1), a.size(1), &l_emlrtECI,
                                  (emlrtConstCTX)&sp);
    }
    lam.set_size(&cd_emlrtRTEI, &sp, KzR.size(0), KzR.size(1));
    loop_ub = KzR.size(0) * KzR.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      varargout_1_tmp = KzR[i].im;
      d = KzR[i].re;
      lam[i].re = -(0.0 * d - varargout_1_tmp);
      lam[i].im = -(0.0 * varargout_1_tmp + d);
    }
    if ((Q.size(0) == a.size(0)) && (Q.size(1) == a.size(1))) {
      for (int32_T i{0}; i < loop_ub_tmp; i++) {
        real_T ai;
        im = Q[i].re - a[i];
        ai = Q[i].im;
        if (grid_erR.im == 0.0) {
          if (ai == 0.0) {
            re = im / grid_erR.re;
            im = 0.0;
          } else if (im == 0.0) {
            re = 0.0;
            im = ai / grid_erR.re;
          } else {
            re = im / grid_erR.re;
            im = ai / grid_erR.re;
          }
        } else if (grid_erR.re == 0.0) {
          if (im == 0.0) {
            re = ai / grid_erR.im;
            im = 0.0;
          } else if (ai == 0.0) {
            re = 0.0;
            im = -(im / grid_erR.im);
          } else {
            re = ai / grid_erR.im;
            im = -(im / grid_erR.im);
          }
        } else {
          brm = muDoubleScalarAbs(grid_erR.re);
          varargout_1_tmp = muDoubleScalarAbs(grid_erR.im);
          if (brm > varargout_1_tmp) {
            varargout_1_tmp = grid_erR.im / grid_erR.re;
            d = grid_erR.re + varargout_1_tmp * grid_erR.im;
            re = (im + varargout_1_tmp * ai) / d;
            im = (ai - varargout_1_tmp * im) / d;
          } else if (varargout_1_tmp == brm) {
            if (grid_erR.re > 0.0) {
              varargout_1_tmp = 0.5;
            } else {
              varargout_1_tmp = -0.5;
            }
            if (grid_erR.im > 0.0) {
              d = 0.5;
            } else {
              d = -0.5;
            }
            re = (im * varargout_1_tmp + ai * d) / brm;
            im = (ai * varargout_1_tmp - im * d) / brm;
          } else {
            varargout_1_tmp = grid_erR.re / grid_erR.im;
            d = grid_erR.im + varargout_1_tmp * grid_erR.re;
            re = (varargout_1_tmp * im + ai) / d;
            im = (varargout_1_tmp * ai - im) / d;
          }
        }
        Q[i].re = re;
        Q[i].im = im;
      }
    } else {
      st.site = &cl_emlrtRSI;
      binary_expand_op_5(st, Q, a, grid_erR);
    }
    st.site = &rd_emlrtRSI;
    if (lam.size(1) != Q.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                    "MATLAB:dimagree", 0);
    }
    b_st.site = &rb_emlrtRSI;
    coder::internal::mrdiv(b_st, Q, lam, Vref);
  }
  st.site = &sd_emlrtRSI;
  coder::mldivide(st, W0, Wref, a);
  st.site = &sd_emlrtRSI;
  coder::mldivide(st, V0, Vref, A);
  if ((a.size(0) != A.size(0)) && ((a.size(0) != 1) && (A.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(0), A.size(0), &m_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(1) != A.size(1)) && ((a.size(1) != 1) && (A.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(1), A.size(1), &n_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(0) == A.size(0)) && (a.size(1) == A.size(1))) {
    loop_ub = a.size(0) * a.size(1);
    A.set_size(&gd_emlrtRTEI, &sp, a.size(0), a.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      A[i].re = a[i] + A[i].re;
      A[i].im = A[i].im;
    }
  } else {
    st.site = &sd_emlrtRSI;
    binary_expand_op_4(st, A, a);
  }
  st.site = &td_emlrtRSI;
  coder::mldivide(st, W0, Wref, a);
  st.site = &td_emlrtRSI;
  coder::mldivide(st, V0, Vref, B);
  if ((a.size(0) != B.size(0)) && ((a.size(0) != 1) && (B.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(0), B.size(0), &o_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(1) != B.size(1)) && ((a.size(1) != 1) && (B.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(a.size(1), B.size(1), &p_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((a.size(0) == B.size(0)) && (a.size(1) == B.size(1))) {
    loop_ub = a.size(0) * a.size(1);
    B.set_size(&hd_emlrtRTEI, &sp, a.size(0), a.size(1));
    for (int32_T i{0}; i < loop_ub; i++) {
      B[i].re = a[i] - B[i].re;
      B[i].im = 0.0 - B[i].im;
    }
  } else {
    st.site = &td_emlrtRSI;
    binary_expand_op_3(st, B, a);
  }
  Vref.set_size(&id_emlrtRTEI, &sp, A.size(0), A.size(1));
  loop_ub_tmp = A.size(0) * A.size(1);
  for (int32_T i{0}; i < loop_ub_tmp; i++) {
    Vref[i].re = -A[i].re;
    Vref[i].im = -A[i].im;
  }
  st.site = &ud_emlrtRSI;
  coder::mldivide(st, Vref, B, Sref_S11);
  st.site = &vd_emlrtRSI;
  coder::inv(st, A, lam);
  Sref_S12.set_size(&jd_emlrtRTEI, &sp, lam.size(0), lam.size(1));
  loop_ub = lam.size(0) * lam.size(1);
  for (int32_T i{0}; i < loop_ub; i++) {
    Sref_S12[i].re = 2.0 * lam[i].re;
    Sref_S12[i].im = 2.0 * lam[i].im;
  }
  st.site = &wd_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, B, A, Q);
  st.site = &wd_emlrtRSI;
  b_st.site = &te_emlrtRSI;
  if (B.size(0) != Q.size(1)) {
    if (((Q.size(0) == 1) && (Q.size(1) == 1)) ||
        ((B.size(0) == 1) && (B.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(
          &b_st, &g_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  b_st.site = &se_emlrtRSI;
  coder::internal::blas::mtimes(b_st, Q, B, lam);
  if ((A.size(0) != lam.size(0)) && ((A.size(0) != 1) && (lam.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(0), lam.size(0), &q_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(1) != lam.size(1)) && ((A.size(1) != 1) && (lam.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(A.size(1), lam.size(1), &r_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((A.size(0) == lam.size(0)) && (A.size(1) == lam.size(1))) {
    Sref_S21.set_size(&kd_emlrtRTEI, &sp, A.size(0), A.size(1));
    for (int32_T i{0}; i < loop_ub_tmp; i++) {
      Sref_S21[i].re = 0.5 * (A[i].re - lam[i].re);
      Sref_S21[i].im = 0.5 * (A[i].im - lam[i].im);
    }
  } else {
    st.site = &bl_emlrtRSI;
    binary_expand_op_2(st, Sref_S21, A, lam);
  }
  st.site = &xd_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  b_st.site = &rb_emlrtRSI;
  coder::internal::mrdiv(b_st, B, A, Sref_S22);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

// End of code generation (calcReflectionSide.cpp)
