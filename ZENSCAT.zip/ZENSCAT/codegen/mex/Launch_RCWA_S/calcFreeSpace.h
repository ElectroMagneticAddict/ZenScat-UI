//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcFreeSpace.h
//
// Code generation for function 'calcFreeSpace'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void binary_expand_op(const emlrtStack &sp, coder::array<creal_T, 2U> &in1,
                      const coder::array<real_T, 2U> &in2);

// End of code generation (calcFreeSpace.h)
