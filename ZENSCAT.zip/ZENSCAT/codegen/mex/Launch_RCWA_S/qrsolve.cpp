//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// qrsolve.cpp
//
// Code generation for function 'qrsolve'
//

// Include files
#include "qrsolve.h"
#include "Launch_RCWA_S_data.h"
#include "Launch_RCWA_S_mexutil.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xgeqp3.h"
#include "xunormqr.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo ad_emlrtRSI{
    173,          // lineNo
    "rankFromQR", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m" // pathName
};

static emlrtRSInfo bd_emlrtRSI{
    172,          // lineNo
    "rankFromQR", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m" // pathName
};

static emlrtRTEInfo xc_emlrtRTEI{
    85,        // lineNo
    1,         // colNo
    "qrsolve", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m" // pName
};

// Function Definitions
namespace coder {
namespace internal {
void qrsolve(const emlrtStack &sp, const array<creal_T, 2U> &A,
             const array<creal_T, 2U> &B, array<creal_T, 2U> &Y)
{
  array<creal_T, 2U> b_A;
  array<creal_T, 2U> b_B;
  array<creal_T, 1U> tau;
  array<int32_T, 2U> jpvt;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  int32_T i;
  int32_T loop_ub;
  int32_T nb;
  int32_T rankA;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  b_A.set_size(&wc_emlrtRTEI, &sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_A[i] = A[i];
  }
  st.site = &nc_emlrtRSI;
  lapack::xgeqp3(st, b_A, tau, jpvt);
  st.site = &oc_emlrtRSI;
  rankA = rankFromQR(st, b_A);
  st.site = &pc_emlrtRSI;
  nb = B.size(1);
  Y.set_size(&xc_emlrtRTEI, &st, b_A.size(1), B.size(1));
  loop_ub = b_A.size(1) * B.size(1);
  for (i = 0; i < loop_ub; i++) {
    Y[i].re = 0.0;
    Y[i].im = 0.0;
  }
  b_B.set_size(&yc_emlrtRTEI, &st, B.size(0), B.size(1));
  loop_ub = B.size(0) * B.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_B[i] = B[i];
  }
  b_st.site = &cd_emlrtRSI;
  lapack::xunormqr(b_st, b_A, b_B, tau);
  b_st.site = &dd_emlrtRSI;
  if (B.size(1) > 2147483646) {
    c_st.site = &eb_emlrtRSI;
    check_forloop_overflow_error(c_st);
  }
  for (int32_T k{0}; k < nb; k++) {
    b_st.site = &ed_emlrtRSI;
    if (rankA > 2147483646) {
      c_st.site = &eb_emlrtRSI;
      check_forloop_overflow_error(c_st);
    }
    for (loop_ub = 0; loop_ub < rankA; loop_ub++) {
      Y[(jpvt[loop_ub] + Y.size(0) * k) - 1] = b_B[loop_ub + b_B.size(0) * k];
    }
    for (int32_T j{rankA}; j >= 1; j--) {
      real_T ai;
      real_T ar;
      real_T bi;
      real_T br;
      real_T brm;
      real_T im;
      real_T re;
      real_T sgnbr;
      i = jpvt[j - 1];
      ar = Y[(i + Y.size(0) * k) - 1].re;
      ai = Y[(i + Y.size(0) * k) - 1].im;
      br = b_A[(j + b_A.size(0) * (j - 1)) - 1].re;
      bi = b_A[(j + b_A.size(0) * (j - 1)) - 1].im;
      if (bi == 0.0) {
        if (ai == 0.0) {
          re = ar / br;
          im = 0.0;
        } else if (ar == 0.0) {
          re = 0.0;
          im = ai / br;
        } else {
          re = ar / br;
          im = ai / br;
        }
      } else if (br == 0.0) {
        if (ar == 0.0) {
          re = ai / bi;
          im = 0.0;
        } else if (ai == 0.0) {
          re = 0.0;
          im = -(ar / bi);
        } else {
          re = ai / bi;
          im = -(ar / bi);
        }
      } else {
        brm = muDoubleScalarAbs(br);
        im = muDoubleScalarAbs(bi);
        if (brm > im) {
          brm = bi / br;
          im = br + brm * bi;
          re = (ar + brm * ai) / im;
          im = (ai - brm * ar) / im;
        } else if (im == brm) {
          if (br > 0.0) {
            sgnbr = 0.5;
          } else {
            sgnbr = -0.5;
          }
          if (bi > 0.0) {
            im = 0.5;
          } else {
            im = -0.5;
          }
          re = (ar * sgnbr + ai * im) / brm;
          im = (ai * sgnbr - ar * im) / brm;
        } else {
          brm = br / bi;
          im = bi + brm * br;
          re = (brm * ar + ai) / im;
          im = (brm * ai - ar) / im;
        }
      }
      Y[(i + Y.size(0) * k) - 1].re = re;
      Y[(i + Y.size(0) * k) - 1].im = im;
      b_st.site = &fd_emlrtRSI;
      for (loop_ub = 0; loop_ub <= j - 2; loop_ub++) {
        im = Y[(jpvt[j - 1] + Y.size(0) * k) - 1].re;
        brm = b_A[loop_ub + b_A.size(0) * (j - 1)].im;
        sgnbr = Y[(jpvt[j - 1] + Y.size(0) * k) - 1].im;
        br = b_A[loop_ub + b_A.size(0) * (j - 1)].re;
        Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].re =
            Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].re - (im * br - sgnbr * brm);
        Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].im =
            Y[(jpvt[loop_ub] + Y.size(0) * k) - 1].im - (im * brm + sgnbr * br);
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

int32_T rankFromQR(const emlrtStack &sp, const array<creal_T, 2U> &A)
{
  static const int32_T b_iv[2]{1, 6};
  static const char_T rfmt[6]{'%', '1', '4', '.', '6', 'e'};
  emlrtStack b_st;
  emlrtStack st;
  const mxArray *b_y;
  const mxArray *m;
  const mxArray *y;
  real_T tol;
  int32_T maxmn;
  int32_T minmn;
  int32_T r;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  r = 0;
  tol = 0.0;
  if (A.size(0) < A.size(1)) {
    minmn = A.size(0);
    maxmn = A.size(1);
  } else {
    minmn = A.size(1);
    maxmn = A.size(0);
  }
  if (minmn > 0) {
    tol =
        muDoubleScalarMin(1.4901161193847656E-8,
                          2.2204460492503131E-15 * static_cast<real_T>(maxmn)) *
        muDoubleScalarHypot(A[0].re, A[0].im);
    while ((r < minmn) &&
           (!(muDoubleScalarHypot(A[r + A.size(0) * r].re,
                                  A[r + A.size(0) * r].im) <= tol))) {
      r++;
    }
  }
  if (r < minmn) {
    char_T str[14];
    st.site = &ad_emlrtRSI;
    y = nullptr;
    m = emlrtCreateCharArray(2, &b_iv[0]);
    emlrtInitCharArrayR2013a(&st, 6, m, &rfmt[0]);
    emlrtAssign(&y, m);
    b_y = nullptr;
    m = emlrtCreateDoubleScalar(tol);
    emlrtAssign(&b_y, m);
    b_st.site = &al_emlrtRSI;
    emlrt_marshallIn(b_st, b_sprintf(b_st, y, b_y, c_emlrtMCI),
                     "<output of sprintf>", str);
    st.site = &bd_emlrtRSI;
    warning(st, r, str);
  }
  return r;
}

int32_T rankFromQR(const emlrtStack &sp, const array<real_T, 2U> &A)
{
  static const int32_T b_iv[2]{1, 6};
  static const char_T rfmt[6]{'%', '1', '4', '.', '6', 'e'};
  emlrtStack b_st;
  emlrtStack st;
  const mxArray *b_y;
  const mxArray *m;
  const mxArray *y;
  real_T tol;
  int32_T maxmn;
  int32_T minmn;
  int32_T r;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  r = 0;
  tol = 0.0;
  if (A.size(0) < A.size(1)) {
    minmn = A.size(0);
    maxmn = A.size(1);
  } else {
    minmn = A.size(1);
    maxmn = A.size(0);
  }
  if (minmn > 0) {
    tol =
        muDoubleScalarMin(1.4901161193847656E-8,
                          2.2204460492503131E-15 * static_cast<real_T>(maxmn)) *
        muDoubleScalarAbs(A[0]);
    while ((r < minmn) && (!(muDoubleScalarAbs(A[r + A.size(0) * r]) <= tol))) {
      r++;
    }
  }
  if (r < minmn) {
    char_T str[14];
    st.site = &ad_emlrtRSI;
    y = nullptr;
    m = emlrtCreateCharArray(2, &b_iv[0]);
    emlrtInitCharArrayR2013a(&st, 6, m, &rfmt[0]);
    emlrtAssign(&y, m);
    b_y = nullptr;
    m = emlrtCreateDoubleScalar(tol);
    emlrtAssign(&b_y, m);
    b_st.site = &al_emlrtRSI;
    emlrt_marshallIn(b_st, b_sprintf(b_st, y, b_y, c_emlrtMCI),
                     "<output of sprintf>", str);
    st.site = &bd_emlrtRSI;
    warning(st, r, str);
  }
  return r;
}

} // namespace internal
} // namespace coder

// End of code generation (qrsolve.cpp)
