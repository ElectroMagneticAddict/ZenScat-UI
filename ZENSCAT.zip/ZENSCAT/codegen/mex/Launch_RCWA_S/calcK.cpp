//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// calcK.cpp
//
// Code generation for function 'calcK'
//

// Include files
#include "calcK.h"
#include "Launch_RCWA_S_data.h"
#include "Launch_RCWA_S_mexutil.h"
#include "eml_int_forloop_overflow_check.h"
#include "eye.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "sqrt1.h"
#include "coder_array.h"
#include "mwmathutil.h"
#include <emmintrin.h>

// Variable Definitions
static emlrtRSInfo fb_emlrtRSI{
    14,                                                 // lineNo
    "calcK",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pathName
};

static emlrtRSInfo gb_emlrtRSI{
    15,                                                 // lineNo
    "calcK",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pathName
};

static emlrtRSInfo hb_emlrtRSI{
    16,                                                 // lineNo
    "calcK",                                            // fcnName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pathName
};

static emlrtRSInfo ib_emlrtRSI{
    90,     // lineNo
    "diag", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\elmat\\diag.m" // pathName
};

static emlrtECInfo e_emlrtECI{
    1,                                                  // nDims
    15,                                                 // lineNo
    25,                                                 // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtECInfo f_emlrtECI{
    2,                                                  // nDims
    15,                                                 // lineNo
    25,                                                 // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtECInfo g_emlrtECI{
    1,                                                  // nDims
    16,                                                 // lineNo
    30,                                                 // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtECInfo h_emlrtECI{
    2,                                                  // nDims
    16,                                                 // lineNo
    30,                                                 // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtBCInfo eb_emlrtBCI{
    -1,                                                  // iFirst
    -1,                                                  // iLast
    11,                                                  // lineNo
    9,                                                   // colNo
    "k_x",                                               // aName
    "calcK",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m", // pName
    0                                                    // checkKind
};

static emlrtBCInfo fb_emlrtBCI{
    -1,                                                  // iFirst
    -1,                                                  // iLast
    13,                                                  // lineNo
    5,                                                   // colNo
    "k_x",                                               // aName
    "calcK",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m", // pName
    0                                                    // checkKind
};

static emlrtBCInfo gb_emlrtBCI{
    -1,                                                  // iFirst
    -1,                                                  // iLast
    11,                                                  // lineNo
    31,                                                  // colNo
    "M",                                                 // aName
    "calcK",                                             // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m", // pName
    0                                                    // checkKind
};

static emlrtRTEInfo
    fc_emlrtRTEI{
        28,      // lineNo
        9,       // colNo
        "colon", // fName
        "C:\\Program "
        "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m" // pName
    };

static emlrtRTEInfo gc_emlrtRTEI{
    7,                                                  // lineNo
    1,                                                  // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtRTEInfo hc_emlrtRTEI{
    9,                                                  // lineNo
    1,                                                  // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtRTEInfo ic_emlrtRTEI{
    34,               // lineNo
    1,                // colNo
    "rdivide_helper", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\rdivide_"
    "helper.m" // pName
};

static emlrtRTEInfo jc_emlrtRTEI{
    14,                                                 // lineNo
    1,                                                  // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtRTEInfo kc_emlrtRTEI{
    15,                                                 // lineNo
    25,                                                 // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

static emlrtRTEInfo lc_emlrtRTEI{
    15,                                                 // lineNo
    54,                                                 // colNo
    "calcK",                                            // fName
    "C:\\Users\\toran\\Desktop\\WORK\\2D RCWA\\calcK.m" // pName
};

// Function Definitions
void calcK(const emlrtStack &sp, const creal_T grid_urR, const creal_T grid_erR,
           const creal_T grid_urT, const creal_T grid_erT, real_T grid_Lx,
           real_T lam0, real_T theta, real_T NH, coder::array<creal_T, 2U> &Kx,
           coder::array<creal_T, 2U> &KzT, coder::array<creal_T, 2U> &KzR)
{
  coder::array<creal_T, 2U> k_x;
  coder::array<creal_T, 2U> r1;
  coder::array<creal_T, 1U> z;
  coder::array<real_T, 2U> M;
  coder::array<real_T, 2U> b_b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  creal_T kinc_x;
  real_T b;
  real_T b_kinc_x_tmp;
  real_T c_kinc_x_tmp;
  real_T k0;
  real_T k0_im;
  real_T k0_re;
  real_T kinc_x_tmp;
  int32_T i;
  int32_T nv;
  int32_T scalarLB;
  int32_T vectorUB;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  //  Calculate K_x, K_z^{(T)} and K_z^{(R)} diagonal matrices.
  // n_inc
  b = 2.0 * NH + 1.0;
  k0 = 6.2831853071795862 / lam0;
  kinc_x_tmp = grid_erR.re * grid_urR.re - grid_erR.im * grid_urR.im;
  kinc_x.re = kinc_x_tmp;
  b_kinc_x_tmp = grid_erR.re * grid_urR.im + grid_erR.im * grid_urR.re;
  kinc_x.im = b_kinc_x_tmp;
  coder::internal::scalar::c_sqrt(&kinc_x);
  k0_re = k0 * kinc_x.re;
  k0_im = k0 * kinc_x.im;
  c_kinc_x_tmp = muDoubleScalarSin(theta);
  kinc_x.re = c_kinc_x_tmp * k0_re;
  kinc_x.im = c_kinc_x_tmp * k0_im;
  // kx^(inc)
  if (muDoubleScalarIsNaN(b)) {
    M.set_size(&fc_emlrtRTEI, &sp, 1, 1);
    M[0] = rtNaN;
  } else if (b < 1.0) {
    M.set_size(&fc_emlrtRTEI, &sp, M.size(0), 0);
  } else {
    M.set_size(&fc_emlrtRTEI, &sp, 1, static_cast<int32_T>(b - 1.0) + 1);
    nv = static_cast<int32_T>(b - 1.0);
    for (i = 0; i <= nv; i++) {
      M[i] = static_cast<real_T>(i) + 1.0;
    }
  }
  i = M.size(1);
  M.set_size(&gc_emlrtRTEI, &sp, 1, M.size(1));
  nv = i - 1;
  scalarLB = (i / 2) << 1;
  vectorUB = scalarLB - 2;
  for (i = 0; i <= vectorUB; i += 2) {
    __m128d r;
    r = _mm_loadu_pd(&M[i]);
    _mm_storeu_pd(&M[i], _mm_mul_pd(_mm_sub_pd(_mm_sub_pd(r, _mm_set1_pd(NH)),
                                               _mm_set1_pd(1.0)),
                                    _mm_set1_pd(-1.0)));
  }
  for (i = scalarLB; i <= nv; i++) {
    M[i] = -((M[i] - NH) - 1.0);
  }
  //  harmonic orders
  // Size of matrices
  k_x.set_size(&hc_emlrtRTEI, &sp, 1, M.size(1));
  nv = M.size(1);
  for (i = 0; i < nv; i++) {
    k_x[i].re = 0.0;
    k_x[i].im = 0.0;
  }
  i = M.size(1);
  for (scalarLB = 0; scalarLB < i; scalarLB++) {
    if (scalarLB + 1 > k_x.size(1)) {
      emlrtDynamicBoundsCheckR2012b(scalarLB + 1, 1, k_x.size(1), &eb_emlrtBCI,
                                    (emlrtConstCTX)&sp);
    }
    nv = M.size(1);
    if (scalarLB + 1 > nv) {
      emlrtDynamicBoundsCheckR2012b(scalarLB + 1, 1, nv, &gb_emlrtBCI,
                                    (emlrtConstCTX)&sp);
    }
    k_x[scalarLB].re =
        kinc_x.re - 6.2831853071795862 * M[scalarLB] / (grid_Lx * 1.0E-6);
    if (scalarLB + 1 > k_x.size(1)) {
      emlrtDynamicBoundsCheckR2012b(scalarLB + 1, 1, k_x.size(1), &eb_emlrtBCI,
                                    (emlrtConstCTX)&sp);
    }
    k_x[scalarLB].im = kinc_x.im;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b((emlrtConstCTX)&sp);
    }
  }
  nv = k_x.size(1) - 1;
  for (scalarLB = 0; scalarLB <= nv; scalarLB++) {
    if ((k_x[scalarLB].re == 0.0) && (k_x[scalarLB].im == 0.0)) {
      if (scalarLB > nv) {
        emlrtDynamicBoundsCheckR2012b(scalarLB, 0, nv, &fb_emlrtBCI,
                                      (emlrtConstCTX)&sp);
      }
      k_x[scalarLB].re = 1.0E-6;
      if (scalarLB > nv) {
        emlrtDynamicBoundsCheckR2012b(scalarLB, 0, nv, &fb_emlrtBCI,
                                      (emlrtConstCTX)&sp);
      }
      k_x[scalarLB].im = 0.0;
    }
  }
  z.set_size(&ic_emlrtRTEI, &sp, k_x.size(1));
  nv = k_x.size(1);
  for (i = 0; i < nv; i++) {
    b = k_x[i].re;
    k0_re = k_x[i].im;
    if (k0_re == 0.0) {
      z[i].re = b / k0;
      z[i].im = 0.0;
    } else if (b == 0.0) {
      z[i].re = 0.0;
      z[i].im = k0_re / k0;
    } else {
      z[i].re = b / k0;
      z[i].im = k0_re / k0;
    }
  }
  st.site = &fb_emlrtRSI;
  nv = z.size(0);
  Kx.set_size(&jc_emlrtRTEI, &st, z.size(0), z.size(0));
  scalarLB = z.size(0) * z.size(0);
  for (i = 0; i < scalarLB; i++) {
    Kx[i].re = 0.0;
    Kx[i].im = 0.0;
  }
  b_st.site = &ib_emlrtRSI;
  if (z.size(0) > 2147483646) {
    c_st.site = &eb_emlrtRSI;
    coder::check_forloop_overflow_error(c_st);
  }
  for (vectorUB = 0; vectorUB < nv; vectorUB++) {
    Kx[vectorUB + Kx.size(0) * vectorUB] = z[vectorUB];
  }
  st.site = &gb_emlrtRSI;
  coder::eye(st, static_cast<real_T>(M.size(1)), b_b);
  KzT.set_size(&kc_emlrtRTEI, &sp, b_b.size(0), b_b.size(1));
  kinc_x.re = grid_erT.re * grid_urT.re - grid_erT.im * grid_urT.im;
  kinc_x.im = grid_erT.re * grid_urT.im + grid_erT.im * grid_urT.re;
  nv = b_b.size(0) * b_b.size(1);
  for (i = 0; i < nv; i++) {
    KzT[i].re = b_b[i] * kinc_x.re;
    KzT[i].im = b_b[i] * kinc_x.im;
  }
  r1.set_size(&lc_emlrtRTEI, &sp, Kx.size(0), Kx.size(1));
  for (i = 0; i < scalarLB; i++) {
    creal_T varargout_1;
    kinc_x = Kx[i];
    varargout_1.re = kinc_x.re * kinc_x.re - kinc_x.im * kinc_x.im;
    b = kinc_x.re * kinc_x.im;
    varargout_1.im = b + b;
    r1[i] = varargout_1;
  }
  if ((KzT.size(0) != r1.size(0)) &&
      ((KzT.size(0) != 1) && (r1.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(KzT.size(0), r1.size(0), &e_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((KzT.size(1) != r1.size(1)) &&
      ((KzT.size(1) != 1) && (r1.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(KzT.size(1), r1.size(1), &f_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((KzT.size(0) == r1.size(0)) && (KzT.size(1) == r1.size(1))) {
    for (i = 0; i < nv; i++) {
      KzT[i].re = KzT[i].re - r1[i].re;
      KzT[i].im = KzT[i].im - r1[i].im;
    }
  } else {
    minus(sp, KzT, r1);
  }
  st.site = &gb_emlrtRSI;
  coder::b_sqrt(st, KzT);
  nv = KzT.size(0) * KzT.size(1);
  for (i = 0; i < nv; i++) {
    KzT[i].re = KzT[i].re;
    KzT[i].im = -KzT[i].im;
  }
  st.site = &hb_emlrtRSI;
  coder::eye(st, static_cast<real_T>(M.size(1)), b_b);
  KzR.set_size(&mc_emlrtRTEI, &sp, b_b.size(0), b_b.size(1));
  scalarLB = b_b.size(0) * b_b.size(1);
  for (i = 0; i < scalarLB; i++) {
    KzR[i].re = b_b[i] * kinc_x_tmp;
    KzR[i].im = b_b[i] * b_kinc_x_tmp;
  }
  if ((KzR.size(0) != r1.size(0)) &&
      ((KzR.size(0) != 1) && (r1.size(0) != 1))) {
    emlrtDimSizeImpxCheckR2021b(KzR.size(0), r1.size(0), &g_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((KzR.size(1) != r1.size(1)) &&
      ((KzR.size(1) != 1) && (r1.size(1) != 1))) {
    emlrtDimSizeImpxCheckR2021b(KzR.size(1), r1.size(1), &h_emlrtECI,
                                (emlrtConstCTX)&sp);
  }
  if ((KzR.size(0) == r1.size(0)) && (KzR.size(1) == r1.size(1))) {
    for (i = 0; i < scalarLB; i++) {
      KzR[i].re = KzR[i].re - r1[i].re;
      KzR[i].im = KzR[i].im - r1[i].im;
    }
  } else {
    minus(sp, KzR, r1);
  }
  st.site = &hb_emlrtRSI;
  coder::b_sqrt(st, KzR);
  scalarLB = KzR.size(0) * KzR.size(1);
  for (i = 0; i < scalarLB; i++) {
    KzR[i].re = KzR[i].re;
    KzR[i].im = -KzR[i].im;
  }
  for (i = 0; i < scalarLB; i++) {
    KzR[i].re = -KzR[i].re;
    KzR[i].im = -KzR[i].im;
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

// End of code generation (calcK.cpp)
