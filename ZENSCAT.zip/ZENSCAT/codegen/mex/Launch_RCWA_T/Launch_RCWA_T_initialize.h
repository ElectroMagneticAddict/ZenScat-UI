//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Launch_RCWA_T_initialize.h
//
// Code generation for function 'Launch_RCWA_T_initialize'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void Launch_RCWA_T_initialize();

// End of code generation (Launch_RCWA_T_initialize.h)
