//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// lusolve.cpp
//
// Code generation for function 'lusolve'
//

// Include files
#include "lusolve.h"
#include "Launch_RCWA_T_data.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>

// Variable Definitions
static emlrtRTEInfo tg_emlrtRTEI{
    67,        // lineNo
    9,         // colNo
    "lusolve", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m" // pName
};

// Function Definitions
namespace coder {
namespace internal {
void lusolve(const emlrtStack &sp, const array<creal_T, 2U> &A,
             const array<creal_T, 2U> &B, array<creal_T, 2U> &X)
{
  array<ptrdiff_t, 1U> IPIV;
  array<ptrdiff_t, 1U> r;
  array<creal_T, 2U> b_A;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  int32_T ma;
  int32_T mb;
  int32_T na;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  st.site = &ah_emlrtRSI;
  X.set_size(&tg_emlrtRTEI, &st, B.size(0), B.size(1));
  ma = B.size(0) * B.size(1);
  for (mb = 0; mb < ma; mb++) {
    X[mb] = B[mb];
  }
  b_st.site = &bh_emlrtRSI;
  c_st.site = &dh_emlrtRSI;
  ma = A.size(0);
  na = A.size(1);
  mb = B.size(0);
  ma = muIntScalarMin_sint32(ma, na);
  na = muIntScalarMin_sint32(mb, ma);
  d_st.site = &eh_emlrtRSI;
  b_A.set_size(&ug_emlrtRTEI, &d_st, A.size(0), A.size(1));
  ma = A.size(0) * A.size(1);
  for (mb = 0; mb < ma; mb++) {
    b_A[mb] = A[mb];
  }
  ma = 0;
  if ((na != 0) && (B.size(1) != 0)) {
    ptrdiff_t INFO;
    ptrdiff_t LDA;
    ptrdiff_t N;
    e_st.site = &gh_emlrtRSI;
    N = (ptrdiff_t)0.0;
    r.set_size(&wg_emlrtRTEI, &e_st, na);
    for (mb = 0; mb < na; mb++) {
      r[mb] = N;
    }
    IPIV.set_size(&vg_emlrtRTEI, &d_st, r.size(0));
    N = (ptrdiff_t)na;
    LDA = (ptrdiff_t)b_A.size(0);
    INFO = LAPACKE_zgetrf_work(102, N, N,
                               (lapack_complex_double *)&(b_A.data())[0], LDA,
                               &(IPIV.data())[0]);
    ma = (int32_T)INFO;
    e_st.site = &fh_emlrtRSI;
    if ((int32_T)INFO < 0) {
      if ((int32_T)INFO == -1010) {
        emlrtErrorWithMessageIdR2018a(&e_st, &j_emlrtRTEI, "MATLAB:nomem",
                                      "MATLAB:nomem", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&e_st, &i_emlrtRTEI,
                                      "Coder:toolbox:LAPACKCallErrorInfo",
                                      "Coder:toolbox:LAPACKCallErrorInfo", 5, 4,
                                      19, &cv[0], 12, (int32_T)INFO);
      }
    }
    LAPACKE_zgetrs_work(
        102, 'N', N, (ptrdiff_t)B.size(1),
        (lapack_complex_double *)&(b_A.data())[0], LDA, &(IPIV.data())[0],
        (lapack_complex_double *)&(X.data())[0], (ptrdiff_t)B.size(0));
  }
  if (((A.size(0) != 1) || (A.size(1) != 1)) && (ma > 0)) {
    b_st.site = &ch_emlrtRSI;
    c_st.site = &nh_emlrtRSI;
    c_warning(c_st);
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace internal
} // namespace coder

// End of code generation (lusolve.cpp)
