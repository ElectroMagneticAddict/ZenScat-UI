//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// mrdivide_helper.cpp
//
// Code generation for function 'mrdivide_helper'
//

// Include files
#include "mrdivide_helper.h"
#include "Launch_RCWA_T_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "blas.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>

// Variable Definitions
static emlrtRSInfo ih_emlrtRSI{
    27,       // lineNo
    "xgetrf", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" // pathName
};

static emlrtRSInfo jh_emlrtRSI{
    91,             // lineNo
    "ceval_xgetrf", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" // pathName
};

static emlrtRSInfo kh_emlrtRSI{
    58,             // lineNo
    "ceval_xgetrf", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" // pathName
};

static emlrtRSInfo lh_emlrtRSI{
    67,      // lineNo
    "xtrsm", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\xtrsm."
    "m" // pathName
};

static emlrtRSInfo xi_emlrtRSI{
    42,      // lineNo
    "mrdiv", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pathName
};

static emlrtRSInfo yi_emlrtRSI{
    44,      // lineNo
    "mrdiv", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pathName
};

static emlrtRSInfo aj_emlrtRSI{
    107,          // lineNo
    "lusolveNxN", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m" // pathName
};

static emlrtRSInfo bj_emlrtRSI{
    135,          // lineNo
    "XtimesInvA", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m" // pathName
};

static emlrtRSInfo cj_emlrtRSI{
    140,          // lineNo
    "XtimesInvA", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m" // pathName
};

static emlrtRSInfo dj_emlrtRSI{
    142,          // lineNo
    "XtimesInvA", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m" // pathName
};

static emlrtRSInfo ej_emlrtRSI{
    147,          // lineNo
    "XtimesInvA", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m" // pathName
};

static emlrtRTEInfo dh_emlrtRTEI{
    44,                // lineNo
    32,                // colNo
    "mrdivide_helper", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pName
};

static emlrtRTEInfo eh_emlrtRTEI{
    44,                // lineNo
    35,                // colNo
    "mrdivide_helper", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pName
};

static emlrtRTEInfo fh_emlrtRTEI{
    44,                // lineNo
    5,                 // colNo
    "mrdivide_helper", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pName
};

static emlrtRTEInfo gh_emlrtRTEI{
    42,                // lineNo
    5,                 // colNo
    "mrdivide_helper", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pName
};

static emlrtRTEInfo hh_emlrtRTEI{
    1,        // lineNo
    37,       // colNo
    "xgetrf", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" // pName
};

static emlrtRTEInfo ih_emlrtRTEI{
    58,       // lineNo
    29,       // colNo
    "xgetrf", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" // pName
};

static emlrtRTEInfo jh_emlrtRTEI{
    89,       // lineNo
    27,       // colNo
    "xgetrf", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgetrf.m" // pName
};

static emlrtRTEInfo kh_emlrtRTEI{
    31,                // lineNo
    5,                 // colNo
    "mrdivide_helper", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_"
    "helper.m" // pName
};

// Function Definitions
namespace coder {
namespace internal {
void mrdiv(const emlrtStack &sp, const array<creal_T, 2U> &A,
           const array<creal_T, 2U> &B, array<creal_T, 2U> &Y)
{
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  array<ptrdiff_t, 1U> ipiv_t;
  array<ptrdiff_t, 1U> r;
  array<creal_T, 2U> b_A;
  array<creal_T, 2U> b_B;
  array<creal_T, 2U> c_A;
  array<int32_T, 2U> ipiv;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack st;
  char_T DIAGA1;
  char_T SIDE1;
  char_T TRANSA1;
  char_T UPLO1;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if ((A.size(0) == 0) || (A.size(1) == 0) ||
      ((B.size(0) == 0) || (B.size(1) == 0))) {
    int32_T loop_ub;
    Y.set_size(&kh_emlrtRTEI, &sp, A.size(0), B.size(0));
    loop_ub = A.size(0) * B.size(0);
    for (int32_T i{0}; i < loop_ub; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
  } else if (B.size(0) == B.size(1)) {
    ptrdiff_t info_t;
    int32_T i;
    int32_T loop_ub;
    int32_T n;
    st.site = &xi_emlrtRSI;
    b_st.site = &ah_emlrtRSI;
    Y.set_size(&gh_emlrtRTEI, &b_st, A.size(0), A.size(1));
    loop_ub = A.size(0) * A.size(1);
    for (i = 0; i < loop_ub; i++) {
      Y[i] = A[i];
    }
    c_st.site = &aj_emlrtRSI;
    n = B.size(1);
    d_st.site = &bj_emlrtRSI;
    c_A.set_size(&hh_emlrtRTEI, &d_st, B.size(0), B.size(1));
    loop_ub = B.size(0) * B.size(1);
    for (i = 0; i < loop_ub; i++) {
      c_A[i] = B[i];
    }
    e_st.site = &ih_emlrtRSI;
    f_st.site = &kh_emlrtRSI;
    info_t = (ptrdiff_t)0.0;
    n = muIntScalarMin_sint32(n, n);
    r.set_size(&wg_emlrtRTEI, &f_st, n);
    for (i = 0; i < n; i++) {
      r[i] = info_t;
    }
    ipiv_t.set_size(&ih_emlrtRTEI, &e_st, r.size(0));
    info_t =
        LAPACKE_zgetrf_work(102, (ptrdiff_t)B.size(1), (ptrdiff_t)B.size(1),
                            (lapack_complex_double *)&(c_A.data())[0],
                            (ptrdiff_t)B.size(1), &(ipiv_t.data())[0]);
    ipiv.set_size(&jh_emlrtRTEI, &e_st, 1, ipiv_t.size(0));
    f_st.site = &jh_emlrtRSI;
    if ((int32_T)info_t < 0) {
      if ((int32_T)info_t == -1010) {
        emlrtErrorWithMessageIdR2018a(&f_st, &j_emlrtRTEI, "MATLAB:nomem",
                                      "MATLAB:nomem", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&f_st, &i_emlrtRTEI,
                                      "Coder:toolbox:LAPACKCallErrorInfo",
                                      "Coder:toolbox:LAPACKCallErrorInfo", 5, 4,
                                      19, &cv[0], 12, (int32_T)info_t);
      }
    }
    i = ipiv_t.size(0) - 1;
    for (n = 0; n <= i; n++) {
      ipiv[n] = (int32_T)ipiv_t[n];
    }
    n = Y.size(0);
    d_st.site = &cj_emlrtRSI;
    e_st.site = &lh_emlrtRSI;
    DIAGA1 = 'N';
    TRANSA1 = 'N';
    UPLO1 = 'U';
    SIDE1 = 'R';
    m_t = (ptrdiff_t)Y.size(0);
    n_t = (ptrdiff_t)B.size(1);
    lda_t = (ptrdiff_t)B.size(1);
    ldb_t = (ptrdiff_t)Y.size(0);
    ztrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, (real_T *)&dc1,
          (real_T *)&(c_A.data())[0], &lda_t, (real_T *)&(Y.data())[0], &ldb_t);
    d_st.site = &dj_emlrtRSI;
    e_st.site = &lh_emlrtRSI;
    DIAGA1 = 'U';
    TRANSA1 = 'N';
    UPLO1 = 'L';
    SIDE1 = 'R';
    m_t = (ptrdiff_t)Y.size(0);
    n_t = (ptrdiff_t)B.size(1);
    lda_t = (ptrdiff_t)B.size(1);
    ldb_t = (ptrdiff_t)Y.size(0);
    ztrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, (real_T *)&dc1,
          (real_T *)&(c_A.data())[0], &lda_t, (real_T *)&(Y.data())[0], &ldb_t);
    i = B.size(1) - 1;
    for (loop_ub = i; loop_ub >= 1; loop_ub--) {
      int32_T i1;
      i1 = ipiv[loop_ub - 1];
      if (i1 != loop_ub) {
        d_st.site = &ej_emlrtRSI;
        if (n > 2147483646) {
          e_st.site = &kc_emlrtRSI;
          check_forloop_overflow_error(e_st);
        }
        for (int32_T b_i{0}; b_i < n; b_i++) {
          real_T temp_im;
          real_T temp_re;
          temp_re = Y[b_i + Y.size(0) * (loop_ub - 1)].re;
          temp_im = Y[b_i + Y.size(0) * (loop_ub - 1)].im;
          Y[b_i + Y.size(0) * (loop_ub - 1)] = Y[b_i + Y.size(0) * (i1 - 1)];
          Y[b_i + Y.size(0) * (i1 - 1)].re = temp_re;
          Y[b_i + Y.size(0) * (i1 - 1)].im = temp_im;
        }
      }
    }
    if (((B.size(0) != 1) || (B.size(1) != 1)) && ((int32_T)info_t > 0)) {
      c_st.site = &ch_emlrtRSI;
      d_st.site = &nh_emlrtRSI;
      c_warning(d_st);
    }
  } else {
    int32_T loop_ub;
    int32_T n;
    b_B.set_size(&dh_emlrtRTEI, &sp, B.size(1), B.size(0));
    loop_ub = B.size(0);
    n = B.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      for (int32_T i1{0}; i1 < n; i1++) {
        b_B[i1 + b_B.size(0) * i].re = B[i + B.size(0) * i1].re;
        b_B[i1 + b_B.size(0) * i].im = -B[i + B.size(0) * i1].im;
      }
    }
    b_A.set_size(&eh_emlrtRTEI, &sp, A.size(1), A.size(0));
    loop_ub = A.size(0);
    n = A.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      for (int32_T i1{0}; i1 < n; i1++) {
        b_A[i1 + b_A.size(0) * i].re = A[i + A.size(0) * i1].re;
        b_A[i1 + b_A.size(0) * i].im = -A[i + A.size(0) * i1].im;
      }
    }
    st.site = &yi_emlrtRSI;
    qrsolve(st, b_B, b_A, c_A);
    Y.set_size(&fh_emlrtRTEI, &sp, c_A.size(1), c_A.size(0));
    loop_ub = c_A.size(0);
    for (int32_T i{0}; i < loop_ub; i++) {
      n = c_A.size(1);
      for (int32_T i1{0}; i1 < n; i1++) {
        Y[i1 + Y.size(0) * i].re = c_A[i + c_A.size(0) * i1].re;
        Y[i1 + Y.size(0) * i].im = -c_A[i + c_A.size(0) * i1].im;
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace internal
} // namespace coder

// End of code generation (mrdivide_helper.cpp)
