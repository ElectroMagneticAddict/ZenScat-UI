//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// schur.cpp
//
// Code generation for function 'schur'
//

// Include files
#include "schur.h"
#include "Launch_RCWA_T_data.h"
#include "anyNonFinite.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>

// Variable Definitions
static emlrtRSInfo qe_emlrtRSI{
    35,      // lineNo
    "schur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pathName
};

static emlrtRSInfo re_emlrtRSI{
    43,      // lineNo
    "schur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pathName
};

static emlrtRSInfo se_emlrtRSI{
    66,      // lineNo
    "schur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pathName
};

static emlrtRSInfo te_emlrtRSI{
    77,      // lineNo
    "schur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pathName
};

static emlrtRSInfo ue_emlrtRSI{
    78,      // lineNo
    "schur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pathName
};

static emlrtRSInfo ve_emlrtRSI{
    83,      // lineNo
    "schur", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pathName
};

static emlrtRSInfo we_emlrtRSI{
    48,     // lineNo
    "triu", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\elmat\\triu.m" // pathName
};

static emlrtRSInfo xe_emlrtRSI{
    47,     // lineNo
    "triu", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\elmat\\triu.m" // pathName
};

static emlrtRSInfo ye_emlrtRSI{
    15,       // lineNo
    "xgehrd", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" // pathName
};

static emlrtRSInfo af_emlrtRSI{
    85,             // lineNo
    "ceval_xgehrd", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" // pathName
};

static emlrtRSInfo bf_emlrtRSI{
    72,                // lineNo
    "ceval_xungorghr", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xungorghr.m" // pathName
};

static emlrtRSInfo cf_emlrtRSI{
    11,          // lineNo
    "xungorghr", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xungorghr.m" // pathName
};

static emlrtRSInfo df_emlrtRSI{
    17,       // lineNo
    "xhseqr", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xhseqr.m" // pathName
};

static emlrtRSInfo ef_emlrtRSI{
    128,            // lineNo
    "ceval_xhseqr", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xhseqr.m" // pathName
};

static emlrtRTEInfo o_emlrtRTEI{
    18,      // lineNo
    15,      // colNo
    "schur", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pName
};

static emlrtRTEInfo tf_emlrtRTEI{
    1,        // lineNo
    27,       // colNo
    "xgehrd", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" // pName
};

static emlrtRTEInfo uf_emlrtRTEI{
    76,       // lineNo
    22,       // colNo
    "xgehrd", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" // pName
};

static emlrtRTEInfo vf_emlrtRTEI{
    86,       // lineNo
    9,        // colNo
    "xgehrd", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" // pName
};

static emlrtRTEInfo wf_emlrtRTEI{
    87,       // lineNo
    9,        // colNo
    "xgehrd", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgehrd.m" // pName
};

static emlrtRTEInfo xf_emlrtRTEI{
    77,      // lineNo
    9,       // colNo
    "schur", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pName
};

static emlrtRTEInfo yf_emlrtRTEI{
    101,      // lineNo
    28,       // colNo
    "xhseqr", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xhseqr.m" // pName
};

static emlrtRTEInfo ag_emlrtRTEI{
    129,      // lineNo
    9,        // colNo
    "xhseqr", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xhseqr.m" // pName
};

static emlrtRTEInfo bg_emlrtRTEI{
    130,      // lineNo
    9,        // colNo
    "xhseqr", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xhseqr.m" // pName
};

static emlrtRTEInfo cg_emlrtRTEI{
    42,      // lineNo
    9,       // colNo
    "schur", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pName
};

static emlrtRTEInfo dg_emlrtRTEI{
    46,      // lineNo
    9,       // colNo
    "schur", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m" // pName
};

// Function Definitions
namespace coder {
void schur(const emlrtStack &sp, const array<creal_T, 2U> &A,
           array<creal_T, 2U> &V, array<creal_T, 2U> &T)
{
  static const char_T b_fname[14]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                  '_', 'z', 'u', 'n', 'g', 'h', 'r'};
  static const char_T c_fname[14]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                  '_', 'z', 'h', 's', 'e', 'q', 'r'};
  static const char_T fname[14]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                '_', 'z', 'g', 'e', 'h', 'r', 'd'};
  array<creal_T, 2U> w;
  array<creal_T, 1U> tau;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (A.size(0) != A.size(1)) {
    emlrtErrorWithMessageIdR2018a(&sp, &o_emlrtRTEI, "Coder:MATLAB:square",
                                  "Coder:MATLAB:square", 0);
  }
  st.site = &qe_emlrtRSI;
  if (internal::anyNonFinite(st, A)) {
    int32_T istart;
    int32_T loop_ub_tmp;
    int32_T n;
    V.set_size(&cg_emlrtRTEI, &sp, A.size(0), A.size(1));
    loop_ub_tmp = A.size(0) * A.size(1);
    for (istart = 0; istart < loop_ub_tmp; istart++) {
      V[istart].re = rtNaN;
      V[istart].im = 0.0;
    }
    st.site = &re_emlrtRSI;
    n = V.size(0);
    if ((V.size(0) != 0) && (V.size(1) != 0) && (V.size(0) > 1)) {
      int32_T jend;
      istart = 2;
      if (V.size(0) - 2 < V.size(1) - 1) {
        jend = V.size(0) - 1;
      } else {
        jend = V.size(1);
      }
      b_st.site = &xe_emlrtRSI;
      for (int32_T j{0}; j < jend; j++) {
        b_st.site = &we_emlrtRSI;
        if ((istart <= n) && (n > 2147483646)) {
          c_st.site = &kc_emlrtRSI;
          check_forloop_overflow_error(c_st);
        }
        for (int32_T i{istart}; i <= n; i++) {
          V[(i + V.size(0) * j) - 1].re = 0.0;
          V[(i + V.size(0) * j) - 1].im = 0.0;
        }
        istart++;
      }
    }
    T.set_size(&dg_emlrtRTEI, &sp, A.size(0), A.size(1));
    for (istart = 0; istart < loop_ub_tmp; istart++) {
      T[istart].re = rtNaN;
      T[istart].im = 0.0;
    }
  } else {
    ptrdiff_t info_t;
    int32_T istart;
    int32_T jend;
    int32_T n;
    boolean_T b_p;
    boolean_T p;
    st.site = &se_emlrtRSI;
    T.set_size(&tf_emlrtRTEI, &st, A.size(0), A.size(1));
    n = A.size(0) * A.size(1);
    for (istart = 0; istart < n; istart++) {
      T[istart] = A[istart];
    }
    b_st.site = &ye_emlrtRSI;
    n = T.size(0);
    if (T.size(0) < 1) {
      jend = 0;
    } else {
      jend = T.size(0) - 1;
    }
    tau.set_size(&uf_emlrtRTEI, &b_st, jend);
    if (T.size(0) > 1) {
      info_t = LAPACKE_zgehrd(102, (ptrdiff_t)T.size(0), (ptrdiff_t)1,
                              (ptrdiff_t)T.size(0),
                              (lapack_complex_double *)&(T.data())[0],
                              (ptrdiff_t)muIntScalarMax_sint32(1, n),
                              (lapack_complex_double *)&(tau.data())[0]);
      c_st.site = &af_emlrtRSI;
      if ((int32_T)info_t != 0) {
        p = true;
        if ((int32_T)info_t != -5) {
          if ((int32_T)info_t == -1010) {
            emlrtErrorWithMessageIdR2018a(&c_st, &j_emlrtRTEI, "MATLAB:nomem",
                                          "MATLAB:nomem", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(
                &c_st, &i_emlrtRTEI, "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, &fname[0], 12,
                (int32_T)info_t);
          }
        }
      } else {
        p = false;
      }
      if (p) {
        n = T.size(0);
        istart = T.size(1);
        T.set_size(&vf_emlrtRTEI, &b_st, n, istart);
        n *= istart;
        for (istart = 0; istart < n; istart++) {
          T[istart].re = rtNaN;
          T[istart].im = 0.0;
        }
        n = tau.size(0);
        tau.set_size(&wf_emlrtRTEI, &b_st, n);
        for (istart = 0; istart < n; istart++) {
          tau[istart].re = rtNaN;
          tau[istart].im = 0.0;
        }
      }
    }
    st.site = &te_emlrtRSI;
    V.set_size(&xf_emlrtRTEI, &st, T.size(0), T.size(1));
    n = T.size(0) * T.size(1);
    for (istart = 0; istart < n; istart++) {
      V[istart] = T[istart];
    }
    b_st.site = &cf_emlrtRSI;
    if (A.size(0) != 0) {
      if (A.size(0) == 1) {
        V[0].re = 1.0;
        V[0].im = 0.0;
      } else {
        info_t = LAPACKE_zunghr(
            102, (ptrdiff_t)A.size(0), (ptrdiff_t)1, (ptrdiff_t)A.size(0),
            (lapack_complex_double *)&(V.data())[0], (ptrdiff_t)A.size(0),
            (lapack_complex_double *)&(tau.data())[0]);
        c_st.site = &bf_emlrtRSI;
        if ((int32_T)info_t != 0) {
          p = true;
          b_p = false;
          if ((int32_T)info_t == -5) {
            b_p = true;
          } else if ((int32_T)info_t == -7) {
            b_p = true;
          }
          if (!b_p) {
            if ((int32_T)info_t == -1010) {
              emlrtErrorWithMessageIdR2018a(&c_st, &j_emlrtRTEI, "MATLAB:nomem",
                                            "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(
                  &c_st, &i_emlrtRTEI, "Coder:toolbox:LAPACKCallErrorInfo",
                  "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, &b_fname[0],
                  12, (int32_T)info_t);
            }
          }
        } else {
          p = false;
        }
        if (p) {
          n = V.size(0);
          istart = V.size(1);
          V.set_size(&xf_emlrtRTEI, &b_st, n, istart);
          n *= istart;
          for (istart = 0; istart < n; istart++) {
            V[istart].re = rtNaN;
            V[istart].im = 0.0;
          }
        }
      }
    }
    st.site = &ue_emlrtRSI;
    b_st.site = &df_emlrtRSI;
    n = T.size(0);
    info_t = (ptrdiff_t)T.size(0);
    if ((T.size(0) != 0) && (T.size(1) != 0)) {
      w.set_size(&yf_emlrtRTEI, &b_st, 1, T.size(0));
      info_t = LAPACKE_zhseqr(102, 'S', 'V', info_t, (ptrdiff_t)1,
                              (ptrdiff_t)T.size(0),
                              (lapack_complex_double *)&(T.data())[0], info_t,
                              (lapack_complex_double *)&w[0],
                              (lapack_complex_double *)&(V.data())[0],
                              (ptrdiff_t)muIntScalarMax_sint32(1, n));
      jend = (int32_T)info_t;
      c_st.site = &ef_emlrtRSI;
      if ((int32_T)info_t < 0) {
        p = true;
        b_p = false;
        if ((int32_T)info_t == -7) {
          b_p = true;
        } else if ((int32_T)info_t == -10) {
          b_p = true;
        }
        if (!b_p) {
          if ((int32_T)info_t == -1010) {
            emlrtErrorWithMessageIdR2018a(&c_st, &j_emlrtRTEI, "MATLAB:nomem",
                                          "MATLAB:nomem", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(
                &c_st, &i_emlrtRTEI, "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, &c_fname[0], 12,
                (int32_T)info_t);
          }
        }
      } else {
        p = false;
      }
      if (p) {
        n = T.size(0);
        istart = T.size(1);
        T.set_size(&ag_emlrtRTEI, &b_st, n, istart);
        n *= istart;
        for (istart = 0; istart < n; istart++) {
          T[istart].re = rtNaN;
          T[istart].im = 0.0;
        }
        n = V.size(0);
        istart = V.size(1);
        V.set_size(&bg_emlrtRTEI, &b_st, n, istart);
        n *= istart;
        for (istart = 0; istart < n; istart++) {
          V[istart].re = rtNaN;
          V[istart].im = 0.0;
        }
      }
    } else {
      jend = 0;
    }
    if (jend != 0) {
      st.site = &ve_emlrtRSI;
      internal::b_warning(st);
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace coder

// End of code generation (schur.cpp)
