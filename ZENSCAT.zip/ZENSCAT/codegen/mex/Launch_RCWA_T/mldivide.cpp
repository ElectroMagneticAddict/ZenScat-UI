//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// mldivide.cpp
//
// Code generation for function 'mldivide'
//

// Include files
#include "mldivide.h"
#include "Launch_RCWA_T_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "infocheck.h"
#include "lusolve.h"
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xgeqp3.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>

// Variable Definitions
static emlrtRSInfo sh_emlrtRSI{
    20,         // lineNo
    "mldivide", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pathName
};

static emlrtRSInfo th_emlrtRSI{
    42,      // lineNo
    "mldiv", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pathName
};

static emlrtRSInfo uh_emlrtRSI{
    44,      // lineNo
    "mldiv", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pathName
};

static emlrtRTEInfo q_emlrtRTEI{
    16,         // lineNo
    19,         // colNo
    "mldivide", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pName
};

static emlrtRTEInfo xg_emlrtRTEI{
    20,         // lineNo
    5,          // colNo
    "mldivide", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m" // pName
};

// Function Definitions
namespace coder {
void mldivide(const emlrtStack &sp, const array<creal_T, 2U> &A,
              const array<creal_T, 2U> &B, array<creal_T, 2U> &Y)
{
  emlrtStack b_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  if (B.size(0) != A.size(0)) {
    emlrtErrorWithMessageIdR2018a(&sp, &q_emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  st.site = &sh_emlrtRSI;
  if ((A.size(0) == 0) || (A.size(1) == 0) ||
      ((B.size(0) == 0) || (B.size(1) == 0))) {
    int32_T loop_ub;
    Y.set_size(&xg_emlrtRTEI, &st, A.size(1), B.size(1));
    loop_ub = A.size(1) * B.size(1);
    for (int32_T i{0}; i < loop_ub; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    b_st.site = &th_emlrtRSI;
    internal::lusolve(b_st, A, B, Y);
  } else {
    b_st.site = &uh_emlrtRSI;
    internal::qrsolve(b_st, A, B, Y);
  }
}

void mldivide(const emlrtStack &sp, const array<creal_T, 2U> &A,
              const array<creal_T, 1U> &B, array<creal_T, 1U> &Y)
{
  array<ptrdiff_t, 1U> IPIV;
  array<ptrdiff_t, 1U> r;
  array<creal_T, 2U> b_A;
  array<creal_T, 1U> b_B;
  array<creal_T, 1U> tau;
  array<int32_T, 2U> jpvt;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (B.size(0) != A.size(0)) {
    emlrtErrorWithMessageIdR2018a(&sp, &q_emlrtRTEI, "MATLAB:dimagree",
                                  "MATLAB:dimagree", 0);
  }
  st.site = &sh_emlrtRSI;
  if ((A.size(0) == 0) || (A.size(1) == 0) || (B.size(0) == 0)) {
    int32_T na;
    Y.set_size(&xg_emlrtRTEI, &st, A.size(1));
    na = A.size(1);
    for (int32_T i{0}; i < na; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    ptrdiff_t INFO;
    ptrdiff_t LDA;
    ptrdiff_t nrc_t;
    int32_T i;
    int32_T ma;
    int32_T na;
    b_st.site = &th_emlrtRSI;
    c_st.site = &ah_emlrtRSI;
    Y.set_size(&xg_emlrtRTEI, &c_st, B.size(0));
    na = B.size(0);
    for (i = 0; i < na; i++) {
      Y[i] = B[i];
    }
    int32_T mb;
    d_st.site = &bh_emlrtRSI;
    e_st.site = &dh_emlrtRSI;
    ma = A.size(0);
    na = A.size(1);
    mb = B.size(0);
    i = muIntScalarMin_sint32(ma, na);
    ma = muIntScalarMin_sint32(mb, i);
    f_st.site = &eh_emlrtRSI;
    b_A.set_size(&ug_emlrtRTEI, &f_st, A.size(0), A.size(1));
    na = A.size(0) * A.size(1);
    for (i = 0; i < na; i++) {
      b_A[i] = A[i];
    }
    g_st.site = &gh_emlrtRSI;
    nrc_t = (ptrdiff_t)0.0;
    r.set_size(&wg_emlrtRTEI, &g_st, ma);
    for (i = 0; i < ma; i++) {
      r[i] = nrc_t;
    }
    IPIV.set_size(&vg_emlrtRTEI, &f_st, r.size(0));
    nrc_t = (ptrdiff_t)ma;
    LDA = (ptrdiff_t)b_A.size(0);
    INFO = LAPACKE_zgetrf_work(102, nrc_t, nrc_t,
                               (lapack_complex_double *)&(b_A.data())[0], LDA,
                               &(IPIV.data())[0]);
    g_st.site = &fh_emlrtRSI;
    if ((int32_T)INFO < 0) {
      if ((int32_T)INFO == -1010) {
        emlrtErrorWithMessageIdR2018a(&g_st, &j_emlrtRTEI, "MATLAB:nomem",
                                      "MATLAB:nomem", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&g_st, &i_emlrtRTEI,
                                      "Coder:toolbox:LAPACKCallErrorInfo",
                                      "Coder:toolbox:LAPACKCallErrorInfo", 5, 4,
                                      19, &cv[0], 12, (int32_T)INFO);
      }
    }
    LAPACKE_zgetrs_work(
        102, 'N', nrc_t, (ptrdiff_t)1,
        (lapack_complex_double *)&(b_A.data())[0], LDA, &(IPIV.data())[0],
        (lapack_complex_double *)&(Y.data())[0], (ptrdiff_t)B.size(0));
    if (((A.size(0) != 1) || (A.size(1) != 1)) && ((int32_T)INFO > 0)) {
      d_st.site = &ch_emlrtRSI;
      e_st.site = &nh_emlrtRSI;
      internal::c_warning(e_st);
    }
  } else {
    int32_T i;
    int32_T ma;
    int32_T mb;
    int32_T na;
    b_st.site = &uh_emlrtRSI;
    b_A.set_size(&yg_emlrtRTEI, &b_st, A.size(0), A.size(1));
    na = A.size(0) * A.size(1);
    for (i = 0; i < na; i++) {
      b_A[i] = A[i];
    }
    c_st.site = &vh_emlrtRSI;
    internal::lapack::xgeqp3(c_st, b_A, tau, jpvt);
    c_st.site = &wh_emlrtRSI;
    mb = internal::rankFromQR(c_st, b_A);
    c_st.site = &xh_emlrtRSI;
    b_B.set_size(&ah_emlrtRTEI, &c_st, B.size(0));
    na = B.size(0);
    for (i = 0; i < na; i++) {
      b_B[i] = B[i];
    }
    Y.set_size(&xg_emlrtRTEI, &c_st, b_A.size(1));
    na = b_A.size(1);
    for (i = 0; i < na; i++) {
      Y[i].re = 0.0;
      Y[i].im = 0.0;
    }
    d_st.site = &ki_emlrtRSI;
    e_st.site = &oi_emlrtRSI;
    if ((b_A.size(0) != 0) && (b_A.size(1) != 0)) {
      ptrdiff_t nrc_t;
      nrc_t = (ptrdiff_t)b_B.size(0);
      i = b_A.size(0);
      na = b_A.size(1);
      nrc_t = LAPACKE_zunmqr(102, 'L', 'C', nrc_t, (ptrdiff_t)1,
                             (ptrdiff_t)muIntScalarMin_sint32(i, na),
                             (lapack_complex_double *)&(b_A.data())[0],
                             (ptrdiff_t)b_A.size(0),
                             (lapack_complex_double *)&(tau.data())[0],
                             (lapack_complex_double *)&(b_B.data())[0], nrc_t);
      f_st.site = &pi_emlrtRSI;
      if (internal::lapack::infocheck(f_st, (int32_T)nrc_t)) {
        ma = b_B.size(0);
        b_B.set_size(&ch_emlrtRTEI, &e_st, ma);
        for (i = 0; i < ma; i++) {
          b_B[i].re = rtNaN;
          b_B[i].im = 0.0;
        }
      }
    }
    d_st.site = &mi_emlrtRSI;
    if (mb > 2147483646) {
      e_st.site = &kc_emlrtRSI;
      check_forloop_overflow_error(e_st);
    }
    for (ma = 0; ma < mb; ma++) {
      Y[jpvt[ma] - 1] = b_B[ma];
    }
    for (na = mb; na >= 1; na--) {
      real_T ai;
      real_T ar;
      real_T bi;
      real_T br;
      real_T brm;
      real_T im;
      real_T re;
      real_T sgnbr;
      i = jpvt[na - 1];
      ar = Y[i - 1].re;
      ai = Y[i - 1].im;
      br = b_A[(na + b_A.size(0) * (na - 1)) - 1].re;
      bi = b_A[(na + b_A.size(0) * (na - 1)) - 1].im;
      if (bi == 0.0) {
        if (ai == 0.0) {
          re = ar / br;
          im = 0.0;
        } else if (ar == 0.0) {
          re = 0.0;
          im = ai / br;
        } else {
          re = ar / br;
          im = ai / br;
        }
      } else if (br == 0.0) {
        if (ar == 0.0) {
          re = ai / bi;
          im = 0.0;
        } else if (ai == 0.0) {
          re = 0.0;
          im = -(ar / bi);
        } else {
          re = ai / bi;
          im = -(ar / bi);
        }
      } else {
        brm = muDoubleScalarAbs(br);
        im = muDoubleScalarAbs(bi);
        if (brm > im) {
          brm = bi / br;
          im = br + brm * bi;
          re = (ar + brm * ai) / im;
          im = (ai - brm * ar) / im;
        } else if (im == brm) {
          if (br > 0.0) {
            sgnbr = 0.5;
          } else {
            sgnbr = -0.5;
          }
          if (bi > 0.0) {
            im = 0.5;
          } else {
            im = -0.5;
          }
          re = (ar * sgnbr + ai * im) / brm;
          im = (ai * sgnbr - ar * im) / brm;
        } else {
          brm = br / bi;
          im = bi + brm * br;
          re = (brm * ar + ai) / im;
          im = (brm * ai - ar) / im;
        }
      }
      Y[i - 1].re = re;
      Y[i - 1].im = im;
      d_st.site = &ni_emlrtRSI;
      for (ma = 0; ma <= na - 2; ma++) {
        im = Y[jpvt[na - 1] - 1].re;
        brm = b_A[ma + b_A.size(0) * (na - 1)].im;
        sgnbr = Y[jpvt[na - 1] - 1].im;
        br = b_A[ma + b_A.size(0) * (na - 1)].re;
        Y[jpvt[ma] - 1].re = Y[jpvt[ma] - 1].re - (im * br - sgnbr * brm);
        Y[jpvt[ma] - 1].im = Y[jpvt[ma] - 1].im - (im * brm + sgnbr * br);
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace coder

// End of code generation (mldivide.cpp)
