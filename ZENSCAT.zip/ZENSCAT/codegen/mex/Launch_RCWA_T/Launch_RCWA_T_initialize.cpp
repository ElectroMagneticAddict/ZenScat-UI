//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Launch_RCWA_T_initialize.cpp
//
// Code generation for function 'Launch_RCWA_T_initialize'
//

// Include files
#include "Launch_RCWA_T_initialize.h"
#include "Launch_RCWA_T_data.h"
#include "_coder_Launch_RCWA_T_mex.h"
#include "rt_nonfinite.h"

// Function Declarations
static void Launch_RCWA_T_once();

// Function Definitions
static void Launch_RCWA_T_once()
{
  mex_InitInfAndNan();
}

void Launch_RCWA_T_initialize()
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2022b(&st);
  emlrtClearAllocCountR2012b(&st, false, 0U, nullptr);
  emlrtEnterRtStackR2012b(&st);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    Launch_RCWA_T_once();
  }
}

// End of code generation (Launch_RCWA_T_initialize.cpp)
