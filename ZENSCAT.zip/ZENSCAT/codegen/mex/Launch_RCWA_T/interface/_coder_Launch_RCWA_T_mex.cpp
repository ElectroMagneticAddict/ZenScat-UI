//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_Launch_RCWA_T_mex.cpp
//
// Code generation for function '_coder_Launch_RCWA_T_mex'
//

// Include files
#include "_coder_Launch_RCWA_T_mex.h"
#include "Launch_RCWA_T_data.h"
#include "Launch_RCWA_T_initialize.h"
#include "Launch_RCWA_T_terminate.h"
#include "_coder_Launch_RCWA_T_api.h"
#include "rt_nonfinite.h"
#include <stdexcept>

void emlrtExceptionBridge();
void emlrtExceptionBridge()
{
  throw std::runtime_error("");
}
// Function Definitions
void Launch_RCWA_T_mexFunction(int32_T nlhs, mxArray *plhs[2], int32_T nrhs,
                               const mxArray *prhs[5])
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  const mxArray *outputs[2];
  int32_T i;
  st.tls = emlrtRootTLSGlobal;
  // Check for proper number of arguments.
  if (nrhs != 5) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:WrongNumberOfInputs", 5, 12, 5, 4,
                        13, "Launch_RCWA_T");
  }
  if (nlhs > 2) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:TooManyOutputArguments", 3, 4, 13,
                        "Launch_RCWA_T");
  }
  // Call the function.
  Launch_RCWA_T_api(prhs, nlhs, outputs);
  // Copy over outputs to the caller.
  if (nlhs < 1) {
    i = 1;
  } else {
    i = nlhs;
  }
  emlrtReturnArrays(i, &plhs[0], &outputs[0]);
}

void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs,
                 const mxArray *prhs[])
{
  mexAtExit(&Launch_RCWA_T_atexit);
  // Module initialization.
  Launch_RCWA_T_initialize();
  try {
    // Dispatch the entry-point.
    Launch_RCWA_T_mexFunction(nlhs, plhs, nrhs, prhs);
    // Module termination.
    Launch_RCWA_T_terminate();
  } catch (...) {
    emlrtCleanupOnException((emlrtCTX *)emlrtRootTLSGlobal);
    throw;
  }
}

emlrtCTX mexFunctionCreateRootTLS()
{
  emlrtCreateRootTLSR2022a(&emlrtRootTLSGlobal, &emlrtContextGlobal, nullptr, 1,
                           (void *)&emlrtExceptionBridge, "windows-1257", true);
  return emlrtRootTLSGlobal;
}

// End of code generation (_coder_Launch_RCWA_T_mex.cpp)
