//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Launch_RCWA_T_data.h
//
// Code generation for function 'Launch_RCWA_T_data'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtContext emlrtContextGlobal;
extern emlrtRSInfo kc_emlrtRSI;
extern emlrtRSInfo oc_emlrtRSI;
extern emlrtRSInfo pc_emlrtRSI;
extern emlrtRSInfo qc_emlrtRSI;
extern emlrtRSInfo sc_emlrtRSI;
extern emlrtRSInfo tc_emlrtRSI;
extern emlrtRSInfo uc_emlrtRSI;
extern emlrtRSInfo vc_emlrtRSI;
extern emlrtRSInfo ld_emlrtRSI;
extern emlrtRSInfo ah_emlrtRSI;
extern emlrtRSInfo bh_emlrtRSI;
extern emlrtRSInfo ch_emlrtRSI;
extern emlrtRSInfo dh_emlrtRSI;
extern emlrtRSInfo eh_emlrtRSI;
extern emlrtRSInfo fh_emlrtRSI;
extern emlrtRSInfo gh_emlrtRSI;
extern emlrtRSInfo nh_emlrtRSI;
extern emlrtRSInfo vh_emlrtRSI;
extern emlrtRSInfo wh_emlrtRSI;
extern emlrtRSInfo xh_emlrtRSI;
extern emlrtRSInfo ki_emlrtRSI;
extern emlrtRSInfo mi_emlrtRSI;
extern emlrtRSInfo ni_emlrtRSI;
extern emlrtRSInfo oi_emlrtRSI;
extern emlrtRSInfo pi_emlrtRSI;
extern emlrtRTEInfo f_emlrtRTEI;
extern emlrtRTEInfo g_emlrtRTEI;
extern emlrtRTEInfo h_emlrtRTEI;
extern emlrtRTEInfo i_emlrtRTEI;
extern emlrtRTEInfo j_emlrtRTEI;
extern emlrtRTEInfo qe_emlrtRTEI;
extern emlrtRTEInfo ug_emlrtRTEI;
extern emlrtRTEInfo vg_emlrtRTEI;
extern emlrtRTEInfo wg_emlrtRTEI;
extern emlrtRTEInfo yg_emlrtRTEI;
extern emlrtRTEInfo ah_emlrtRTEI;
extern emlrtRTEInfo ch_emlrtRTEI;
extern const creal_T dc;
extern const creal_T dc1;
extern const char_T cv[19];

// End of code generation (Launch_RCWA_T_data.h)
