//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// xgeqp3.cpp
//
// Code generation for function 'xgeqp3'
//

// Include files
#include "xgeqp3.h"
#include "Launch_RCWA_T_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <cstddef>
#include <emmintrin.h>

// Variable Definitions
static emlrtRSInfo yh_emlrtRSI{
    63,       // lineNo
    "xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo ai_emlrtRSI{
    98,             // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo bi_emlrtRSI{
    138,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo ci_emlrtRSI{
    141,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo di_emlrtRSI{
    143,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo ei_emlrtRSI{
    148,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo fi_emlrtRSI{
    151,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo gi_emlrtRSI{
    154,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRSInfo hi_emlrtRSI{
    158,            // lineNo
    "ceval_xgeqp3", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pathName
};

static emlrtRTEInfo mh_emlrtRTEI{
    61,       // lineNo
    9,        // colNo
    "xgeqp3", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pName
};

static emlrtRTEInfo nh_emlrtRTEI{
    92,       // lineNo
    22,       // colNo
    "xgeqp3", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pName
};

static emlrtRTEInfo oh_emlrtRTEI{
    105,      // lineNo
    1,        // colNo
    "xgeqp3", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pName
};

static emlrtRTEInfo ph_emlrtRTEI{
    97,       // lineNo
    5,        // colNo
    "xgeqp3", // fName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\eml\\+coder\\+internal\\+"
    "lapack\\xgeqp3.m" // pName
};

// Function Definitions
namespace coder {
namespace internal {
namespace lapack {
void xgeqp3(const emlrtStack &sp, array<creal_T, 2U> &A,
            array<creal_T, 1U> &tau, array<int32_T, 2U> &jpvt)
{
  static const int32_T b_offsets[4]{0, 1, 2, 3};
  static const int32_T offsets[4]{0, 1, 2, 3};
  static const char_T fname[14]{'L', 'A', 'P', 'A', 'C', 'K', 'E',
                                '_', 'z', 'g', 'e', 'q', 'p', '3'};
  array<ptrdiff_t, 1U> jpvt_t;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  int32_T b_na;
  int32_T i;
  int32_T m;
  int32_T ma;
  int32_T minmana;
  int32_T na;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  m = A.size(0);
  na = A.size(1) - 1;
  jpvt.set_size(&mh_emlrtRTEI, &sp, 1, A.size(1));
  b_na = A.size(1);
  for (i = 0; i < b_na; i++) {
    jpvt[i] = 0;
  }
  st.site = &yh_emlrtRSI;
  ma = A.size(0);
  b_na = A.size(1);
  minmana = muIntScalarMin_sint32(ma, b_na);
  tau.set_size(&nh_emlrtRTEI, &st, minmana);
  if ((A.size(0) == 0) || (A.size(1) == 0) || (A.size(0) < 1) ||
      (A.size(1) < 1)) {
    tau.set_size(&ph_emlrtRTEI, &st, minmana);
    for (i = 0; i < minmana; i++) {
      tau[i].re = 0.0;
      tau[i].im = 0.0;
    }
    b_st.site = &ai_emlrtRSI;
    if (A.size(1) > 2147483646) {
      c_st.site = &kc_emlrtRSI;
      check_forloop_overflow_error(c_st);
    }
    b_na = ((na + 1) / 4) << 2;
    m = b_na - 4;
    for (ma = 0; ma <= m; ma += 4) {
      __m128i r;
      r = _mm_add_epi32(
          _mm_add_epi32(_mm_set1_epi32(ma),
                        _mm_loadu_si128((const __m128i *)&offsets[0])),
          _mm_set1_epi32(1));
      _mm_storeu_si128((__m128i *)&jpvt[ma], r);
    }
    for (ma = b_na; ma <= na; ma++) {
      jpvt[ma] = ma + 1;
    }
  } else {
    ptrdiff_t info_t;
    boolean_T p;
    jpvt_t.set_size(&oh_emlrtRTEI, &st, A.size(1));
    b_na = A.size(1);
    for (i = 0; i < b_na; i++) {
      jpvt_t[i] = (ptrdiff_t)0;
    }
    info_t = LAPACKE_zgeqp3(102, (ptrdiff_t)A.size(0), (ptrdiff_t)A.size(1),
                            (lapack_complex_double *)&(A.data())[0],
                            (ptrdiff_t)A.size(0), &(jpvt_t.data())[0],
                            (lapack_complex_double *)&(tau.data())[0]);
    b_st.site = &bi_emlrtRSI;
    if ((int32_T)info_t != 0) {
      p = true;
      if ((int32_T)info_t != -4) {
        if ((int32_T)info_t == -1010) {
          emlrtErrorWithMessageIdR2018a(&b_st, &j_emlrtRTEI, "MATLAB:nomem",
                                        "MATLAB:nomem", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI,
                                        "Coder:toolbox:LAPACKCallErrorInfo",
                                        "Coder:toolbox:LAPACKCallErrorInfo", 5,
                                        4, 14, &fname[0], 12, (int32_T)info_t);
        }
      }
    } else {
      p = false;
    }
    if (p) {
      b_st.site = &ci_emlrtRSI;
      if (A.size(1) > 2147483646) {
        c_st.site = &kc_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      for (b_na = 0; b_na <= na; b_na++) {
        b_st.site = &di_emlrtRSI;
        if (m > 2147483646) {
          c_st.site = &kc_emlrtRSI;
          check_forloop_overflow_error(c_st);
        }
        for (int32_T b_i{0}; b_i < m; b_i++) {
          i = b_na * ma + b_i;
          A[i].re = rtNaN;
          A[i].im = 0.0;
        }
      }
      i = na + 1;
      b_na = muIntScalarMin_sint32(m, i);
      b_st.site = &ei_emlrtRSI;
      if (b_na > 2147483646) {
        c_st.site = &kc_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      for (ma = 0; ma < b_na; ma++) {
        tau[ma].re = rtNaN;
        tau[ma].im = 0.0;
      }
      m = b_na + 1;
      b_st.site = &fi_emlrtRSI;
      if ((b_na + 1 <= minmana) && (minmana > 2147483646)) {
        c_st.site = &kc_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      for (ma = m; ma <= minmana; ma++) {
        tau[ma - 1].re = 0.0;
        tau[ma - 1].im = 0.0;
      }
      b_st.site = &gi_emlrtRSI;
      if (A.size(1) > 2147483646) {
        c_st.site = &kc_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      b_na = ((na + 1) / 4) << 2;
      m = b_na - 4;
      for (ma = 0; ma <= m; ma += 4) {
        __m128i r;
        r = _mm_add_epi32(
            _mm_add_epi32(_mm_set1_epi32(ma),
                          _mm_loadu_si128((const __m128i *)&b_offsets[0])),
            _mm_set1_epi32(1));
        _mm_storeu_si128((__m128i *)&jpvt[ma], r);
      }
      for (ma = b_na; ma <= na; ma++) {
        jpvt[ma] = ma + 1;
      }
    } else {
      b_st.site = &hi_emlrtRSI;
      if (A.size(1) > 2147483646) {
        c_st.site = &kc_emlrtRSI;
        check_forloop_overflow_error(c_st);
      }
      for (ma = 0; ma <= na; ma++) {
        jpvt[ma] = (int32_T)jpvt_t[ma];
      }
    }
  }
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace lapack
} // namespace internal
} // namespace coder

// End of code generation (xgeqp3.cpp)
