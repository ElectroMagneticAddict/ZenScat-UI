//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// mpower.cpp
//
// Code generation for function 'mpower'
//

// Include files
#include "mpower.h"
#include "Launch_RCWA_T_data.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Variable Definitions
static emlrtRSInfo rc_emlrtRSI{
    69,                              // lineNo
    "matrix_to_small_integer_power", // fcnName
    "C:\\Program "
    "Files\\MATLAB\\R2023b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\matrix_"
    "to_integer_power.m" // pathName
};

// Function Definitions
namespace coder {
void mpower(const emlrtStack &sp, const array<creal_T, 2U> &a,
            array<creal_T, 2U> &c)
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  if (a.size(0) != a.size(1)) {
    emlrtErrorWithMessageIdR2018a(&sp, &f_emlrtRTEI, "MATLAB:square",
                                  "MATLAB:square", 0);
  }
  st.site = &oc_emlrtRSI;
  b_st.site = &pc_emlrtRSI;
  c_st.site = &qc_emlrtRSI;
  d_st.site = &rc_emlrtRSI;
  e_st.site = &tc_emlrtRSI;
  if (a.size(0) != a.size(1)) {
    boolean_T b;
    b = ((a.size(0) == 1) && (a.size(1) == 1));
    if (b) {
      emlrtErrorWithMessageIdR2018a(
          &e_st, &h_emlrtRTEI, "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&e_st, &g_emlrtRTEI, "MATLAB:innerdim",
                                    "MATLAB:innerdim", 0);
    }
  }
  e_st.site = &sc_emlrtRSI;
  internal::blas::mtimes(e_st, a, a, c);
}

} // namespace coder

// End of code generation (mpower.cpp)
