//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  eigHermitianStandard.cpp
//
//  Code generation for function 'eigHermitianStandard'
//


// Include files
#include "eigHermitianStandard.h"
#include "Launch_RCWA_data.h"
#include "anyNonFinite.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <stddef.h>

// Variable Definitions
static emlrtRSInfo lg_emlrtRSI = { 32, // lineNo
  "eigHermitianStandard",              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHermitianStandard.m"// pathName 
};

static emlrtRSInfo mg_emlrtRSI = { 33, // lineNo
  "eigHermitianStandard",              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHermitianStandard.m"// pathName 
};

static emlrtRSInfo ng_emlrtRSI = { 35, // lineNo
  "schur",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pathName 
};

static emlrtRSInfo og_emlrtRSI = { 43, // lineNo
  "schur",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pathName 
};

static emlrtRSInfo pg_emlrtRSI = { 66, // lineNo
  "schur",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pathName 
};

static emlrtRSInfo qg_emlrtRSI = { 77, // lineNo
  "schur",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pathName 
};

static emlrtRSInfo rg_emlrtRSI = { 78, // lineNo
  "schur",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pathName 
};

static emlrtRSInfo sg_emlrtRSI = { 83, // lineNo
  "schur",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pathName 
};

static emlrtRSInfo tg_emlrtRSI = { 48, // lineNo
  "triu",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elmat\\triu.m"// pathName 
};

static emlrtRSInfo ug_emlrtRSI = { 47, // lineNo
  "triu",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elmat\\triu.m"// pathName 
};

static emlrtRSInfo vg_emlrtRSI = { 15, // lineNo
  "xgehrd",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgehrd.m"// pathName 
};

static emlrtRSInfo wg_emlrtRSI = { 85, // lineNo
  "ceval_xgehrd",                      // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgehrd.m"// pathName 
};

static emlrtRSInfo xg_emlrtRSI = { 69, // lineNo
  "ceval_xungorghr",                   // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xungorghr.m"// pathName 
};

static emlrtRSInfo yg_emlrtRSI = { 11, // lineNo
  "xungorghr",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xungorghr.m"// pathName 
};

static emlrtRSInfo ah_emlrtRSI = { 17, // lineNo
  "xhseqr",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xhseqr.m"// pathName 
};

static emlrtRSInfo bh_emlrtRSI = { 128,// lineNo
  "ceval_xhseqr",                      // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xhseqr.m"// pathName 
};

static emlrtRSInfo ch_emlrtRSI = { 59, // lineNo
  "diagDiagUpperHessNoImag",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHermitianStandard.m"// pathName 
};

static emlrtRSInfo dh_emlrtRSI = { 62, // lineNo
  "diagDiagUpperHessNoImag",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigHermitianStandard.m"// pathName 
};

static emlrtRTEInfo n_emlrtRTEI = { 18,// lineNo
  15,                                  // colNo
  "schur",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pName 
};

static emlrtRTEInfo xe_emlrtRTEI = { 1,// lineNo
  27,                                  // colNo
  "xgehrd",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgehrd.m"// pName 
};

static emlrtRTEInfo ye_emlrtRTEI = { 76,// lineNo
  22,                                  // colNo
  "xgehrd",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgehrd.m"// pName 
};

static emlrtRTEInfo af_emlrtRTEI = { 86,// lineNo
  9,                                   // colNo
  "xgehrd",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgehrd.m"// pName 
};

static emlrtRTEInfo bf_emlrtRTEI = { 87,// lineNo
  9,                                   // colNo
  "xgehrd",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgehrd.m"// pName 
};

static emlrtRTEInfo cf_emlrtRTEI = { 77,// lineNo
  9,                                   // colNo
  "schur",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pName 
};

static emlrtRTEInfo df_emlrtRTEI = { 101,// lineNo
  28,                                  // colNo
  "xhseqr",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xhseqr.m"// pName 
};

static emlrtRTEInfo ef_emlrtRTEI = { 129,// lineNo
  9,                                   // colNo
  "xhseqr",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xhseqr.m"// pName 
};

static emlrtRTEInfo ff_emlrtRTEI = { 130,// lineNo
  9,                                   // colNo
  "xhseqr",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xhseqr.m"// pName 
};

static emlrtRTEInfo gf_emlrtRTEI = { 42,// lineNo
  9,                                   // colNo
  "schur",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pName 
};

static emlrtRTEInfo hf_emlrtRTEI = { 46,// lineNo
  9,                                   // colNo
  "schur",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\schur.m"// pName 
};

// Function Definitions
namespace coder
{
  void eigHermitianStandard(const emlrtStack *sp, const ::coder::array<creal_T,
    2U> &A, ::coder::array<creal_T, 2U> &V, ::coder::array<creal_T, 2U> &D)
  {
    static const char_T b_fname[14] = { 'L', 'A', 'P', 'A', 'C', 'K', 'E', '_',
      'z', 'u', 'n', 'g', 'h', 'r' };

    static const char_T c_fname[14] = { 'L', 'A', 'P', 'A', 'C', 'K', 'E', '_',
      'z', 'h', 's', 'e', 'q', 'r' };

    static const char_T fname[14] = { 'L', 'A', 'P', 'A', 'C', 'K', 'E', '_',
      'z', 'g', 'e', 'h', 'r', 'd' };

    array<creal_T, 2U> w;
    array<creal_T, 1U> tau;
    emlrtStack b_st;
    emlrtStack c_st;
    emlrtStack d_st;
    emlrtStack st;
    int32_T i;
    int32_T j;
    int32_T n;
    st.prev = sp;
    st.tls = sp->tls;
    b_st.prev = &st;
    b_st.tls = st.tls;
    c_st.prev = &b_st;
    c_st.tls = b_st.tls;
    d_st.prev = &c_st;
    d_st.tls = c_st.tls;
    emlrtHeapReferenceStackEnterFcnR2012b(sp);
    st.site = &lg_emlrtRSI;
    if (A.size(0) != A.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &n_emlrtRTEI, "Coder:MATLAB:square",
        "Coder:MATLAB:square", 0);
    }

    b_st.site = &ng_emlrtRSI;
    if (internal::anyNonFinite(&b_st, A)) {
      int32_T istart;
      V.set_size((&gf_emlrtRTEI), (&st), A.size(0), A.size(1));
      n = A.size(0) * A.size(1);
      for (istart = 0; istart < n; istart++) {
        V[istart].re = rtNaN;
        V[istart].im = 0.0;
      }

      b_st.site = &og_emlrtRSI;
      n = V.size(0);
      if ((V.size(0) != 0) && (V.size(1) != 0) && (1 < V.size(0))) {
        int32_T jend;
        istart = 2;
        if (V.size(0) - 2 < V.size(1) - 1) {
          jend = V.size(0) - 1;
        } else {
          jend = V.size(1);
        }

        c_st.site = &ug_emlrtRSI;
        if (jend > 2147483646) {
          d_st.site = &ib_emlrtRSI;
          check_forloop_overflow_error(&d_st);
        }

        for (j = 0; j < jend; j++) {
          c_st.site = &tg_emlrtRSI;
          if ((istart <= n) && (n > 2147483646)) {
            d_st.site = &ib_emlrtRSI;
            check_forloop_overflow_error(&d_st);
          }

          for (i = istart; i <= n; i++) {
            V[(i + V.size(0) * j) - 1].re = 0.0;
            V[(i + V.size(0) * j) - 1].im = 0.0;
          }

          istart++;
        }
      }

      D.set_size((&hf_emlrtRTEI), (&st), A.size(0), A.size(1));
      n = A.size(0) * A.size(1);
      for (istart = 0; istart < n; istart++) {
        D[istart].re = rtNaN;
        D[istart].im = 0.0;
      }
    } else {
      ptrdiff_t info_t;
      int32_T istart;
      int32_T jend;
      boolean_T b_p;
      boolean_T p;
      b_st.site = &pg_emlrtRSI;
      D.set_size((&xe_emlrtRTEI), (&b_st), A.size(0), A.size(1));
      n = A.size(0) * A.size(1);
      for (istart = 0; istart < n; istart++) {
        D[istart] = A[istart];
      }

      c_st.site = &vg_emlrtRSI;
      n = D.size(0);
      if (D.size(0) < 1) {
        jend = 0;
      } else {
        jend = D.size(0) - 1;
      }

      tau.set_size((&ye_emlrtRTEI), (&c_st), jend);
      if (D.size(0) > 1) {
        info_t = LAPACKE_zgehrd(102, (ptrdiff_t)D.size(0), (ptrdiff_t)1,
          (ptrdiff_t)D.size(0), (lapack_complex_double *)&(D.data())[0],
          (ptrdiff_t)muIntScalarMax_sint32(1, n), (lapack_complex_double *)
          &(tau.data())[0]);
        jend = (int32_T)info_t;
        d_st.site = &wg_emlrtRSI;
        if (jend != 0) {
          p = true;
          if (jend != -5) {
            if (jend == -1010) {
              emlrtErrorWithMessageIdR2018a(&d_st, &i_emlrtRTEI, "MATLAB:nomem",
                "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&d_st, &h_emlrtRTEI,
                "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, fname, 12, jend);
            }
          }
        } else {
          p = false;
        }

        if (p) {
          n = D.size(0);
          istart = D.size(1);
          D.set_size((&af_emlrtRTEI), (&c_st), n, istart);
          n *= istart;
          for (istart = 0; istart < n; istart++) {
            D[istart].re = rtNaN;
            D[istart].im = 0.0;
          }

          n = tau.size(0);
          tau.set_size((&bf_emlrtRTEI), (&c_st), n);
          for (istart = 0; istart < n; istart++) {
            tau[istart].re = rtNaN;
            tau[istart].im = 0.0;
          }
        }
      }

      b_st.site = &qg_emlrtRSI;
      V.set_size((&cf_emlrtRTEI), (&b_st), D.size(0), D.size(1));
      n = D.size(0) * D.size(1);
      for (istart = 0; istart < n; istart++) {
        V[istart] = D[istart];
      }

      c_st.site = &yg_emlrtRSI;
      if ((V.size(0) != 0) && (V.size(1) != 0)) {
        info_t = LAPACKE_zunghr(102, (ptrdiff_t)A.size(0), (ptrdiff_t)1,
          (ptrdiff_t)A.size(0), (lapack_complex_double *)&(V.data())[0],
          (ptrdiff_t)A.size(0), (lapack_complex_double *)&(tau.data())[0]);
        jend = (int32_T)info_t;
        d_st.site = &xg_emlrtRSI;
        if (jend != 0) {
          p = true;
          b_p = false;
          if (jend == -5) {
            b_p = true;
          } else {
            if (jend == -7) {
              b_p = true;
            }
          }

          if (!b_p) {
            if (jend == -1010) {
              emlrtErrorWithMessageIdR2018a(&d_st, &i_emlrtRTEI, "MATLAB:nomem",
                "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&d_st, &h_emlrtRTEI,
                "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, b_fname, 12, jend);
            }
          }
        } else {
          p = false;
        }

        if (p) {
          n = V.size(0);
          istart = V.size(1);
          V.set_size((&cf_emlrtRTEI), (&c_st), n, istart);
          n *= istart;
          for (istart = 0; istart < n; istart++) {
            V[istart].re = rtNaN;
            V[istart].im = 0.0;
          }
        }
      }

      b_st.site = &rg_emlrtRSI;
      c_st.site = &ah_emlrtRSI;
      n = D.size(0);
      info_t = (ptrdiff_t)D.size(0);
      if ((D.size(0) != 0) && (D.size(1) != 0)) {
        w.set_size((&df_emlrtRTEI), (&c_st), 1, D.size(0));
        info_t = LAPACKE_zhseqr(102, 'S', 'V', info_t, (ptrdiff_t)1, (ptrdiff_t)
          D.size(0), (lapack_complex_double *)&(D.data())[0], info_t,
          (lapack_complex_double *)&w[0], (lapack_complex_double *)&(V.data())[0],
          (ptrdiff_t)muIntScalarMax_sint32(1, n));
        jend = (int32_T)info_t;
        d_st.site = &bh_emlrtRSI;
        if (jend < 0) {
          p = true;
          b_p = false;
          if (jend == -7) {
            b_p = true;
          } else {
            if (jend == -10) {
              b_p = true;
            }
          }

          if (!b_p) {
            if (jend == -1010) {
              emlrtErrorWithMessageIdR2018a(&d_st, &i_emlrtRTEI, "MATLAB:nomem",
                "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&d_st, &h_emlrtRTEI,
                "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, c_fname, 12, jend);
            }
          }
        } else {
          p = false;
        }

        if (p) {
          n = D.size(0);
          istart = D.size(1);
          D.set_size((&ef_emlrtRTEI), (&c_st), n, istart);
          n *= istart;
          for (istart = 0; istart < n; istart++) {
            D[istart].re = rtNaN;
            D[istart].im = 0.0;
          }

          n = V.size(0);
          istart = V.size(1);
          V.set_size((&ff_emlrtRTEI), (&c_st), n, istart);
          n *= istart;
          for (istart = 0; istart < n; istart++) {
            V[istart].re = rtNaN;
            V[istart].im = 0.0;
          }
        }
      } else {
        jend = 0;
      }

      if (jend != 0) {
        b_st.site = &sg_emlrtRSI;
        internal::b_warning(&b_st);
      }
    }

    st.site = &mg_emlrtRSI;
    n = D.size(0);
    D[0].im = 0.0;
    b_st.site = &ch_emlrtRSI;
    if ((2 <= n) && (n > 2147483646)) {
      c_st.site = &ib_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    for (j = 2; j <= n; j++) {
      D[(j + D.size(0) * (j - 1)) - 1].im = 0.0;
      D[(j + D.size(0) * (j - 2)) - 1].re = 0.0;
      D[(j + D.size(0) * (j - 2)) - 1].im = 0.0;
      b_st.site = &dh_emlrtRSI;
      for (i = 0; i <= j - 2; i++) {
        D[i + D.size(0) * (j - 1)].re = 0.0;
        D[i + D.size(0) * (j - 1)].im = 0.0;
      }
    }

    emlrtHeapReferenceStackLeaveFcnR2012b(sp);
  }
}

// End of code generation (eigHermitianStandard.cpp)
