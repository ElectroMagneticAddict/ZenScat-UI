//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  star.cpp
//
//  Code generation for function 'star'
//


// Include files
#include "star.h"
#include "Launch_RCWA_data.h"
#include "eye.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Variable Definitions
static emlrtRSInfo gi_emlrtRSI = { 6,  // lineNo
  "star",                              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pathName 
};

static emlrtRSInfo hi_emlrtRSI = { 7,  // lineNo
  "star",                              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pathName 
};

static emlrtRSInfo ii_emlrtRSI = { 8,  // lineNo
  "star",                              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pathName 
};

static emlrtRSInfo ji_emlrtRSI = { 9,  // lineNo
  "star",                              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pathName 
};

static emlrtRSInfo ki_emlrtRSI = { 10, // lineNo
  "star",                              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pathName 
};

static emlrtRSInfo li_emlrtRSI = { 11, // lineNo
  "star",                              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pathName 
};

static emlrtECInfo v_emlrtECI = { 2,   // nDims
  6,                                   // lineNo
  14,                                  // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtECInfo w_emlrtECI = { 2,   // nDims
  7,                                   // lineNo
  14,                                  // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtECInfo x_emlrtECI = { 2,   // nDims
  8,                                   // lineNo
  9,                                   // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtECInfo y_emlrtECI = { 2,   // nDims
  11,                                  // lineNo
  9,                                   // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtRTEInfo ag_emlrtRTEI = { 6,// lineNo
  14,                                  // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtRTEInfo bg_emlrtRTEI = { 7,// lineNo
  14,                                  // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtRTEInfo cg_emlrtRTEI = { 8,// lineNo
  1,                                   // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

static emlrtRTEInfo dg_emlrtRTEI = { 11,// lineNo
  1,                                   // colNo
  "star",                              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\star.m"// pName 
};

// Function Definitions
void star(const emlrtStack *sp, const coder::array<creal_T, 2U> &SA_S11, const
          coder::array<creal_T, 2U> &SA_S12, const coder::array<creal_T, 2U>
          &SA_S21, const coder::array<creal_T, 2U> &SA_S22, const coder::array<
          creal_T, 2U> &SB_S11, const coder::array<creal_T, 2U> &SB_S12, const
          coder::array<creal_T, 2U> &SB_S21, const coder::array<creal_T, 2U>
          &SB_S22, coder::array<creal_T, 2U> &S_S11, coder::array<creal_T, 2U>
          &S_S12, coder::array<creal_T, 2U> &S_S21, coder::array<creal_T, 2U>
          &S_S22)
{
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> D;
  coder::array<creal_T, 2U> F;
  coder::array<creal_T, 2U> r1;
  coder::array<real_T, 2U> r;
  emlrtStack b_st;
  emlrtStack st;
  int32_T i;
  int32_T loop_ub;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  //  Redheffer star product
  //  w = warning ('off','all');
  st.site = &gi_emlrtRSI;
  coder::eye(&st, static_cast<real_T>(static_cast<uint32_T>(SA_S12.size(0))), r);
  st.site = &gi_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (SB_S11.size(1) != SA_S22.size(0)) {
    if (((SB_S11.size(0) == 1) && (SB_S11.size(1) == 1)) || ((SA_S22.size(0) ==
          1) && (SA_S22.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, SB_S11, SA_S22, B);
  emlrtSizeEqCheckNDR2012b(r.size(), B.size(), &v_emlrtECI, sp);
  st.site = &gi_emlrtRSI;
  loop_ub = r.size(0) * r.size(1);
  B.set_size((&ag_emlrtRTEI), (&st), r.size(0), r.size(1));
  for (i = 0; i < loop_ub; i++) {
    B[i].re = r[i] - B[i].re;
    B[i].im = 0.0 - B[i].im;
  }

  if (B.size(1) != SA_S12.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, SA_S12, B, D);
  st.site = &hi_emlrtRSI;
  coder::eye(&st, static_cast<real_T>(static_cast<uint32_T>(SA_S12.size(0))), r);
  st.site = &hi_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (SA_S22.size(1) != SB_S11.size(0)) {
    if (((SA_S22.size(0) == 1) && (SA_S22.size(1) == 1)) || ((SB_S11.size(0) ==
          1) && (SB_S11.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, SA_S22, SB_S11, B);
  emlrtSizeEqCheckNDR2012b(r.size(), B.size(), &w_emlrtECI, sp);
  st.site = &hi_emlrtRSI;
  loop_ub = r.size(0) * r.size(1);
  B.set_size((&bg_emlrtRTEI), (&st), r.size(0), r.size(1));
  for (i = 0; i < loop_ub; i++) {
    B[i].re = r[i] - B[i].re;
    B[i].im = 0.0 - B[i].im;
  }

  if (B.size(1) != SB_S21.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, SB_S21, B, F);
  st.site = &ii_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (D.size(1) != SB_S11.size(0)) {
    if (((D.size(0) == 1) && (D.size(1) == 1)) || ((SB_S11.size(0) == 1) &&
         (SB_S11.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, D, SB_S11, B);
  st.site = &ii_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (B.size(1) != SA_S21.size(0)) {
    if (((B.size(0) == 1) && (B.size(1) == 1)) || ((SA_S21.size(0) == 1) &&
         (SA_S21.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, B, SA_S21, r1);
  emlrtSizeEqCheckNDR2012b(((coder::array<creal_T, 2U> *)&SA_S11)->size(),
    r1.size(), &x_emlrtECI, sp);
  S_S11.set_size((&cg_emlrtRTEI), sp, SA_S11.size(0), SA_S11.size(1));
  loop_ub = SA_S11.size(0) * SA_S11.size(1);
  for (i = 0; i < loop_ub; i++) {
    S_S11[i].re = SA_S11[i].re + r1[i].re;
    S_S11[i].im = SA_S11[i].im + r1[i].im;
  }

  st.site = &ji_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (D.size(1) != SB_S12.size(0)) {
    if (((D.size(0) == 1) && (D.size(1) == 1)) || ((SB_S12.size(0) == 1) &&
         (SB_S12.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, D, SB_S12, S_S12);
  st.site = &ki_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (F.size(1) != SA_S21.size(0)) {
    if (((F.size(0) == 1) && (F.size(1) == 1)) || ((SA_S21.size(0) == 1) &&
         (SA_S21.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, F, SA_S21, S_S21);
  st.site = &li_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (F.size(1) != SA_S22.size(0)) {
    if (((F.size(0) == 1) && (F.size(1) == 1)) || ((SA_S22.size(0) == 1) &&
         (SA_S22.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, F, SA_S22, B);
  st.site = &li_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (B.size(1) != SB_S12.size(0)) {
    if (((B.size(0) == 1) && (B.size(1) == 1)) || ((SB_S12.size(0) == 1) &&
         (SB_S12.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, B, SB_S12, r1);
  emlrtSizeEqCheckNDR2012b(((coder::array<creal_T, 2U> *)&SB_S22)->size(),
    r1.size(), &y_emlrtECI, sp);
  S_S22.set_size((&dg_emlrtRTEI), sp, SB_S22.size(0), SB_S22.size(1));
  loop_ub = SB_S22.size(0) * SB_S22.size(1);
  for (i = 0; i < loop_ub; i++) {
    S_S22[i].re = SB_S22[i].re + r1[i].re;
    S_S22[i].im = SB_S22[i].im + r1[i].im;
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

// End of code generation (star.cpp)
