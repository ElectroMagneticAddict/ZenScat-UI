//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  expm.cpp
//
//  Code generation for function 'expm'
//


// Include files
#include "expm.h"
#include "Launch_RCWA_data.h"
#include "lusolve.h"
#include "mtimes.h"
#include "norm.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"
#include <math.h>

// Variable Definitions
static emlrtRSInfo jh_emlrtRSI = { 51, // lineNo
  "expm",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo kh_emlrtRSI = { 56, // lineNo
  "expm",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo lh_emlrtRSI = { 60, // lineNo
  "expm",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo mh_emlrtRSI = { 61, // lineNo
  "expm",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo nh_emlrtRSI = { 63, // lineNo
  "expm",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo oh_emlrtRSI = { 117,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo ph_emlrtRSI = { 123,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo qh_emlrtRSI = { 127,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo rh_emlrtRSI = { 133,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo sh_emlrtRSI = { 137,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo th_emlrtRSI = { 143,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo uh_emlrtRSI = { 147,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo vh_emlrtRSI = { 152,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo wh_emlrtRSI = { 160,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo xh_emlrtRSI = { 161,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo yh_emlrtRSI = { 174,// lineNo
  "PadeApproximantOfDegree",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pathName 
};

static emlrtRSInfo ai_emlrtRSI = { 17, // lineNo
  "log2",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elfun\\log2.m"// pathName 
};

static emlrtRSInfo di_emlrtRSI = { 12, // lineNo
  "pow2",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elfun\\pow2.m"// pathName 
};

static emlrtRTEInfo o_emlrtRTEI = { 8, // lineNo
  15,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo p_emlrtRTEI = { 62,// lineNo
  13,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo if_emlrtRTEI = { 42,// lineNo
  20,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo jf_emlrtRTEI = { 156,// lineNo
  13,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo kf_emlrtRTEI = { 160,// lineNo
  24,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo lf_emlrtRTEI = { 161,// lineNo
  21,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo mf_emlrtRTEI = { 63,// lineNo
  13,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo nf_emlrtRTEI = { 63,// lineNo
  15,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo of_emlrtRTEI = { 148,// lineNo
  13,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo pf_emlrtRTEI = { 152,// lineNo
  19,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo qf_emlrtRTEI = { 139,// lineNo
  13,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo rf_emlrtRTEI = { 143,// lineNo
  19,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo sf_emlrtRTEI = { 144,// lineNo
  13,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo tf_emlrtRTEI = { 129,// lineNo
  9,                                   // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo uf_emlrtRTEI = { 133,// lineNo
  15,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo vf_emlrtRTEI = { 134,// lineNo
  9,                                   // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo wf_emlrtRTEI = { 119,// lineNo
  5,                                   // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo xf_emlrtRTEI = { 123,// lineNo
  11,                                  // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

static emlrtRTEInfo yf_emlrtRTEI = { 124,// lineNo
  5,                                   // colNo
  "expm",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\expm.m"// pName 
};

// Function Declarations
namespace coder
{
  static void PadeApproximantOfDegree(const emlrtStack *sp, const ::coder::array<
    creal_T, 2U> &A, uint8_T m, ::coder::array<creal_T, 2U> &F);
}

// Function Definitions
namespace coder
{
  static void PadeApproximantOfDegree(const emlrtStack *sp, const ::coder::array<
    creal_T, 2U> &A, uint8_T m, ::coder::array<creal_T, 2U> &F)
  {
    array<creal_T, 2U> A2;
    array<creal_T, 2U> A3;
    array<creal_T, 2U> A4;
    array<creal_T, 2U> U;
    array<creal_T, 2U> V;
    array<creal_T, 2U> b;
    emlrtStack b_st;
    emlrtStack st;
    real_T d;
    int32_T i;
    int32_T loop_ub;
    st.prev = sp;
    st.tls = sp->tls;
    b_st.prev = &st;
    b_st.tls = st.tls;
    emlrtHeapReferenceStackEnterFcnR2012b(sp);
    st.site = &oh_emlrtRSI;
    b_st.site = &ye_emlrtRSI;
    if (A.size(1) != A.size(0)) {
      if ((A.size(0) == 1) && (A.size(1) == 1)) {
        emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
          "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
          "MATLAB:innerdim", 0);
      }
    }

    b_st.site = &xe_emlrtRSI;
    internal::blas::mtimes(&b_st, A, A, A2);
    if (m == 3) {
      U.set_size((&wf_emlrtRTEI), sp, A2.size(0), A2.size(1));
      loop_ub = A2.size(0) * A2.size(1);
      for (i = 0; i < loop_ub; i++) {
        U[i] = A2[i];
      }

      i = A.size(0);
      for (loop_ub = 0; loop_ub < i; loop_ub++) {
        U[loop_ub + U.size(0) * loop_ub].re = U[loop_ub + U.size(0) * loop_ub].
          re + 60.0;
        U[loop_ub + U.size(0) * loop_ub].im = U[loop_ub + U.size(0) * loop_ub].
          im;
      }

      st.site = &ph_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      if (A.size(1) != U.size(0)) {
        if (((A.size(0) == 1) && (A.size(1) == 1)) || ((U.size(0) == 1) &&
             (U.size(1) == 1))) {
          emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
            "MATLAB:innerdim", 0);
        }
      }

      b.set_size((&xf_emlrtRTEI), (&st), U.size(0), U.size(1));
      loop_ub = U.size(0) * U.size(1) - 1;
      for (i = 0; i <= loop_ub; i++) {
        b[i] = U[i];
      }

      b_st.site = &xe_emlrtRSI;
      internal::blas::mtimes(&b_st, A, b, U);
      V.set_size((&yf_emlrtRTEI), sp, A2.size(0), A2.size(1));
      loop_ub = A2.size(0) * A2.size(1);
      for (i = 0; i < loop_ub; i++) {
        V[i].re = 12.0 * A2[i].re;
        V[i].im = 12.0 * A2[i].im;
      }

      d = 120.0;
    } else {
      st.site = &qh_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      if (A2.size(1) != A2.size(0)) {
        if ((A2.size(0) == 1) && (A2.size(1) == 1)) {
          emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
            "MATLAB:innerdim", 0);
        }
      }

      b_st.site = &xe_emlrtRSI;
      internal::blas::mtimes(&b_st, A2, A2, A3);
      if (m == 5) {
        U.set_size((&tf_emlrtRTEI), sp, A3.size(0), A3.size(1));
        loop_ub = A3.size(0) * A3.size(1);
        for (i = 0; i < loop_ub; i++) {
          U[i].re = A3[i].re + 420.0 * A2[i].re;
          U[i].im = A3[i].im + 420.0 * A2[i].im;
        }

        i = A.size(0);
        for (loop_ub = 0; loop_ub < i; loop_ub++) {
          U[loop_ub + U.size(0) * loop_ub].re = U[loop_ub + U.size(0) * loop_ub]
            .re + 15120.0;
          U[loop_ub + U.size(0) * loop_ub].im = U[loop_ub + U.size(0) * loop_ub]
            .im;
        }

        st.site = &rh_emlrtRSI;
        b_st.site = &ye_emlrtRSI;
        if (A.size(1) != U.size(0)) {
          if (((A.size(0) == 1) && (A.size(1) == 1)) || ((U.size(0) == 1) &&
               (U.size(1) == 1))) {
            emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        b.set_size((&uf_emlrtRTEI), (&st), U.size(0), U.size(1));
        loop_ub = U.size(0) * U.size(1) - 1;
        for (i = 0; i <= loop_ub; i++) {
          b[i] = U[i];
        }

        b_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&b_st, A, b, U);
        V.set_size((&vf_emlrtRTEI), sp, A3.size(0), A3.size(1));
        loop_ub = A3.size(0) * A3.size(1);
        for (i = 0; i < loop_ub; i++) {
          V[i].re = 30.0 * A3[i].re + 3360.0 * A2[i].re;
          V[i].im = 30.0 * A3[i].im + 3360.0 * A2[i].im;
        }

        d = 30240.0;
      } else {
        st.site = &sh_emlrtRSI;
        b_st.site = &ye_emlrtRSI;
        if (A3.size(1) != A2.size(0)) {
          if (((A3.size(0) == 1) && (A3.size(1) == 1)) || ((A2.size(0) == 1) &&
               (A2.size(1) == 1))) {
            emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        b_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&b_st, A3, A2, A4);
        if (m == 7) {
          U.set_size((&qf_emlrtRTEI), sp, A4.size(0), A4.size(1));
          loop_ub = A4.size(0) * A4.size(1);
          for (i = 0; i < loop_ub; i++) {
            U[i].re = (A4[i].re + 1512.0 * A3[i].re) + 277200.0 * A2[i].re;
            U[i].im = (A4[i].im + 1512.0 * A3[i].im) + 277200.0 * A2[i].im;
          }

          i = A.size(0);
          for (loop_ub = 0; loop_ub < i; loop_ub++) {
            U[loop_ub + U.size(0) * loop_ub].re = U[loop_ub + U.size(0) *
              loop_ub].re + 8.64864E+6;
            U[loop_ub + U.size(0) * loop_ub].im = U[loop_ub + U.size(0) *
              loop_ub].im;
          }

          st.site = &th_emlrtRSI;
          b_st.site = &ye_emlrtRSI;
          if (A.size(1) != U.size(0)) {
            if (((A.size(0) == 1) && (A.size(1) == 1)) || ((U.size(0) == 1) &&
                 (U.size(1) == 1))) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          b.set_size((&rf_emlrtRTEI), (&st), U.size(0), U.size(1));
          loop_ub = U.size(0) * U.size(1) - 1;
          for (i = 0; i <= loop_ub; i++) {
            b[i] = U[i];
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A, b, U);
          V.set_size((&sf_emlrtRTEI), sp, A4.size(0), A4.size(1));
          loop_ub = A4.size(0) * A4.size(1);
          for (i = 0; i < loop_ub; i++) {
            V[i].re = (56.0 * A4[i].re + 25200.0 * A3[i].re) + 1.99584E+6 * A2[i]
              .re;
            V[i].im = (56.0 * A4[i].im + 25200.0 * A3[i].im) + 1.99584E+6 * A2[i]
              .im;
          }

          d = 1.729728E+7;
        } else if (m == 9) {
          st.site = &uh_emlrtRSI;
          b_st.site = &ye_emlrtRSI;
          if (A4.size(1) != A2.size(0)) {
            if (((A4.size(0) == 1) && (A4.size(1) == 1)) || ((A2.size(0) == 1) &&
                 (A2.size(1) == 1))) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A4, A2, V);
          U.set_size((&of_emlrtRTEI), sp, V.size(0), V.size(1));
          loop_ub = V.size(0) * V.size(1);
          for (i = 0; i < loop_ub; i++) {
            U[i].re = ((V[i].re + 3960.0 * A4[i].re) + 2.16216E+6 * A3[i].re) +
              3.027024E+8 * A2[i].re;
            U[i].im = ((V[i].im + 3960.0 * A4[i].im) + 2.16216E+6 * A3[i].im) +
              3.027024E+8 * A2[i].im;
          }

          i = A.size(0);
          for (loop_ub = 0; loop_ub < i; loop_ub++) {
            U[loop_ub + U.size(0) * loop_ub].re = U[loop_ub + U.size(0) *
              loop_ub].re + 8.8216128E+9;
            U[loop_ub + U.size(0) * loop_ub].im = U[loop_ub + U.size(0) *
              loop_ub].im;
          }

          st.site = &vh_emlrtRSI;
          b_st.site = &ye_emlrtRSI;
          if (A.size(1) != U.size(0)) {
            if (((A.size(0) == 1) && (A.size(1) == 1)) || ((U.size(0) == 1) &&
                 (U.size(1) == 1))) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          b.set_size((&pf_emlrtRTEI), (&st), U.size(0), U.size(1));
          loop_ub = U.size(0) * U.size(1) - 1;
          for (i = 0; i <= loop_ub; i++) {
            b[i] = U[i];
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A, b, U);
          loop_ub = V.size(0) * V.size(1);
          for (i = 0; i < loop_ub; i++) {
            V[i].re = ((90.0 * V[i].re + 110880.0 * A4[i].re) + 3.027024E+7 *
                       A3[i].re) + 2.0756736E+9 * A2[i].re;
            V[i].im = ((90.0 * V[i].im + 110880.0 * A4[i].im) + 3.027024E+7 *
                       A3[i].im) + 2.0756736E+9 * A2[i].im;
          }

          d = 1.76432256E+10;
        } else {
          U.set_size((&jf_emlrtRTEI), sp, A4.size(0), A4.size(1));
          loop_ub = A4.size(0) * A4.size(1);
          for (i = 0; i < loop_ub; i++) {
            U[i].re = (3.352212864E+10 * A4[i].re + 1.05594705216E+13 * A3[i].re)
              + 1.1873537964288E+15 * A2[i].re;
            U[i].im = (3.352212864E+10 * A4[i].im + 1.05594705216E+13 * A3[i].im)
              + 1.1873537964288E+15 * A2[i].im;
          }

          i = A.size(0);
          for (loop_ub = 0; loop_ub < i; loop_ub++) {
            U[loop_ub + U.size(0) * loop_ub].re = U[loop_ub + U.size(0) *
              loop_ub].re + 3.238237626624E+16;
            U[loop_ub + U.size(0) * loop_ub].im = U[loop_ub + U.size(0) *
              loop_ub].im;
          }

          st.site = &wh_emlrtRSI;
          b.set_size((&kf_emlrtRTEI), (&st), A4.size(0), A4.size(1));
          loop_ub = A4.size(0) * A4.size(1);
          for (i = 0; i < loop_ub; i++) {
            b[i].re = (A4[i].re + 16380.0 * A3[i].re) + 4.08408E+7 * A2[i].re;
            b[i].im = (A4[i].im + 16380.0 * A3[i].im) + 4.08408E+7 * A2[i].im;
          }

          b_st.site = &ye_emlrtRSI;
          if (A4.size(1) != b.size(0)) {
            if (((A4.size(0) == 1) && (A4.size(1) == 1)) || ((b.size(0) == 1) &&
                 (b.size(1) == 1))) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A4, b, V);
          st.site = &wh_emlrtRSI;
          loop_ub = V.size(0) * V.size(1);
          for (i = 0; i < loop_ub; i++) {
            V[i].re = V[i].re + U[i].re;
            V[i].im = V[i].im + U[i].im;
          }

          b_st.site = &ye_emlrtRSI;
          if (A.size(1) != V.size(0)) {
            if (((A.size(0) == 1) && (A.size(1) == 1)) || ((V.size(0) == 1) &&
                 (V.size(1) == 1))) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A, V, U);
          st.site = &xh_emlrtRSI;
          b.set_size((&lf_emlrtRTEI), (&st), A4.size(0), A4.size(1));
          loop_ub = A4.size(0) * A4.size(1);
          for (i = 0; i < loop_ub; i++) {
            b[i].re = (182.0 * A4[i].re + 960960.0 * A3[i].re) + 1.32324192E+9 *
              A2[i].re;
            b[i].im = (182.0 * A4[i].im + 960960.0 * A3[i].im) + 1.32324192E+9 *
              A2[i].im;
          }

          b_st.site = &ye_emlrtRSI;
          if (A4.size(1) != b.size(0)) {
            if (((A4.size(0) == 1) && (A4.size(1) == 1)) || ((b.size(0) == 1) &&
                 (b.size(1) == 1))) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A4, b, V);
          loop_ub = V.size(0) * V.size(1);
          for (i = 0; i < loop_ub; i++) {
            V[i].re = ((V[i].re + 6.704425728E+11 * A4[i].re) +
                       1.29060195264E+14 * A3[i].re) + 7.7717703038976E+15 *
              A2[i].re;
            V[i].im = ((V[i].im + 6.704425728E+11 * A4[i].im) +
                       1.29060195264E+14 * A3[i].im) + 7.7717703038976E+15 *
              A2[i].im;
          }

          d = 6.476475253248E+16;
        }
      }
    }

    i = A.size(0);
    for (loop_ub = 0; loop_ub < i; loop_ub++) {
      V[loop_ub + V.size(0) * loop_ub].re = V[loop_ub + V.size(0) * loop_ub].re
        + d;
    }

    i = U.size(0) * U.size(1);
    for (loop_ub = 0; loop_ub < i; loop_ub++) {
      V[loop_ub].re = V[loop_ub].re - U[loop_ub].re;
      V[loop_ub].im = V[loop_ub].im - U[loop_ub].im;
      U[loop_ub].re = 2.0 * U[loop_ub].re;
      U[loop_ub].im = 2.0 * U[loop_ub].im;
    }

    st.site = &yh_emlrtRSI;
    internal::lusolve(&st, V, U, F);
    i = A.size(0);
    for (loop_ub = 0; loop_ub < i; loop_ub++) {
      F[loop_ub + F.size(0) * loop_ub].re = F[loop_ub + F.size(0) * loop_ub].re
        + 1.0;
      F[loop_ub + F.size(0) * loop_ub].im = F[loop_ub + F.size(0) * loop_ub].im;
    }

    emlrtHeapReferenceStackLeaveFcnR2012b(sp);
  }

  void expm(const emlrtStack *sp, ::coder::array<creal_T, 2U> &A, ::coder::array<
            creal_T, 2U> &F)
  {
    static const real_T theta[5] = { 0.01495585217958292, 0.253939833006323,
      0.95041789961629319, 2.097847961257068, 5.3719203511481517 };

    static const uint8_T uv[5] = { 3U, 5U, 7U, 9U, 13U };

    array<creal_T, 2U> A2;
    array<creal_T, 2U> A3;
    array<creal_T, 2U> A4;
    array<creal_T, 2U> U;
    array<creal_T, 2U> V;
    array<creal_T, 2U> b;
    emlrtStack b_st;
    emlrtStack c_st;
    emlrtStack st;
    real_T normA;
    int32_T eint;
    st.prev = sp;
    st.tls = sp->tls;
    b_st.prev = &st;
    b_st.tls = st.tls;
    c_st.prev = &b_st;
    c_st.tls = b_st.tls;
    emlrtHeapReferenceStackEnterFcnR2012b(sp);
    if (A.size(0) != A.size(1)) {
      emlrtErrorWithMessageIdR2018a(sp, &o_emlrtRTEI, "MATLAB:square",
        "MATLAB:square", 0);
    }

    F.set_size((&if_emlrtRTEI), sp, A.size(0), A.size(1));
    if ((A.size(0) != 0) && (A.size(1) != 0)) {
      normA = b_norm(A);
      if (normA <= 5.3719203511481517) {
        boolean_T exitg1;
        eint = 0;
        exitg1 = false;
        while ((!exitg1) && (eint < 5)) {
          if (normA <= theta[eint]) {
            st.site = &jh_emlrtRSI;
            PadeApproximantOfDegree(&st, A, uv[eint], F);
            exitg1 = true;
          } else {
            eint++;
          }
        }
      } else {
        real_T s;
        real_T y;
        int32_T i;
        st.site = &kh_emlrtRSI;
        normA /= 5.3719203511481517;
        b_st.site = &ai_emlrtRSI;
        if ((!muDoubleScalarIsInf(normA)) && (!muDoubleScalarIsNaN(normA))) {
          normA = frexp(normA, &eint);
        } else {
          eint = 0;
        }

        s = eint;
        if (normA == 0.5) {
          s = static_cast<real_T>(eint) - 1.0;
        }

        st.site = &lh_emlrtRSI;
        b_st.site = &di_emlrtRSI;
        y = muDoubleScalarPower(2.0, s);
        eint = A.size(0) * A.size(1);
        for (i = 0; i < eint; i++) {
          real_T ai;
          real_T re;
          normA = A[i].re;
          ai = A[i].im;
          if (ai == 0.0) {
            re = normA / y;
            normA = 0.0;
          } else if (normA == 0.0) {
            re = 0.0;
            normA = ai / y;
          } else {
            re = normA / y;
            normA = ai / y;
          }

          A[i].re = re;
          A[i].im = normA;
        }

        st.site = &mh_emlrtRSI;
        b_st.site = &oh_emlrtRSI;
        c_st.site = &ye_emlrtRSI;
        if (A.size(1) != A.size(0)) {
          if ((A.size(0) == 1) && (A.size(1) == 1)) {
            emlrtErrorWithMessageIdR2018a(&c_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&c_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        c_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&c_st, A, A, A2);
        b_st.site = &qh_emlrtRSI;
        c_st.site = &ye_emlrtRSI;
        if (A2.size(1) != A2.size(0)) {
          if ((A2.size(0) == 1) && (A2.size(1) == 1)) {
            emlrtErrorWithMessageIdR2018a(&c_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&c_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        c_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&c_st, A2, A2, A3);
        b_st.site = &sh_emlrtRSI;
        c_st.site = &ye_emlrtRSI;
        if (A3.size(1) != A2.size(0)) {
          if (((A3.size(0) == 1) && (A3.size(1) == 1)) || ((A2.size(0) == 1) &&
               (A2.size(1) == 1))) {
            emlrtErrorWithMessageIdR2018a(&c_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&c_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        c_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&c_st, A3, A2, A4);
        U.set_size((&jf_emlrtRTEI), (&st), A4.size(0), A4.size(1));
        eint = A4.size(0) * A4.size(1);
        for (i = 0; i < eint; i++) {
          U[i].re = (3.352212864E+10 * A4[i].re + 1.05594705216E+13 * A3[i].re)
            + 1.1873537964288E+15 * A2[i].re;
          U[i].im = (3.352212864E+10 * A4[i].im + 1.05594705216E+13 * A3[i].im)
            + 1.1873537964288E+15 * A2[i].im;
        }

        i = A.size(0);
        for (eint = 0; eint < i; eint++) {
          U[eint + U.size(0) * eint].re = U[eint + U.size(0) * eint].re +
            3.238237626624E+16;
          U[eint + U.size(0) * eint].im = U[eint + U.size(0) * eint].im;
        }

        b_st.site = &wh_emlrtRSI;
        b.set_size((&kf_emlrtRTEI), (&b_st), A4.size(0), A4.size(1));
        eint = A4.size(0) * A4.size(1);
        for (i = 0; i < eint; i++) {
          b[i].re = (A4[i].re + 16380.0 * A3[i].re) + 4.08408E+7 * A2[i].re;
          b[i].im = (A4[i].im + 16380.0 * A3[i].im) + 4.08408E+7 * A2[i].im;
        }

        c_st.site = &ye_emlrtRSI;
        if (A4.size(1) != b.size(0)) {
          if (((A4.size(0) == 1) && (A4.size(1) == 1)) || ((b.size(0) == 1) &&
               (b.size(1) == 1))) {
            emlrtErrorWithMessageIdR2018a(&c_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&c_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        c_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&c_st, A4, b, V);
        b_st.site = &wh_emlrtRSI;
        eint = V.size(0) * V.size(1);
        for (i = 0; i < eint; i++) {
          V[i].re = V[i].re + U[i].re;
          V[i].im = V[i].im + U[i].im;
        }

        c_st.site = &ye_emlrtRSI;
        if (A.size(1) != V.size(0)) {
          if (((A.size(0) == 1) && (A.size(1) == 1)) || ((V.size(0) == 1) &&
               (V.size(1) == 1))) {
            emlrtErrorWithMessageIdR2018a(&c_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&c_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        c_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&c_st, A, V, U);
        b_st.site = &xh_emlrtRSI;
        b.set_size((&lf_emlrtRTEI), (&b_st), A4.size(0), A4.size(1));
        eint = A4.size(0) * A4.size(1);
        for (i = 0; i < eint; i++) {
          b[i].re = (182.0 * A4[i].re + 960960.0 * A3[i].re) + 1.32324192E+9 *
            A2[i].re;
          b[i].im = (182.0 * A4[i].im + 960960.0 * A3[i].im) + 1.32324192E+9 *
            A2[i].im;
        }

        c_st.site = &ye_emlrtRSI;
        if (A4.size(1) != b.size(0)) {
          if (((A4.size(0) == 1) && (A4.size(1) == 1)) || ((b.size(0) == 1) &&
               (b.size(1) == 1))) {
            emlrtErrorWithMessageIdR2018a(&c_st, &g_emlrtRTEI,
              "Coder:toolbox:mtimes_noDynamicScalarExpansion",
              "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
          } else {
            emlrtErrorWithMessageIdR2018a(&c_st, &f_emlrtRTEI, "MATLAB:innerdim",
              "MATLAB:innerdim", 0);
          }
        }

        c_st.site = &xe_emlrtRSI;
        internal::blas::mtimes(&c_st, A4, b, V);
        eint = V.size(0) * V.size(1);
        for (i = 0; i < eint; i++) {
          V[i].re = ((V[i].re + 6.704425728E+11 * A4[i].re) + 1.29060195264E+14 *
                     A3[i].re) + 7.7717703038976E+15 * A2[i].re;
          V[i].im = ((V[i].im + 6.704425728E+11 * A4[i].im) + 1.29060195264E+14 *
                     A3[i].im) + 7.7717703038976E+15 * A2[i].im;
        }

        i = A.size(0);
        for (eint = 0; eint < i; eint++) {
          V[eint + V.size(0) * eint].re = V[eint + V.size(0) * eint].re +
            6.476475253248E+16;
          V[eint + V.size(0) * eint].im = V[eint + V.size(0) * eint].im;
        }

        i = U.size(0) * U.size(1);
        for (eint = 0; eint < i; eint++) {
          V[eint].re = V[eint].re - U[eint].re;
          V[eint].im = V[eint].im - U[eint].im;
          U[eint].re = 2.0 * U[eint].re;
          U[eint].im = 2.0 * U[eint].im;
        }

        b_st.site = &yh_emlrtRSI;
        internal::lusolve(&b_st, V, U, F);
        i = A.size(0);
        for (eint = 0; eint < i; eint++) {
          F[eint + F.size(0) * eint].re = F[eint + F.size(0) * eint].re + 1.0;
          F[eint + F.size(0) * eint].im = F[eint + F.size(0) * eint].im;
        }

        i = static_cast<int32_T>(s);
        emlrtForLoopVectorCheckR2012b(1.0, 1.0, s, mxDOUBLE_CLASS, static_cast<
          int32_T>(s), &p_emlrtRTEI, sp);
        for (int32_T j = 0; j < i; j++) {
          int32_T i1;
          st.site = &nh_emlrtRSI;
          b_st.site = &ye_emlrtRSI;
          if (F.size(1) != F.size(0)) {
            if ((F.size(0) == 1) && (F.size(1) == 1)) {
              emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
                "Coder:toolbox:mtimes_noDynamicScalarExpansion",
                "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI,
                "MATLAB:innerdim", "MATLAB:innerdim", 0);
            }
          }

          A2.set_size((&mf_emlrtRTEI), (&st), F.size(0), F.size(1));
          eint = F.size(0) * F.size(1) - 1;
          for (i1 = 0; i1 <= eint; i1++) {
            A2[i1] = F[i1];
          }

          A3.set_size((&nf_emlrtRTEI), (&st), F.size(0), F.size(1));
          eint = F.size(0) * F.size(1) - 1;
          for (i1 = 0; i1 <= eint; i1++) {
            A3[i1] = F[i1];
          }

          b_st.site = &xe_emlrtRSI;
          internal::blas::mtimes(&b_st, A2, A3, F);
        }
      }
    }

    emlrtHeapReferenceStackLeaveFcnR2012b(sp);
  }
}

// End of code generation (expm.cpp)
