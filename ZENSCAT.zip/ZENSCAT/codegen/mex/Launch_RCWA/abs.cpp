//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  abs.cpp
//
//  Code generation for function 'abs'
//


// Include files
#include "abs.h"
#include "Launch_RCWA_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo mi_emlrtRSI = { 18, // lineNo
  "abs",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elfun\\abs.m"// pathName 
};

static emlrtRSInfo ni_emlrtRSI = { 75, // lineNo
  "applyScalarFunction",               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunction.m"// pathName 
};

static emlrtRTEInfo eg_emlrtRTEI = { 31,// lineNo
  21,                                  // colNo
  "applyScalarFunction",               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunction.m"// pName 
};

// Function Definitions
namespace coder
{
  void b_abs(const emlrtStack *sp, const ::coder::array<creal_T, 1U> &x, ::coder::
             array<real_T, 1U> &y)
  {
    emlrtStack b_st;
    emlrtStack c_st;
    emlrtStack st;
    int32_T nx;
    st.prev = sp;
    st.tls = sp->tls;
    st.site = &mi_emlrtRSI;
    b_st.prev = &st;
    b_st.tls = st.tls;
    c_st.prev = &b_st;
    c_st.tls = b_st.tls;
    nx = x.size(0);
    y.set_size((&eg_emlrtRTEI), (&st), x.size(0));
    b_st.site = &ni_emlrtRSI;
    if ((1 <= x.size(0)) && (x.size(0) > 2147483646)) {
      c_st.site = &ib_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    for (int32_T k = 0; k < nx; k++) {
      y[k] = muDoubleScalarHypot(x[k].re, x[k].im);
    }
  }
}

// End of code generation (abs.cpp)
