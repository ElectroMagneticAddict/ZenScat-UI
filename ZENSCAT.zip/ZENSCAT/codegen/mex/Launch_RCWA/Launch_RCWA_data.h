//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  Launch_RCWA_data.h
//
//  Code generation for function 'Launch_RCWA_data'
//


#pragma once

// Include files
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtContext emlrtContextGlobal;
extern emlrtRSInfo ib_emlrtRSI;
extern emlrtRSInfo ob_emlrtRSI;
extern emlrtRSInfo bc_emlrtRSI;
extern emlrtRSInfo ec_emlrtRSI;
extern emlrtRSInfo gc_emlrtRSI;
extern emlrtRSInfo lc_emlrtRSI;
extern emlrtRSInfo mc_emlrtRSI;
extern emlrtRSInfo nc_emlrtRSI;
extern emlrtRSInfo vc_emlrtRSI;
extern emlrtRSInfo wc_emlrtRSI;
extern emlrtRSInfo xc_emlrtRSI;
extern emlrtRSInfo yc_emlrtRSI;
extern emlrtRSInfo md_emlrtRSI;
extern emlrtRSInfo nd_emlrtRSI;
extern emlrtRSInfo od_emlrtRSI;
extern emlrtRSInfo pd_emlrtRSI;
extern emlrtRSInfo qd_emlrtRSI;
extern emlrtRSInfo ge_emlrtRSI;
extern emlrtRSInfo he_emlrtRSI;
extern emlrtRSInfo ie_emlrtRSI;
extern emlrtRSInfo je_emlrtRSI;
extern emlrtRSInfo ke_emlrtRSI;
extern emlrtRSInfo le_emlrtRSI;
extern emlrtRSInfo xe_emlrtRSI;
extern emlrtRSInfo ye_emlrtRSI;
extern emlrtRSInfo af_emlrtRSI;
extern emlrtRSInfo bf_emlrtRSI;
extern emlrtMCInfo c_emlrtMCI;
extern emlrtRTEInfo emlrtRTEI;
extern emlrtRTEInfo f_emlrtRTEI;
extern emlrtRTEInfo g_emlrtRTEI;
extern emlrtRTEInfo h_emlrtRTEI;
extern emlrtRTEInfo i_emlrtRTEI;
extern emlrtRTEInfo xb_emlrtRTEI;
extern emlrtRTEInfo yb_emlrtRTEI;
extern emlrtRTEInfo oc_emlrtRTEI;
extern emlrtRTEInfo pc_emlrtRTEI;
extern emlrtRTEInfo dd_emlrtRTEI;
extern emlrtRTEInfo fd_emlrtRTEI;
extern emlrtRTEInfo gd_emlrtRTEI;
extern emlrtRTEInfo hd_emlrtRTEI;
extern emlrtRTEInfo kd_emlrtRTEI;
extern emlrtRTEInfo ld_emlrtRTEI;
extern emlrtRTEInfo pd_emlrtRTEI;
extern const char_T cv1[19];
extern const creal_T dc;
extern emlrtRSInfo ti_emlrtRSI;

// End of code generation (Launch_RCWA_data.h)
