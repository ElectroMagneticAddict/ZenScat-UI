//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  calcLayer.h
//
//  Code generation for function 'calcLayer'
//


#pragma once

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void calcLayer(const emlrtStack *sp, const coder::array<real_T, 2U> &Kx, real_T
               lam0, real_T N, const coder::array<real_T, 2U> &W0, const coder::
               array<creal_T, 2U> &V0, const coder::array<creal_T, 3U>
               &device_ERC, const coder::array<real_T, 2U> &device_sub_L, real_T
               layer, real_T sub_layer, char_T mode, coder::array<creal_T, 2U>
               &Si_S11, coder::array<creal_T, 2U> &Si_S12, coder::array<creal_T,
               2U> &Si_S21, coder::array<creal_T, 2U> &Si_S22);

// End of code generation (calcLayer.h)
