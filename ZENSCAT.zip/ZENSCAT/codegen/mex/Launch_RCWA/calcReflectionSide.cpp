//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  calcReflectionSide.cpp
//
//  Code generation for function 'calcReflectionSide'
//


// Include files
#include "calcReflectionSide.h"
#include "Launch_RCWA_data.h"
#include "eye.h"
#include "inv.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "power.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo rd_emlrtRSI = { 3,  // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo sd_emlrtRSI = { 6,  // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo td_emlrtRSI = { 8,  // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo ud_emlrtRSI = { 10, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo vd_emlrtRSI = { 12, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo wd_emlrtRSI = { 14, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo xd_emlrtRSI = { 15, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo yd_emlrtRSI = { 16, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo ae_emlrtRSI = { 17, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo be_emlrtRSI = { 18, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtRSInfo ce_emlrtRSI = { 19, // lineNo
  "calcReflectionSide",                // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pathName 
};

static emlrtDCInfo m_emlrtDCI = { 4,   // lineNo
  22,                                  // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m",// pName 
  1                                    // checkKind
};

static emlrtECInfo e_emlrtECI = { 2,   // nDims
  6,                                   // lineNo
  9,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtECInfo f_emlrtECI = { 2,   // nDims
  10,                                  // lineNo
  9,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtECInfo g_emlrtECI = { 2,   // nDims
  14,                                  // lineNo
  5,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtECInfo h_emlrtECI = { 2,   // nDims
  15,                                  // lineNo
  5,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtECInfo i_emlrtECI = { 2,   // nDims
  18,                                  // lineNo
  17,                                  // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo sc_emlrtRTEI = { 4,// lineNo
  1,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo tc_emlrtRTEI = { 11,// lineNo
  5,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo uc_emlrtRTEI = { 7,// lineNo
  5,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo vc_emlrtRTEI = { 14,// lineNo
  1,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo wc_emlrtRTEI = { 15,// lineNo
  1,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo xc_emlrtRTEI = { 16,// lineNo
  12,                                  // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo yc_emlrtRTEI = { 17,// lineNo
  1,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

static emlrtRTEInfo ad_emlrtRTEI = { 18,// lineNo
  1,                                   // colNo
  "calcReflectionSide",                // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcReflectionSide.m"// pName 
};

// Function Definitions
void calcReflectionSide(const emlrtStack *sp, const coder::array<real_T, 2U> &Kx,
  const coder::array<creal_T, 2U> &KzR, real_T N, const coder::array<real_T, 2U>
  &W0, const coder::array<creal_T, 2U> &V0, real_T grid_urR, real_T grid_erR,
  char_T mode, coder::array<real_T, 2U> &Wref, coder::array<creal_T, 2U>
  &Sref_S11, coder::array<creal_T, 2U> &Sref_S12, coder::array<creal_T, 2U>
  &Sref_S21, coder::array<creal_T, 2U> &Sref_S22)
{
  coder::array<creal_T, 2U> A;
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> Vref;
  coder::array<creal_T, 2U> lam;
  coder::array<real_T, 2U> Q;
  coder::array<real_T, 2U> a;
  emlrtStack b_st;
  emlrtStack st;
  int32_T i;
  int32_T loop_ub;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  //  Reflected modes from the surface of the device
  st.site = &rd_emlrtRSI;
  coder::eye(&st, N, Wref);
  if (N != static_cast<int32_T>(muDoubleScalarFloor(N))) {
    emlrtIntegerCheckR2012b(N, &m_emlrtDCI, sp);
  }

  Vref.set_size((&sc_emlrtRTEI), sp, (static_cast<int32_T>(N)),
                (static_cast<int32_T>(N)));
  loop_ub = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (i = 0; i < loop_ub; i++) {
    Vref[i].re = 0.0;
    Vref[i].im = 0.0;
  }

  if (mode == 'E') {
    st.site = &sd_emlrtRSI;
    coder::power(&st, Kx, Q);
    loop_ub = Q.size(0) * Q.size(1);
    for (i = 0; i < loop_ub; i++) {
      Q[i] = Q[i] / grid_urR;
    }

    st.site = &sd_emlrtRSI;
    coder::eye(&st, N, a);
    loop_ub = a.size(0) * a.size(1);
    for (i = 0; i < loop_ub; i++) {
      a[i] = a[i] * grid_erR;
    }

    emlrtSizeEqCheckNDR2012b(Q.size(), a.size(), &e_emlrtECI, sp);
    loop_ub = Q.size(0) * Q.size(1);
    for (i = 0; i < loop_ub; i++) {
      Q[i] = Q[i] - a[i];
    }

    lam.set_size((&uc_emlrtRTEI), sp, KzR.size(0), KzR.size(1));
    loop_ub = KzR.size(0) * KzR.size(1);
    for (i = 0; i < loop_ub; i++) {
      lam[i].re = -(0.0 * KzR[i].re - KzR[i].im);
      lam[i].im = -(0.0 * KzR[i].im + KzR[i].re);
    }

    st.site = &td_emlrtRSI;
    if (lam.size(1) != Q.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
        "MATLAB:dimagree", 0);
    }

    b_st.site = &bc_emlrtRSI;
    coder::internal::mrdiv(&b_st, Q, lam, Vref);
  } else {
    if (mode == 'H') {
      st.site = &ud_emlrtRSI;
      coder::power(&st, Kx, Q);
      loop_ub = Q.size(0) * Q.size(1);
      for (i = 0; i < loop_ub; i++) {
        Q[i] = Q[i] / grid_erR;
      }

      st.site = &ud_emlrtRSI;
      coder::eye(&st, N, a);
      emlrtSizeEqCheckNDR2012b(Q.size(), a.size(), &f_emlrtECI, sp);
      lam.set_size((&tc_emlrtRTEI), sp, KzR.size(0), KzR.size(1));
      loop_ub = KzR.size(0) * KzR.size(1);
      for (i = 0; i < loop_ub; i++) {
        lam[i].re = -(0.0 * KzR[i].re - KzR[i].im);
        lam[i].im = -(0.0 * KzR[i].im + KzR[i].re);
      }

      loop_ub = Q.size(0) * Q.size(1);
      for (i = 0; i < loop_ub; i++) {
        Q[i] = (Q[i] - a[i]) / grid_erR;
      }

      st.site = &vd_emlrtRSI;
      if (lam.size(1) != Q.size(1)) {
        emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
          "MATLAB:dimagree", 0);
      }

      b_st.site = &bc_emlrtRSI;
      coder::internal::mrdiv(&b_st, Q, lam, Vref);
    }
  }

  st.site = &wd_emlrtRSI;
  coder::mldivide(&st, W0, Wref, a);
  st.site = &wd_emlrtRSI;
  coder::mldivide(&st, V0, Vref, A);
  emlrtSizeEqCheckNDR2012b(a.size(), A.size(), &g_emlrtECI, sp);
  loop_ub = a.size(0) * a.size(1);
  A.set_size((&vc_emlrtRTEI), sp, a.size(0), a.size(1));
  for (i = 0; i < loop_ub; i++) {
    A[i].re = a[i] + A[i].re;
    A[i].im = A[i].im;
  }

  st.site = &xd_emlrtRSI;
  coder::mldivide(&st, W0, Wref, a);
  st.site = &xd_emlrtRSI;
  coder::mldivide(&st, V0, Vref, B);
  emlrtSizeEqCheckNDR2012b(a.size(), B.size(), &h_emlrtECI, sp);
  loop_ub = a.size(0) * a.size(1);
  B.set_size((&wc_emlrtRTEI), sp, a.size(0), a.size(1));
  for (i = 0; i < loop_ub; i++) {
    B[i].re = a[i] - B[i].re;
    B[i].im = 0.0 - B[i].im;
  }

  lam.set_size((&xc_emlrtRTEI), sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    lam[i].re = -A[i].re;
    lam[i].im = -A[i].im;
  }

  st.site = &yd_emlrtRSI;
  coder::mldivide(&st, lam, B, Sref_S11);
  st.site = &ae_emlrtRSI;
  coder::inv(&st, A, lam);
  Sref_S12.set_size((&yc_emlrtRTEI), sp, lam.size(0), lam.size(1));
  loop_ub = lam.size(0) * lam.size(1);
  for (i = 0; i < loop_ub; i++) {
    Sref_S12[i].re = 2.0 * lam[i].re;
    Sref_S12[i].im = 2.0 * lam[i].im;
  }

  st.site = &be_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, B, A, lam);
  st.site = &be_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (lam.size(1) != B.size(0)) {
    if (((lam.size(0) == 1) && (lam.size(1) == 1)) || ((B.size(0) == 1) &&
         (B.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, lam, B, Vref);
  emlrtSizeEqCheckNDR2012b(A.size(), Vref.size(), &i_emlrtECI, sp);
  Sref_S21.set_size((&ad_emlrtRTEI), sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    Sref_S21[i].re = 0.5 * (A[i].re - Vref[i].re);
    Sref_S21[i].im = 0.5 * (A[i].im - Vref[i].im);
  }

  st.site = &ce_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, B, A, Sref_S22);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

// End of code generation (calcReflectionSide.cpp)
