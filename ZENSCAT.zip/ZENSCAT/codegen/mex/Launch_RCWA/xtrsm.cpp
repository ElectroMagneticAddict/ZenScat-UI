//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  xtrsm.cpp
//
//  Code generation for function 'xtrsm'
//


// Include files
#include "xtrsm.h"
#include "Launch_RCWA_data.h"
#include "rt_nonfinite.h"
#include "blas.h"
#include "coder_array.h"
#include <stddef.h>

// Function Definitions
namespace coder
{
  namespace internal
  {
    namespace blas
    {
      void b_xtrsm(int32_T m, int32_T n, const ::coder::array<creal_T, 2U> &A,
                   int32_T lda, ::coder::array<creal_T, 2U> &B, int32_T ldb)
      {
        ptrdiff_t lda_t;
        ptrdiff_t ldb_t;
        ptrdiff_t m_t;
        ptrdiff_t n_t;
        char_T DIAGA1;
        char_T SIDE1;
        char_T TRANSA1;
        char_T UPLO1;
        if ((m >= 1) && (n >= 1)) {
          DIAGA1 = 'U';
          TRANSA1 = 'N';
          UPLO1 = 'L';
          SIDE1 = 'R';
          m_t = (ptrdiff_t)m;
          n_t = (ptrdiff_t)n;
          lda_t = (ptrdiff_t)lda;
          ldb_t = (ptrdiff_t)ldb;
          ztrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, (real_T *)&dc,
                (real_T *)&(((::coder::array<creal_T, 2U> *)&A)->data())[0],
                &lda_t, (real_T *)&(B.data())[0], &ldb_t);
        }
      }

      void xtrsm(int32_T m, int32_T n, const ::coder::array<creal_T, 2U> &A,
                 int32_T lda, ::coder::array<creal_T, 2U> &B, int32_T ldb)
      {
        ptrdiff_t lda_t;
        ptrdiff_t ldb_t;
        ptrdiff_t m_t;
        ptrdiff_t n_t;
        char_T DIAGA1;
        char_T SIDE1;
        char_T TRANSA1;
        char_T UPLO1;
        if ((m >= 1) && (n >= 1)) {
          DIAGA1 = 'N';
          TRANSA1 = 'N';
          UPLO1 = 'U';
          SIDE1 = 'R';
          m_t = (ptrdiff_t)m;
          n_t = (ptrdiff_t)n;
          lda_t = (ptrdiff_t)lda;
          ldb_t = (ptrdiff_t)ldb;
          ztrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, (real_T *)&dc,
                (real_T *)&(((::coder::array<creal_T, 2U> *)&A)->data())[0],
                &lda_t, (real_T *)&(B.data())[0], &ldb_t);
        }
      }
    }
  }
}

// End of code generation (xtrsm.cpp)
