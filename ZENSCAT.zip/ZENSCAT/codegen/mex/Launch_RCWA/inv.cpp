//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  inv.cpp
//
//  Code generation for function 'inv'
//


// Include files
#include "inv.h"
#include "Launch_RCWA_data.h"
#include "Launch_RCWA_mexutil.h"
#include "eml_int_forloop_overflow_check.h"
#include "norm.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "blas.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <stddef.h>

// Variable Definitions
static emlrtRSInfo oc_emlrtRSI = { 28, // lineNo
  "repmat",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elmat\\repmat.m"// pathName 
};

static emlrtRSInfo pc_emlrtRSI = { 28, // lineNo
  "colon",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m"// pathName 
};

static emlrtRSInfo qc_emlrtRSI = { 81, // lineNo
  "colon",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m"// pathName 
};

static emlrtRSInfo rc_emlrtRSI = { 126,// lineNo
  "eml_integer_colon_dispatcher",      // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m"// pathName 
};

static emlrtRSInfo sc_emlrtRSI = { 154,// lineNo
  "eml_signed_integer_colon",          // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m"// pathName 
};

static emlrtRSInfo tc_emlrtRSI = { 67, // lineNo
  "xtrsm",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\xtrsm.m"// pathName 
};

static emlrtRSInfo uc_emlrtRSI = { 81, // lineNo
  "xtrsm_blas",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\xtrsm.m"// pathName 
};

static emlrtRSInfo me_emlrtRSI = { 21, // lineNo
  "inv",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo ne_emlrtRSI = { 22, // lineNo
  "inv",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo oe_emlrtRSI = { 173,// lineNo
  "invNxN",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo pe_emlrtRSI = { 174,// lineNo
  "invNxN",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo qe_emlrtRSI = { 177,// lineNo
  "invNxN",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo re_emlrtRSI = { 180,// lineNo
  "invNxN",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo se_emlrtRSI = { 183,// lineNo
  "invNxN",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo te_emlrtRSI = { 190,// lineNo
  "invNxN",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo ue_emlrtRSI = { 14, // lineNo
  "eml_ipiv2perm",                     // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eml_ipiv2perm.m"// pathName 
};

static emlrtRSInfo ve_emlrtRSI = { 42, // lineNo
  "checkcond",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRSInfo we_emlrtRSI = { 46, // lineNo
  "checkcond",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pathName 
};

static emlrtRTEInfo k_emlrtRTEI = { 14,// lineNo
  15,                                  // colNo
  "inv",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pName 
};

static emlrtRTEInfo id_emlrtRTEI = { 21,// lineNo
  5,                                   // colNo
  "inv",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pName 
};

static emlrtRTEInfo jd_emlrtRTEI = { 1,// lineNo
  37,                                  // colNo
  "xgetrf",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pName 
};

static emlrtRTEInfo md_emlrtRTEI = { 150,// lineNo
  20,                                  // colNo
  "colon",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m"// pName 
};

static emlrtRTEInfo nd_emlrtRTEI = { 19,// lineNo
  5,                                   // colNo
  "inv",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\inv.m"// pName 
};

// Function Definitions
namespace coder
{
  void inv(const emlrtStack *sp, const ::coder::array<creal_T, 2U> &x, ::coder::
           array<creal_T, 2U> &y)
  {
    static const int32_T iv[2] = { 1, 6 };

    static const char_T rfmt[6] = { '%', '1', '4', '.', '6', 'e' };

    ptrdiff_t info_t;
    ptrdiff_t lda_t;
    ptrdiff_t ldb_t;
    ptrdiff_t n_t;
    array<ptrdiff_t, 1U> ipiv_t;
    array<ptrdiff_t, 1U> r;
    array<creal_T, 2U> b_x;
    array<int32_T, 2U> ipiv;
    array<int32_T, 2U> p;
    emlrtStack b_st;
    emlrtStack c_st;
    emlrtStack d_st;
    emlrtStack e_st;
    emlrtStack f_st;
    emlrtStack g_st;
    emlrtStack h_st;
    emlrtStack st;
    const mxArray *b_y;
    const mxArray *c_y;
    const mxArray *m;
    char_T str[14];
    char_T DIAGA1;
    char_T SIDE1;
    char_T TRANSA1;
    char_T UPLO1;
    st.prev = sp;
    st.tls = sp->tls;
    b_st.prev = &st;
    b_st.tls = st.tls;
    c_st.prev = &b_st;
    c_st.tls = b_st.tls;
    d_st.prev = &c_st;
    d_st.tls = c_st.tls;
    e_st.prev = &d_st;
    e_st.tls = d_st.tls;
    f_st.prev = &e_st;
    f_st.tls = e_st.tls;
    g_st.prev = &f_st;
    g_st.tls = f_st.tls;
    h_st.prev = &g_st;
    h_st.tls = g_st.tls;
    emlrtHeapReferenceStackEnterFcnR2012b(sp);
    if (x.size(0) != x.size(1)) {
      emlrtErrorWithMessageIdR2018a(sp, &k_emlrtRTEI, "Coder:MATLAB:square",
        "Coder:MATLAB:square", 0);
    }

    if ((x.size(0) == 0) || (x.size(1) == 0)) {
      int32_T b_n;
      y.set_size((&nd_emlrtRTEI), sp, x.size(0), x.size(1));
      b_n = x.size(0) * x.size(1);
      for (int32_T i = 0; i < b_n; i++) {
        y[i] = x[i];
      }
    } else {
      real_T n1x;
      real_T n1xinv;
      real_T rc;
      int32_T b_n;
      int32_T i;
      int32_T k;
      int32_T n;
      int32_T yk;
      st.site = &me_emlrtRSI;
      n = x.size(0);
      y.set_size((&id_emlrtRTEI), (&st), x.size(0), x.size(1));
      b_n = x.size(0) * x.size(1);
      for (i = 0; i < b_n; i++) {
        y[i].re = 0.0;
        y[i].im = 0.0;
      }

      b_st.site = &oe_emlrtRSI;
      b_x.set_size((&jd_emlrtRTEI), (&b_st), x.size(0), x.size(1));
      b_n = x.size(0) * x.size(1);
      for (i = 0; i < b_n; i++) {
        b_x[i] = x[i];
      }

      c_st.site = &lc_emlrtRSI;
      d_st.site = &nc_emlrtRSI;
      info_t = (ptrdiff_t)0.0;
      b_n = muIntScalarMin_sint32(n, n);
      e_st.site = &oc_emlrtRSI;
      r.set_size((&oc_emlrtRTEI), (&d_st), b_n);
      for (i = 0; i < b_n; i++) {
        r[i] = info_t;
      }

      ipiv_t.set_size((&kd_emlrtRTEI), (&c_st), r.size(0));
      info_t = LAPACKE_zgetrf_work(102, (ptrdiff_t)x.size(0), (ptrdiff_t)x.size
        (0), (lapack_complex_double *)&(b_x.data())[0], (ptrdiff_t)x.size(0),
        &(ipiv_t.data())[0]);
      b_n = (int32_T)info_t;
      ipiv.set_size((&ld_emlrtRTEI), (&c_st), 1, ipiv_t.size(0));
      d_st.site = &mc_emlrtRSI;
      if (b_n < 0) {
        if (b_n == -1010) {
          emlrtErrorWithMessageIdR2018a(&d_st, &i_emlrtRTEI, "MATLAB:nomem",
            "MATLAB:nomem", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&d_st, &h_emlrtRTEI,
            "Coder:toolbox:LAPACKCallErrorInfo",
            "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 19, cv1, 12, b_n);
        }
      }

      i = ipiv_t.size(0) - 1;
      for (k = 0; k <= i; k++) {
        ipiv[k] = (int32_T)ipiv_t[k];
      }

      b_st.site = &pe_emlrtRSI;
      c_st.site = &ue_emlrtRSI;
      d_st.site = &pc_emlrtRSI;
      e_st.site = &qc_emlrtRSI;
      f_st.site = &rc_emlrtRSI;
      b_n = x.size(0);
      p.set_size((&md_emlrtRTEI), (&f_st), 1, x.size(0));
      p[0] = 1;
      yk = 1;
      g_st.site = &sc_emlrtRSI;
      if ((2 <= x.size(0)) && (x.size(0) > 2147483646)) {
        h_st.site = &ib_emlrtRSI;
        check_forloop_overflow_error(&h_st);
      }

      for (k = 2; k <= b_n; k++) {
        yk++;
        p[k - 1] = yk;
      }

      i = ipiv.size(1);
      for (k = 0; k < i; k++) {
        b_n = ipiv[k];
        if (b_n > k + 1) {
          yk = p[b_n - 1];
          p[b_n - 1] = p[k];
          p[k] = yk;
        }
      }

      b_st.site = &qe_emlrtRSI;
      if (x.size(0) > 2147483646) {
        c_st.site = &ib_emlrtRSI;
        check_forloop_overflow_error(&c_st);
      }

      for (k = 0; k < n; k++) {
        i = p[k];
        y[k + y.size(0) * (i - 1)] = dc;
        b_st.site = &re_emlrtRSI;
        if ((k + 1 <= n) && (n > 2147483646)) {
          c_st.site = &ib_emlrtRSI;
          check_forloop_overflow_error(&c_st);
        }

        for (yk = k + 1; yk <= n; yk++) {
          if ((y[(yk + y.size(0) * (i - 1)) - 1].re != 0.0) || (y[(yk + y.size(0)
                * (i - 1)) - 1].im != 0.0)) {
            b_n = yk + 1;
            b_st.site = &se_emlrtRSI;
            for (int32_T b_i = b_n; b_i <= n; b_i++) {
              n1x = y[(yk + y.size(0) * (i - 1)) - 1].re * b_x[(b_i + b_x.size(0)
                * (yk - 1)) - 1].im + y[(yk + y.size(0) * (i - 1)) - 1].im *
                b_x[(b_i + b_x.size(0) * (yk - 1)) - 1].re;
              y[(b_i + y.size(0) * (i - 1)) - 1].re = y[(b_i + y.size(0) * (i -
                1)) - 1].re - (y[(yk + y.size(0) * (i - 1)) - 1].re * b_x[(b_i +
                b_x.size(0) * (yk - 1)) - 1].re - y[(yk + y.size(0) * (i - 1)) -
                               1].im * b_x[(b_i + b_x.size(0) * (yk - 1)) - 1].
                               im);
              y[(b_i + y.size(0) * (i - 1)) - 1].im = y[(b_i + y.size(0) * (i -
                1)) - 1].im - n1x;
            }
          }
        }
      }

      b_st.site = &te_emlrtRSI;
      c_st.site = &tc_emlrtRSI;
      d_st.site = &uc_emlrtRSI;
      DIAGA1 = 'N';
      TRANSA1 = 'N';
      UPLO1 = 'U';
      SIDE1 = 'L';
      info_t = (ptrdiff_t)x.size(0);
      n_t = (ptrdiff_t)x.size(0);
      lda_t = (ptrdiff_t)x.size(0);
      ldb_t = (ptrdiff_t)x.size(0);
      ztrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &info_t, &n_t, (real_T *)&dc,
            (real_T *)&(b_x.data())[0], &lda_t, (real_T *)&(y.data())[0], &ldb_t);
      st.site = &ne_emlrtRSI;
      n1x = b_norm(x);
      n1xinv = b_norm(y);
      rc = 1.0 / (n1x * n1xinv);
      if ((n1x == 0.0) || (n1xinv == 0.0) || (rc == 0.0)) {
        b_st.site = &ve_emlrtRSI;
        internal::warning(&b_st);
      } else {
        if (muDoubleScalarIsNaN(rc) || (rc < 2.2204460492503131E-16)) {
          b_st.site = &we_emlrtRSI;
          b_y = NULL;
          m = emlrtCreateCharArray(2, &iv[0]);
          emlrtInitCharArrayR2013a(&b_st, 6, m, &rfmt[0]);
          emlrtAssign(&b_y, m);
          c_y = NULL;
          m = emlrtCreateDoubleScalar(rc);
          emlrtAssign(&c_y, m);
          c_st.site = &ti_emlrtRSI;
          emlrt_marshallIn(&c_st, b_sprintf(&c_st, b_y, c_y, &c_emlrtMCI),
                           "<output of sprintf>", str);
          b_st.site = &we_emlrtRSI;
          internal::warning(&b_st, str);
        }
      }
    }

    emlrtHeapReferenceStackLeaveFcnR2012b(sp);
  }
}

// End of code generation (inv.cpp)
