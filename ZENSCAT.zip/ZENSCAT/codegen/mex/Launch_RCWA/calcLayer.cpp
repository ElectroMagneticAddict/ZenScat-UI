//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  calcLayer.cpp
//
//  Code generation for function 'calcLayer'
//


// Include files
#include "calcLayer.h"
#include "Launch_RCWA_data.h"
#include "eig.h"
#include "eml_mtimes_helper.h"
#include "expm.h"
#include "eye.h"
#include "inv.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "blas.h"
#include "coder_array.h"
#include "mwmathutil.h"
#include <stddef.h>

// Variable Definitions
static emlrtRSInfo mf_emlrtRSI = { 8,  // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo nf_emlrtRSI = { 9,  // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo of_emlrtRSI = { 10, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo pf_emlrtRSI = { 11, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo qf_emlrtRSI = { 13, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo rf_emlrtRSI = { 14, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo sf_emlrtRSI = { 15, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo tf_emlrtRSI = { 16, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo uf_emlrtRSI = { 18, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo vf_emlrtRSI = { 19, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo wf_emlrtRSI = { 20, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo xf_emlrtRSI = { 22, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo yf_emlrtRSI = { 23, // lineNo
  "calcLayer",                         // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pathName 
};

static emlrtRSInfo ag_emlrtRSI = { 49, // lineNo
  "mpower",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\mpower.m"// pathName 
};

static emlrtRSInfo bg_emlrtRSI = { 78, // lineNo
  "matrix_to_scalar_power",            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\mpower.m"// pathName 
};

static emlrtRSInfo cg_emlrtRSI = { 13, // lineNo
  "matrix_to_integer_power",           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\private\\matrix_to_integer_power.m"// pathName 
};

static emlrtRSInfo dg_emlrtRSI = { 68, // lineNo
  "matrix_to_small_integer_power",     // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\private\\matrix_to_integer_power.m"// pathName 
};

static emlrtRTEInfo l_emlrtRTEI = { 38,// lineNo
  15,                                  // colNo
  "mpower",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\mpower.m"// pName 
};

static emlrtECInfo n_emlrtECI = { 2,   // nDims
  23,                                  // lineNo
  28,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtECInfo o_emlrtECI = { 2,   // nDims
  23,                                  // lineNo
  8,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtECInfo p_emlrtECI = { 2,   // nDims
  22,                                  // lineNo
  26,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtECInfo q_emlrtECI = { 2,   // nDims
  22,                                  // lineNo
  8,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtECInfo r_emlrtECI = { 2,   // nDims
  20,                                  // lineNo
  5,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtECInfo s_emlrtECI = { 2,   // nDims
  19,                                  // lineNo
  5,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtBCInfo ab_emlrtBCI = { -1, // iFirst
  -1,                                  // iLast
  18,                                  // lineNo
  46,                                  // colNo
  "device.sub_L",                      // aName
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m",// pName 
  0                                    // checkKind
};

static emlrtECInfo t_emlrtECI = { 2,   // nDims
  13,                                  // lineNo
  19,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtECInfo u_emlrtECI = { 2,   // nDims
  8,                                   // lineNo
  14,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtDCInfo o_emlrtDCI = { 4,   // lineNo
  21,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m",// pName 
  1                                    // checkKind
};

static emlrtBCInfo bb_emlrtBCI = { 1,  // iFirst
  1,                                   // iLast
  3,                                   // lineNo
  32,                                  // colNo
  "device.ERC",                        // aName
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo cb_emlrtBCI = { -1, // iFirst
  -1,                                  // iLast
  3,                                   // lineNo
  22,                                  // colNo
  "device.ERC",                        // aName
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo db_emlrtBCI = { -1, // iFirst
  -1,                                  // iLast
  18,                                  // lineNo
  33,                                  // colNo
  "device.sub_L",                      // aName
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m",// pName 
  0                                    // checkKind
};

static emlrtRTEInfo ce_emlrtRTEI = { 4,// lineNo
  1,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo de_emlrtRTEI = { 5,// lineNo
  1,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo ee_emlrtRTEI = { 6,// lineNo
  1,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo fe_emlrtRTEI = { 3,// lineNo
  7,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo ge_emlrtRTEI = { 13,// lineNo
  19,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo he_emlrtRTEI = { 8,// lineNo
  14,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo ie_emlrtRTEI = { 65,// lineNo
  13,                                  // colNo
  "eml_mtimes_helper",                 // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pName 
};

static emlrtRTEInfo je_emlrtRTEI = { 22,// lineNo
  8,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo ke_emlrtRTEI = { 22,// lineNo
  26,                                  // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo le_emlrtRTEI = { 23,// lineNo
  8,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo me_emlrtRTEI = { 26,// lineNo
  1,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

static emlrtRTEInfo ne_emlrtRTEI = { 27,// lineNo
  1,                                   // colNo
  "calcLayer",                         // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcLayer.m"// pName 
};

// Function Definitions
void calcLayer(const emlrtStack *sp, const coder::array<real_T, 2U> &Kx, real_T
               lam0, real_T N, const coder::array<real_T, 2U> &W0, const coder::
               array<creal_T, 2U> &V0, const coder::array<creal_T, 3U>
               &device_ERC, const coder::array<real_T, 2U> &device_sub_L, real_T
               layer, real_T sub_layer, char_T mode, coder::array<creal_T, 2U>
               &Si_S11, coder::array<creal_T, 2U> &Si_S12, coder::array<creal_T,
               2U> &Si_S21, coder::array<creal_T, 2U> &Si_S22)
{
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  coder::array<creal_T, 2U> A;
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> V;
  coder::array<creal_T, 2U> W;
  coder::array<creal_T, 2U> X;
  coder::array<creal_T, 2U> a;
  coder::array<creal_T, 2U> b_device_ERC;
  coder::array<real_T, 2U> r;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack st;
  real_T alpha1;
  real_T beta1;
  int32_T iv[2];
  int32_T i;
  int32_T loop_ub;
  char_T TRANSA1;
  char_T TRANSB1;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  //  Get parameters for current layer
  if ((static_cast<int32_T>(layer) < 1) || (static_cast<int32_T>(layer) > 1)) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(layer), 1, 1,
      &bb_emlrtBCI, sp);
  }

  if ((static_cast<int32_T>(sub_layer) < 1) || (static_cast<int32_T>(sub_layer) >
       device_ERC.size(2))) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(sub_layer), 1,
      device_ERC.size(2), &cb_emlrtBCI, sp);
  }

  if (N != static_cast<int32_T>(muDoubleScalarFloor(N))) {
    emlrtIntegerCheckR2012b(N, &o_emlrtDCI, sp);
  }

  Si_S12.set_size((&ce_emlrtRTEI), sp, (static_cast<int32_T>(N)),
                  (static_cast<int32_T>(N)));
  loop_ub = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (i = 0; i < loop_ub; i++) {
    Si_S12[i].re = 0.0;
    Si_S12[i].im = 0.0;
  }

  W.set_size((&de_emlrtRTEI), sp, Si_S12.size(0), Si_S12.size(1));
  loop_ub = Si_S12.size(0) * Si_S12.size(1);
  for (i = 0; i < loop_ub; i++) {
    W[i] = Si_S12[i];
  }

  V.set_size((&ee_emlrtRTEI), sp, Si_S12.size(0), Si_S12.size(1));
  loop_ub = Si_S12.size(0) * Si_S12.size(1);
  for (i = 0; i < loop_ub; i++) {
    V[i] = Si_S12[i];
  }

  if (mode == 'E') {
    //  include air as well after the first try
    st.site = &mf_emlrtRSI;
    if (Kx.size(0) != Kx.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &l_emlrtRTEI, "MATLAB:square",
        "MATLAB:square", 0);
    }

    b_st.site = &ag_emlrtRSI;
    c_st.site = &bg_emlrtRSI;
    d_st.site = &cg_emlrtRSI;
    e_st.site = &dg_emlrtRSI;
    f_st.site = &ye_emlrtRSI;
    if (Kx.size(1) != Kx.size(0)) {
      if ((Kx.size(0) == 1) && (Kx.size(1) == 1)) {
        emlrtErrorWithMessageIdR2018a(&f_st, &g_emlrtRTEI,
          "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&f_st, &f_emlrtRTEI, "MATLAB:innerdim",
          "MATLAB:innerdim", 0);
      }
    }

    f_st.site = &xe_emlrtRSI;
    if ((Kx.size(0) == 0) || (Kx.size(1) == 0)) {
      r.set_size((&he_emlrtRTEI), (&f_st), Kx.size(0), Kx.size(1));
      loop_ub = Kx.size(0) * Kx.size(1);
      for (i = 0; i < loop_ub; i++) {
        r[i] = 0.0;
      }
    } else {
      g_st.site = &af_emlrtRSI;
      h_st.site = &bf_emlrtRSI;
      TRANSB1 = 'N';
      TRANSA1 = 'N';
      alpha1 = 1.0;
      beta1 = 0.0;
      m_t = (ptrdiff_t)Kx.size(0);
      n_t = (ptrdiff_t)Kx.size(1);
      k_t = (ptrdiff_t)Kx.size(1);
      lda_t = (ptrdiff_t)Kx.size(0);
      ldb_t = (ptrdiff_t)Kx.size(0);
      ldc_t = (ptrdiff_t)Kx.size(0);
      r.set_size((&pd_emlrtRTEI), (&h_st), Kx.size(0), Kx.size(1));
      dgemm(&TRANSA1, &TRANSB1, &m_t, &n_t, &k_t, &alpha1, &(((coder::array<
               real_T, 2U> *)&Kx)->data())[0], &lda_t, &(((coder::array<real_T,
               2U> *)&Kx)->data())[0], &ldb_t, &beta1, &(r.data())[0], &ldc_t);
    }

    iv[0] = device_ERC.size(0);
    iv[1] = device_ERC.size(1);
    emlrtSizeEqCheckNDR2012b(r.size(), &iv[0], &u_emlrtECI, sp);
    b_device_ERC.set_size((&he_emlrtRTEI), sp, r.size(0), r.size(1));
    loop_ub = r.size(1);
    for (i = 0; i < loop_ub; i++) {
      int32_T b_loop_ub;
      b_loop_ub = r.size(0);
      for (int32_T i1 = 0; i1 < b_loop_ub; i1++) {
        b_device_ERC[i1 + b_device_ERC.size(0) * i].re = r[i1 + r.size(0) * i] -
          device_ERC[(i1 + device_ERC.size(0) * i) + device_ERC.size(0) *
          device_ERC.size(1) * (static_cast<int32_T>(sub_layer) - 1)].re;
        b_device_ERC[i1 + b_device_ERC.size(0) * i].im = 0.0 - device_ERC[(i1 +
          device_ERC.size(0) * i) + device_ERC.size(0) * device_ERC.size(1) * (
          static_cast<int32_T>(sub_layer) - 1)].im;
      }
    }

    st.site = &nf_emlrtRSI;
    coder::eig(&st, b_device_ERC, W, Si_S12);
    st.site = &of_emlrtRSI;
    coder::b_sqrt(&st, Si_S12);
    st.site = &pf_emlrtRSI;
    b_st.site = &ye_emlrtRSI;
    coder::dynamic_size_checks(&b_st, W, Si_S12, W.size(1), Si_S12.size(0));
    b_st.site = &xe_emlrtRSI;
    coder::internal::blas::mtimes(&b_st, W, Si_S12, V);
  } else {
    if (mode == 'H') {
      int32_T b_loop_ub;
      int32_T c_loop_ub;
      int32_T i1;
      int32_T i2;
      st.site = &qf_emlrtRSI;
      loop_ub = device_ERC.size(0);
      b_loop_ub = device_ERC.size(1);
      b_device_ERC.set_size((&fe_emlrtRTEI), (&st), device_ERC.size(0),
                            device_ERC.size(1));
      for (i = 0; i < b_loop_ub; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_device_ERC[i1 + b_device_ERC.size(0) * i] = device_ERC[(i1 +
            device_ERC.size(0) * i) + device_ERC.size(0) * device_ERC.size(1) *
            (static_cast<int32_T>(sub_layer) - 1)];
        }
      }

      b_st.site = &qf_emlrtRSI;
      coder::inv(&b_st, b_device_ERC, Si_S12);
      b_st.site = &ye_emlrtRSI;
      if (Kx.size(1) != Si_S12.size(0)) {
        if (((Kx.size(0) == 1) && (Kx.size(1) == 1)) || ((Si_S12.size(0) == 1) &&
             (Si_S12.size(1) == 1))) {
          emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
            "MATLAB:innerdim", 0);
        }
      }

      b_device_ERC.set_size((&xb_emlrtRTEI), (&st), Kx.size(0), Kx.size(1));
      loop_ub = Kx.size(0) * Kx.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_device_ERC[i].re = Kx[i];
        b_device_ERC[i].im = 0.0;
      }

      V.set_size((&yb_emlrtRTEI), (&st), b_device_ERC.size(0), Si_S12.size(1));
      loop_ub = b_device_ERC.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub = Si_S12.size(1);
        for (i1 = 0; i1 < b_loop_ub; i1++) {
          V[i + V.size(0) * i1].re = 0.0;
          V[i + V.size(0) * i1].im = 0.0;
          c_loop_ub = b_device_ERC.size(1);
          for (i2 = 0; i2 < c_loop_ub; i2++) {
            V[i + V.size(0) * i1].re = V[i + V.size(0) * i1].re +
              (b_device_ERC[i + b_device_ERC.size(0) * i2].re * Si_S12[i2 +
               Si_S12.size(0) * i1].re - b_device_ERC[i + b_device_ERC.size(0) *
               i2].im * Si_S12[i2 + Si_S12.size(0) * i1].im);
            V[i + V.size(0) * i1].im = V[i + V.size(0) * i1].im +
              (b_device_ERC[i + b_device_ERC.size(0) * i2].re * Si_S12[i2 +
               Si_S12.size(0) * i1].im + b_device_ERC[i + b_device_ERC.size(0) *
               i2].im * Si_S12[i2 + Si_S12.size(0) * i1].re);
          }
        }
      }

      st.site = &qf_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      if (V.size(1) != Kx.size(0)) {
        if (((V.size(0) == 1) && (V.size(1) == 1)) || ((Kx.size(0) == 1) &&
             (Kx.size(1) == 1))) {
          emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
            "MATLAB:innerdim", 0);
        }
      }

      b_device_ERC.set_size((&xb_emlrtRTEI), (&st), Kx.size(0), Kx.size(1));
      loop_ub = Kx.size(0) * Kx.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_device_ERC[i].re = Kx[i];
        b_device_ERC[i].im = 0.0;
      }

      Si_S12.set_size((&ge_emlrtRTEI), (&st), V.size(0), b_device_ERC.size(1));
      loop_ub = V.size(0);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub = b_device_ERC.size(1);
        for (i1 = 0; i1 < b_loop_ub; i1++) {
          Si_S12[i + Si_S12.size(0) * i1].re = 0.0;
          Si_S12[i + Si_S12.size(0) * i1].im = 0.0;
          c_loop_ub = V.size(1);
          for (i2 = 0; i2 < c_loop_ub; i2++) {
            Si_S12[i + Si_S12.size(0) * i1].re = Si_S12[i + Si_S12.size(0) * i1]
              .re + (V[i + V.size(0) * i2].re * b_device_ERC[i2 +
                     b_device_ERC.size(0) * i1].re - V[i + V.size(0) * i2].im *
                     b_device_ERC[i2 + b_device_ERC.size(0) * i1].im);
            Si_S12[i + Si_S12.size(0) * i1].im = Si_S12[i + Si_S12.size(0) * i1]
              .im + (V[i + V.size(0) * i2].re * b_device_ERC[i2 +
                     b_device_ERC.size(0) * i1].im + V[i + V.size(0) * i2].im *
                     b_device_ERC[i2 + b_device_ERC.size(0) * i1].re);
          }
        }
      }

      st.site = &qf_emlrtRSI;
      coder::eye(&st, N, r);
      emlrtSizeEqCheckNDR2012b(Si_S12.size(), r.size(), &t_emlrtECI, sp);
      st.site = &qf_emlrtRSI;
      loop_ub = Si_S12.size(0) * Si_S12.size(1);
      for (i = 0; i < loop_ub; i++) {
        Si_S12[i].re = Si_S12[i].re - r[i];
        Si_S12[i].im = Si_S12[i].im;
      }

      loop_ub = device_ERC.size(0);
      b_loop_ub = device_ERC.size(1);
      b_device_ERC.set_size((&fe_emlrtRTEI), (&st), device_ERC.size(0),
                            device_ERC.size(1));
      for (i = 0; i < b_loop_ub; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_device_ERC[i1 + b_device_ERC.size(0) * i] = device_ERC[(i1 +
            device_ERC.size(0) * i) + device_ERC.size(0) * device_ERC.size(1) *
            (static_cast<int32_T>(sub_layer) - 1)];
        }
      }

      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, b_device_ERC, Si_S12, device_ERC.size(1),
        Si_S12.size(0));
      loop_ub = device_ERC.size(0);
      b_loop_ub = device_ERC.size(1);
      b_device_ERC.set_size((&fe_emlrtRTEI), (&st), device_ERC.size(0),
                            device_ERC.size(1));
      for (i = 0; i < b_loop_ub; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_device_ERC[i1 + b_device_ERC.size(0) * i] = device_ERC[(i1 +
            device_ERC.size(0) * i) + device_ERC.size(0) * device_ERC.size(1) *
            (static_cast<int32_T>(sub_layer) - 1)];
        }
      }

      b_st.site = &xe_emlrtRSI;
      coder::internal::blas::mtimes(&b_st, b_device_ERC, Si_S12, V);
      st.site = &rf_emlrtRSI;
      coder::eig(&st, V, W, Si_S12);
      st.site = &sf_emlrtRSI;
      coder::b_sqrt(&st, Si_S12);
      st.site = &tf_emlrtRSI;
      loop_ub = device_ERC.size(0);
      b_loop_ub = device_ERC.size(1);
      b_device_ERC.set_size((&fe_emlrtRTEI), (&st), device_ERC.size(0),
                            device_ERC.size(1));
      for (i = 0; i < b_loop_ub; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_device_ERC[i1 + b_device_ERC.size(0) * i] = device_ERC[(i1 +
            device_ERC.size(0) * i) + device_ERC.size(0) * device_ERC.size(1) *
            (static_cast<int32_T>(sub_layer) - 1)];
        }
      }

      b_st.site = &tf_emlrtRSI;
      coder::mldivide(&b_st, b_device_ERC, W, a);
      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, a, Si_S12, a.size(1), Si_S12.size(0));
      b_st.site = &xe_emlrtRSI;
      coder::internal::blas::mtimes(&b_st, a, Si_S12, V);

      //  this is for TM
    }
  }

  if ((static_cast<int32_T>(layer) < 1) || (static_cast<int32_T>(layer) >
       device_sub_L.size(0))) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(layer), 1,
      device_sub_L.size(0), &ab_emlrtBCI, sp);
  }

  alpha1 = 6.2831853071795862 / lam0;
  if ((static_cast<int32_T>(sub_layer) < 1) || (static_cast<int32_T>(sub_layer) >
       device_sub_L.size(1))) {
    emlrtDynamicBoundsCheckR2012b(static_cast<int32_T>(sub_layer), 1,
      device_sub_L.size(1), &db_emlrtBCI, sp);
  }

  beta1 = device_sub_L[device_sub_L.size(0) * (static_cast<int32_T>(sub_layer) -
    1)];
  b_device_ERC.set_size((&ie_emlrtRTEI), sp, Si_S12.size(0), Si_S12.size(1));
  loop_ub = Si_S12.size(0) * Si_S12.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_device_ERC[i].re = beta1 * (alpha1 * -Si_S12[i].re);
    b_device_ERC[i].im = beta1 * (alpha1 * -Si_S12[i].im);
  }

  st.site = &uf_emlrtRSI;
  coder::expm(&st, b_device_ERC, X);
  st.site = &vf_emlrtRSI;
  coder::mldivide(&st, W, W0, A);
  st.site = &vf_emlrtRSI;
  coder::mldivide(&st, V, V0, a);
  emlrtSizeEqCheckNDR2012b(A.size(), a.size(), &s_emlrtECI, sp);
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    A[i].re = A[i].re + a[i].re;
    A[i].im = A[i].im + a[i].im;
  }

  st.site = &wf_emlrtRSI;
  coder::mldivide(&st, W, W0, B);
  st.site = &wf_emlrtRSI;
  coder::mldivide(&st, V, V0, a);
  emlrtSizeEqCheckNDR2012b(B.size(), a.size(), &r_emlrtECI, sp);
  loop_ub = B.size(0) * B.size(1);
  for (i = 0; i < loop_ub; i++) {
    B[i].re = B[i].re - a[i].re;
    B[i].im = B[i].im - a[i].im;
  }

  //  S matrix > where the transverse modulation is not included (perfect for homogeneous layers) 
  st.site = &xf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, X, B, X.size(1), B.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, X, B, V);
  st.site = &xf_emlrtRSI;
  if (A.size(1) != V.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, V, A, Si_S12);
  st.site = &xf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, Si_S12, X, Si_S12.size(1), X.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, Si_S12, X, V);
  st.site = &xf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, V, B, V.size(1), B.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, V, B, a);
  emlrtSizeEqCheckNDR2012b(A.size(), a.size(), &q_emlrtECI, sp);
  st.site = &xf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, X, B, X.size(1), B.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, X, B, V);
  st.site = &xf_emlrtRSI;
  if (A.size(1) != V.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, V, A, Si_S12);
  st.site = &xf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, Si_S12, X, Si_S12.size(1), X.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, Si_S12, X, V);
  st.site = &xf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, V, A, V.size(1), A.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, V, A, W);
  emlrtSizeEqCheckNDR2012b(W.size(), B.size(), &p_emlrtECI, sp);
  V.set_size((&je_emlrtRTEI), sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    V[i].re = A[i].re - a[i].re;
    V[i].im = A[i].im - a[i].im;
  }

  b_device_ERC.set_size((&ke_emlrtRTEI), sp, W.size(0), W.size(1));
  loop_ub = W.size(0) * W.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_device_ERC[i].re = W[i].re - B[i].re;
    b_device_ERC[i].im = W[i].im - B[i].im;
  }

  st.site = &xf_emlrtRSI;
  coder::mldivide(&st, V, b_device_ERC, Si_S11);
  st.site = &yf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, X, B, X.size(1), B.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, X, B, V);
  st.site = &yf_emlrtRSI;
  if (A.size(1) != V.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, V, A, Si_S12);
  st.site = &yf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, Si_S12, X, Si_S12.size(1), X.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, Si_S12, X, V);
  st.site = &yf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, V, B, V.size(1), B.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, V, B, a);
  emlrtSizeEqCheckNDR2012b(A.size(), a.size(), &o_emlrtECI, sp);
  st.site = &yf_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, B, A, Si_S12);
  st.site = &yf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, Si_S12, B, Si_S12.size(1), B.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, Si_S12, B, W);
  emlrtSizeEqCheckNDR2012b(A.size(), W.size(), &n_emlrtECI, sp);
  st.site = &yf_emlrtRSI;
  V.set_size((&le_emlrtRTEI), (&st), A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    V[i].re = A[i].re - a[i].re;
    V[i].im = A[i].im - a[i].im;
  }

  b_st.site = &yf_emlrtRSI;
  coder::mldivide(&b_st, V, X, a);
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    A[i].re = A[i].re - W[i].re;
    A[i].im = A[i].im - W[i].im;
  }

  b_st.site = &ye_emlrtRSI;
  coder::dynamic_size_checks(&b_st, a, A, a.size(1), A.size(0));
  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, a, A, Si_S12);
  Si_S21.set_size((&me_emlrtRTEI), sp, Si_S12.size(0), Si_S12.size(1));
  loop_ub = Si_S12.size(0) * Si_S12.size(1);
  for (i = 0; i < loop_ub; i++) {
    Si_S21[i] = Si_S12[i];
  }

  Si_S22.set_size((&ne_emlrtRTEI), sp, Si_S11.size(0), Si_S11.size(1));
  loop_ub = Si_S11.size(0) * Si_S11.size(1);
  for (i = 0; i < loop_ub; i++) {
    Si_S22[i] = Si_S11[i];
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

// End of code generation (calcLayer.cpp)
