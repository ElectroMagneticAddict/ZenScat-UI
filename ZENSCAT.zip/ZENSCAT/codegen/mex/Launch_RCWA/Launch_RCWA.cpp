//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  Launch_RCWA.cpp
//
//  Code generation for function 'Launch_RCWA'
//


// Include files
#include "Launch_RCWA.h"
#include "Launch_RCWA_data.h"
#include "Launch_RCWA_types.h"
#include "abs.h"
#include "calcLayer.h"
#include "calcReflectionSide.h"
#include "calcTransmissionSide.h"
#include "diag.h"
#include "eml_mtimes_helper.h"
#include "eye.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "power.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "star.h"
#include "sum.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Type Definitions
struct struct_T
{
  coder::array<creal_T, 2U> S11;
  coder::array<creal_T, 2U> S12;
  coder::array<creal_T, 2U> S21;
  coder::array<creal_T, 2U> S22;
};

// Variable Definitions
static emlrtRSInfo emlrtRSI = { 5,     // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo b_emlrtRSI = { 6,   // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo c_emlrtRSI = { 32,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo d_emlrtRSI = { 33,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo e_emlrtRSI = { 34,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo f_emlrtRSI = { 35,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo g_emlrtRSI = { 40,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo h_emlrtRSI = { 41,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo i_emlrtRSI = { 44,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo j_emlrtRSI = { 45,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo k_emlrtRSI = { 47,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo l_emlrtRSI = { 49,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo m_emlrtRSI = { 50,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo n_emlrtRSI = { 51,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo o_emlrtRSI = { 52,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo p_emlrtRSI = { 56,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo q_emlrtRSI = { 58,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo r_emlrtRSI = { 59,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo s_emlrtRSI = { 60,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo t_emlrtRSI = { 62,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo u_emlrtRSI = { 64,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo v_emlrtRSI = { 65,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo w_emlrtRSI = { 66,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo x_emlrtRSI = { 68,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo y_emlrtRSI = { 70,  // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo ab_emlrtRSI = { 72, // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo bb_emlrtRSI = { 73, // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo cb_emlrtRSI = { 74, // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo db_emlrtRSI = { 76, // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo eb_emlrtRSI = { 81, // lineNo
  "Launch_RCWA",                       // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pathName 
};

static emlrtRSInfo jb_emlrtRSI = { 3,  // lineNo
  "calcK",                             // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pathName 
};

static emlrtRSInfo kb_emlrtRSI = { 14, // lineNo
  "calcK",                             // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pathName 
};

static emlrtRSInfo lb_emlrtRSI = { 15, // lineNo
  "calcK",                             // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pathName 
};

static emlrtRSInfo mb_emlrtRSI = { 16, // lineNo
  "calcK",                             // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pathName 
};

static emlrtRSInfo ub_emlrtRSI = { 3,  // lineNo
  "calcFreeSpace",                     // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pathName 
};

static emlrtRSInfo vb_emlrtRSI = { 4,  // lineNo
  "calcFreeSpace",                     // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pathName 
};

static emlrtRSInfo wb_emlrtRSI = { 5,  // lineNo
  "calcFreeSpace",                     // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pathName 
};

static emlrtRSInfo xb_emlrtRSI = { 7,  // lineNo
  "calcFreeSpace",                     // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pathName 
};

static emlrtRSInfo yb_emlrtRSI = { 9,  // lineNo
  "calcFreeSpace",                     // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pathName 
};

static emlrtRSInfo ac_emlrtRSI = { 10, // lineNo
  "calcFreeSpace",                     // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pathName 
};

static emlrtDCInfo emlrtDCI = { 11,    // lineNo
  24,                                  // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m",// pName 
  1                                    // checkKind
};

static emlrtECInfo emlrtECI = { 2,     // nDims
  4,                                   // lineNo
  10,                                  // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtECInfo b_emlrtECI = { 2,   // nDims
  3,                                   // lineNo
  24,                                  // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtECInfo c_emlrtECI = { 2,   // nDims
  16,                                  // lineNo
  30,                                  // colNo
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pName 
};

static emlrtECInfo d_emlrtECI = { 2,   // nDims
  15,                                  // lineNo
  25,                                  // colNo
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pName 
};

static emlrtBCInfo emlrtBCI = { -1,    // iFirst
  -1,                                  // iLast
  11,                                  // lineNo
  7,                                   // colNo
  "S",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo b_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  14,                                  // lineNo
  5,                                   // colNo
  "src",                               // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtRTEInfo b_emlrtRTEI = { 38,// lineNo
  20,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtBCInfo c_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  30,                                  // lineNo
  27,                                  // colNo
  "grid.Theta",                        // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtDCInfo b_emlrtDCI = { 7,   // lineNo
  24,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo c_emlrtDCI = { 4,   // lineNo
  24,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo d_emlrtDCI = { 4,   // lineNo
  24,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  4                                    // checkKind
};

static emlrtDCInfo e_emlrtDCI = { 4,   // lineNo
  26,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo f_emlrtDCI = { 8,   // lineNo
  24,                                  // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo g_emlrtDCI = { 8,   // lineNo
  26,                                  // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo h_emlrtDCI = { 4,   // lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo i_emlrtDCI = { 8,   // lineNo
  12,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  1                                    // checkKind
};

static emlrtDCInfo j_emlrtDCI = { 8,   // lineNo
  12,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  4                                    // checkKind
};

static emlrtDCInfo k_emlrtDCI = { 13,  // lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  1                                    // checkKind
};

static emlrtBCInfo d_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  28,                                  // lineNo
  12,                                  // colNo
  "grid.Lam0",                         // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo e_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  11,                                  // lineNo
  29,                                  // colNo
  "M",                                 // aName
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo f_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  11,                                  // lineNo
  5,                                   // colNo
  "k_x",                               // aName
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo g_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  13,                                  // lineNo
  1,                                   // colNo
  "k_x",                               // aName
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m",// pName 
  0                                    // checkKind
};

static emlrtDCInfo l_emlrtDCI = { 8,   // lineNo
  1,                                   // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m",// pName 
  1                                    // checkKind
};

static emlrtBCInfo h_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  53,                                  // lineNo
  27,                                  // colNo
  "R",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo i_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  53,                                  // lineNo
  8,                                   // colNo
  "REF.minus_1",                       // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo j_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  54,                                  // lineNo
  26,                                  // colNo
  "R",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo k_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  54,                                  // lineNo
  8,                                   // colNo
  "REF.plus_1",                        // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo l_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  55,                                  // lineNo
  24,                                  // colNo
  "R",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo m_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  55,                                  // lineNo
  8,                                   // colNo
  "REF.REF0",                          // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo n_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  56,                                  // lineNo
  8,                                   // colNo
  "REF.sum",                           // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo o_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  78,                                  // lineNo
  27,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo p_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  78,                                  // lineNo
  8,                                   // colNo
  "TRN.minus_1",                       // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo q_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  79,                                  // lineNo
  26,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo r_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  79,                                  // lineNo
  8,                                   // colNo
  "TRN.plus_1",                        // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo s_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  80,                                  // lineNo
  24,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo t_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  80,                                  // lineNo
  8,                                   // colNo
  "TRN.TRN0",                          // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo u_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  81,                                  // lineNo
  8,                                   // colNo
  "TRN.sum",                           // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo v_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  68,                                  // lineNo
  38,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo w_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  68,                                  // lineNo
  12,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo x_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  76,                                  // lineNo
  38,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtBCInfo y_emlrtBCI = { -1,  // iFirst
  -1,                                  // iLast
  76,                                  // lineNo
  12,                                  // colNo
  "T",                                 // aName
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m",// pName 
  0                                    // checkKind
};

static emlrtRTEInfo r_emlrtRTEI = { 13,// lineNo
  9,                                   // colNo
  "sqrt",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elfun\\sqrt.m"// pName 
};

static emlrtRTEInfo s_emlrtRTEI = { 14,// lineNo
  9,                                   // colNo
  "asin",                              // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elfun\\asin.m"// pName 
};

static emlrtRTEInfo t_emlrtRTEI = { 4, // lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo u_emlrtRTEI = { 5, // lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo v_emlrtRTEI = { 6, // lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo w_emlrtRTEI = { 7, // lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo x_emlrtRTEI = { 9, // lineNo
  20,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo y_emlrtRTEI = { 13,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo ab_emlrtRTEI = { 17,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo bb_emlrtRTEI = { 18,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo cb_emlrtRTEI = { 19,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo db_emlrtRTEI = { 20,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo eb_emlrtRTEI = { 22,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo fb_emlrtRTEI = { 23,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo gb_emlrtRTEI = { 24,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo hb_emlrtRTEI = { 25,// lineNo
  1,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo ib_emlrtRTEI = { 28,// lineNo
  9,                                   // colNo
  "colon",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\colon.m"// pName 
};

static emlrtRTEInfo jb_emlrtRTEI = { 7,// lineNo
  1,                                   // colNo
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pName 
};

static emlrtRTEInfo kb_emlrtRTEI = { 32,// lineNo
  8,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo lb_emlrtRTEI = { 14,// lineNo
  12,                                  // colNo
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pName 
};

static emlrtRTEInfo mb_emlrtRTEI = { 15,// lineNo
  12,                                  // colNo
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pName 
};

static emlrtRTEInfo nb_emlrtRTEI = { 16,// lineNo
  17,                                  // colNo
  "calcK",                             // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcK.m"// pName 
};

static emlrtRTEInfo ob_emlrtRTEI = { 3,// lineNo
  11,                                  // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtRTEInfo pb_emlrtRTEI = { 8,// lineNo
  1,                                   // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtRTEInfo qb_emlrtRTEI = { 9,// lineNo
  1,                                   // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtRTEInfo rb_emlrtRTEI = { 10,// lineNo
  1,                                   // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtRTEInfo sb_emlrtRTEI = { 11,// lineNo
  1,                                   // colNo
  "calcFreeSpace",                     // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcFreeSpace.m"// pName 
};

static emlrtRTEInfo tb_emlrtRTEI = { 33,// lineNo
  9,                                   // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo ub_emlrtRTEI = { 41,// lineNo
  21,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo vb_emlrtRTEI = { 44,// lineNo
  13,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo wb_emlrtRTEI = { 45,// lineNo
  13,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo ac_emlrtRTEI = { 52,// lineNo
  12,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo bc_emlrtRTEI = { 70,// lineNo
  16,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo cc_emlrtRTEI = { 70,// lineNo
  69,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo dc_emlrtRTEI = { 62,// lineNo
  16,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

static emlrtRTEInfo ec_emlrtRTEI = { 62,// lineNo
  58,                                  // colNo
  "Launch_RCWA",                       // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"// pName 
};

// Function Definitions
void Launch_RCWA(const emlrtStack *sp, real_T NH, const struct0_T *grid, const
                 struct1_T *device, char_T Mode, struct2_T *TRN, struct3_T *REF)
{
  coder::array<struct_T, 2U> S;
  coder::array<creal_T, 2U> Kz;
  coder::array<creal_T, 2U> KzT;
  coder::array<creal_T, 2U> Sref_S11;
  coder::array<creal_T, 2U> Sref_S21;
  coder::array<creal_T, 2U> Sref_S22;
  coder::array<creal_T, 2U> Strn_S11;
  coder::array<creal_T, 2U> Strn_S12;
  coder::array<creal_T, 2U> Strn_S21;
  coder::array<creal_T, 2U> Strn_S22;
  coder::array<creal_T, 2U> V0;
  coder::array<creal_T, 2U> b_b;
  coder::array<creal_T, 2U> b_expl_temp_S11;
  coder::array<creal_T, 2U> b_expl_temp_S12;
  coder::array<creal_T, 2U> b_expl_temp_S21;
  coder::array<creal_T, 2U> b_expl_temp_S22;
  coder::array<creal_T, 2U> c_expl_temp_S11;
  coder::array<creal_T, 2U> c_expl_temp_S12;
  coder::array<creal_T, 2U> c_expl_temp_S21;
  coder::array<creal_T, 2U> c_expl_temp_S22;
  coder::array<creal_T, 2U> d_expl_temp_S11;
  coder::array<creal_T, 2U> d_expl_temp_S12;
  coder::array<creal_T, 2U> d_expl_temp_S21;
  coder::array<creal_T, 2U> d_expl_temp_S22;
  coder::array<creal_T, 2U> expl_temp_S11;
  coder::array<creal_T, 2U> expl_temp_S12;
  coder::array<creal_T, 2U> expl_temp_S21;
  coder::array<creal_T, 2U> expl_temp_S22;
  coder::array<creal_T, 1U> b_Kz;
  coder::array<creal_T, 1U> b_csrc;
  coder::array<cuint8_T, 2U> SG_S11;
  coder::array<cuint8_T, 2U> SG_S22;
  coder::array<real_T, 2U> Kx;
  coder::array<real_T, 2U> M;
  coder::array<real_T, 2U> Omega2;
  coder::array<real_T, 2U> W0;
  coder::array<real_T, 2U> Wtrn;
  coder::array<real_T, 2U> k_x;
  coder::array<real_T, 1U> R;
  coder::array<real_T, 1U> c_b;
  coder::array<real_T, 1U> csrc;
  coder::array<real_T, 1U> r;
  coder::array<real_T, 1U> src;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack st;
  struct_T expl_temp;
  real_T N_tmp;
  real_T a;
  real_T b_a;
  real_T b_grid;
  real_T k0;
  real_T kinc_x;
  real_T kinc_x_tmp;
  int32_T b;
  int32_T b_i;
  int32_T b_loop_ub;
  int32_T c_loop_ub;
  int32_T i;
  int32_T i1;
  int32_T i4;
  int32_T loop_ub;
  int32_T loop_ub_tmp;
  uint32_T Size_Device_idx_0;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  //  Define variables - gali buti kad substrato neturiu
  N_tmp = 2.0 * NH + 1.0;
  if (!(N_tmp >= 0.0)) {
    emlrtNonNegativeCheckR2012b(N_tmp, &d_emlrtDCI, sp);
  }

  i = static_cast<int32_T>(muDoubleScalarFloor(N_tmp));
  if (N_tmp != i) {
    emlrtIntegerCheckR2012b(N_tmp, &c_emlrtDCI, sp);
  }

  expl_temp.S11.set_size((&t_emlrtRTEI), sp, (static_cast<int32_T>(N_tmp)),
    expl_temp.S11.size(1));
  if (N_tmp != i) {
    emlrtIntegerCheckR2012b(N_tmp, &e_emlrtDCI, sp);
  }

  expl_temp.S11.set_size((&t_emlrtRTEI), sp, expl_temp.S11.size(0), (
    static_cast<int32_T>(N_tmp)));
  if (N_tmp != i) {
    emlrtIntegerCheckR2012b(N_tmp, &h_emlrtDCI, sp);
  }

  loop_ub = static_cast<int32_T>(N_tmp) * static_cast<int32_T>(N_tmp);
  for (i1 = 0; i1 < loop_ub; i1++) {
    expl_temp.S11[i1].re = 0.0;
    expl_temp.S11[i1].im = 0.0;
  }

  st.site = &emlrtRSI;
  coder::eye(&st, N_tmp, Wtrn);
  expl_temp.S12.set_size((&u_emlrtRTEI), sp, Wtrn.size(0), Wtrn.size(1));
  loop_ub = Wtrn.size(0) * Wtrn.size(1);
  for (i1 = 0; i1 < loop_ub; i1++) {
    expl_temp.S12[i1].re = Wtrn[i1];
    expl_temp.S12[i1].im = 0.0;
  }

  st.site = &b_emlrtRSI;
  coder::eye(&st, N_tmp, Wtrn);
  expl_temp.S21.set_size((&v_emlrtRTEI), sp, Wtrn.size(0), Wtrn.size(1));
  loop_ub = Wtrn.size(0) * Wtrn.size(1);
  for (i1 = 0; i1 < loop_ub; i1++) {
    expl_temp.S21[i1].re = Wtrn[i1];
    expl_temp.S21[i1].im = 0.0;
  }

  if (N_tmp != i) {
    emlrtIntegerCheckR2012b(N_tmp, &b_emlrtDCI, sp);
  }

  loop_ub = static_cast<int32_T>(N_tmp);
  expl_temp.S22.set_size((&w_emlrtRTEI), sp, loop_ub, loop_ub);
  loop_ub_tmp = static_cast<int32_T>(N_tmp) * static_cast<int32_T>(N_tmp);
  for (i1 = 0; i1 < loop_ub_tmp; i1++) {
    expl_temp.S22[i1].re = 0.0;
    expl_temp.S22[i1].im = 0.0;
  }

  S.set_size((&x_emlrtRTEI), sp, 1, S.size(1));
  kinc_x_tmp = 4.0 * grid->layer_num + 2.0;
  if (!(kinc_x_tmp >= 0.0)) {
    emlrtNonNegativeCheckR2012b(kinc_x_tmp, &j_emlrtDCI, sp);
  }

  if (kinc_x_tmp != static_cast<int32_T>(muDoubleScalarFloor(kinc_x_tmp))) {
    emlrtIntegerCheckR2012b(kinc_x_tmp, &i_emlrtDCI, sp);
  }

  S.set_size((&x_emlrtRTEI), sp, S.size(0), (static_cast<int32_T>(kinc_x_tmp)));
  i1 = static_cast<int32_T>(kinc_x_tmp);
  for (b_i = 0; b_i < i1; b_i++) {
    if (b_i > S.size(1) - 1) {
      emlrtDynamicBoundsCheckR2012b(b_i, 0, S.size(1) - 1, &emlrtBCI, sp);
    }

    S[b_i] = expl_temp;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  if (loop_ub != i) {
    emlrtIntegerCheckR2012b(N_tmp, &k_emlrtDCI, sp);
  }

  src.set_size((&y_emlrtRTEI), sp, loop_ub);
  if (loop_ub != i) {
    emlrtIntegerCheckR2012b(N_tmp, &k_emlrtDCI, sp);
  }

  for (i1 = 0; i1 < loop_ub; i1++) {
    src[i1] = 0.0;
  }

  i1 = static_cast<int32_T>(muDoubleScalarFloor(N_tmp / 2.0)) + 1;
  if (i1 > loop_ub) {
    emlrtDynamicBoundsCheckR2012b(i1, 1, static_cast<int32_T>(N_tmp),
      &b_emlrtBCI, sp);
  }

  src[i1 - 1] = 1.0;

  //  Transmission profiles
  TRN->minus_1.set_size((&ab_emlrtRTEI), sp, grid->Lam0.size(1),
                        grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->minus_1[i1] = 0.0;
  }

  TRN->plus_1.set_size((&bb_emlrtRTEI), sp, grid->Lam0.size(1), grid->Theta.size
                       (1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->plus_1[i1] = 0.0;
  }

  TRN->TRN0.set_size((&cb_emlrtRTEI), sp, grid->Lam0.size(1), grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->TRN0[i1] = 0.0;
  }

  TRN->sum.set_size((&db_emlrtRTEI), sp, grid->Lam0.size(1), grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    TRN->sum[i1] = 0.0;
  }

  //  Reflection profiles
  REF->minus_1.set_size((&eb_emlrtRTEI), sp, grid->Lam0.size(1),
                        grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->minus_1[i1] = 0.0;
  }

  REF->plus_1.set_size((&fb_emlrtRTEI), sp, grid->Lam0.size(1), grid->Theta.size
                       (1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->plus_1[i1] = 0.0;
  }

  REF->REF0.set_size((&gb_emlrtRTEI), sp, grid->Lam0.size(1), grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->REF0[i1] = 0.0;
  }

  REF->sum.set_size((&hb_emlrtRTEI), sp, grid->Lam0.size(1), grid->Theta.size(1));
  b_loop_ub = grid->Lam0.size(1) * grid->Theta.size(1);
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    REF->sum[i1] = 0.0;
  }

  i1 = grid->Lam0.size(1);
  for (b_i = 0; b_i < i1; b_i++) {
    real_T lam0;
    int32_T i2;
    if ((b_i + 1 < 1) || (b_i + 1 > grid->Lam0.size(1))) {
      emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, grid->Lam0.size(1), &d_emlrtBCI,
        sp);
    }

    lam0 = grid->Lam0[b_i];
    i2 = grid->Theta.size(1);
    if (0 <= grid->Theta.size(1) - 1) {
      b = loop_ub;
      k0 = 6.2831853071795862 / lam0;
      b_grid = grid->erT * grid->urT;
      a = grid->erR * grid->urR;
      c_loop_ub = loop_ub_tmp;
      i4 = static_cast<int32_T>(grid->layer_num);
      b_a = 1.0 / grid->erSub;
      Size_Device_idx_0 = static_cast<uint32_T>(device->ER.size(0));
    }

    for (int32_T j = 0; j < i2; j++) {
      real_T ai;
      real_T kzInc;
      real_T kzInc_tmp;
      real_T ninc_tmp;
      real_T theta_i;
      int32_T c_i;
      int32_T end;
      int32_T i3;
      int32_T i5;
      int32_T i6;
      i3 = j + 1;
      if ((i3 < 1) || (i3 > grid->Theta.size(1))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, grid->Theta.size(1), &c_emlrtBCI,
          sp);
      }

      //        %% Kx, Kz and eigen-modes of outer regions
      st.site = &c_emlrtRSI;

      //  Calculate K_x, K_z^{(T)} and K_z^{(R)} diagonal matrices.
      ninc_tmp = grid->erR * grid->urR;
      b_st.site = &jb_emlrtRSI;
      if (ninc_tmp < 0.0) {
        emlrtErrorWithMessageIdR2018a(&b_st, &r_emlrtRTEI,
          "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError", 3,
          4, 4, "sqrt");
      }

      // n_inc
      kinc_x_tmp = muDoubleScalarSin(grid->Theta[j]);
      kinc_x = k0 * muDoubleScalarSqrt(ninc_tmp) * kinc_x_tmp;

      // kx^(inc)
      if (b < 1) {
        M.set_size((&ib_emlrtRTEI), (&st), 1, 0);
      } else {
        b_loop_ub = b - 1;
        M.set_size((&ib_emlrtRTEI), (&st), 1, b);
        for (i3 = 0; i3 <= b_loop_ub; i3++) {
          M[i3] = static_cast<real_T>(i3) + 1.0;
        }
      }

      i3 = M.size(0) * M.size(1);
      M.set_size((&jb_emlrtRTEI), (&st), 1, M.size(1));
      b_loop_ub = i3 - 1;
      for (i3 = 0; i3 <= b_loop_ub; i3++) {
        M[i3] = -((M[i3] - NH) - 1.0);
      }

      //  harmonic orders
      // Size of matrices
      k_x.set_size((&kb_emlrtRTEI), (&st), 1, M.size(1));
      i3 = M.size(1);
      for (c_i = 0; c_i < i3; c_i++) {
        if ((c_i + 1 < 1) || (c_i + 1 > M.size(1))) {
          emlrtDynamicBoundsCheckR2012b(c_i + 1, 1, M.size(1), &e_emlrtBCI, &st);
        }

        if ((c_i + 1 < 1) || (c_i + 1 > k_x.size(1))) {
          emlrtDynamicBoundsCheckR2012b(c_i + 1, 1, k_x.size(1), &f_emlrtBCI,
            &st);
        }

        k_x[c_i] = kinc_x - 6.2831853071795862 * M[c_i] / grid->Lx;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(&st);
        }
      }

      end = k_x.size(1);
      for (c_i = 0; c_i < end; c_i++) {
        if (k_x[c_i] == 0.0) {
          if ((c_i + 1 < 1) || (c_i + 1 > k_x.size(1))) {
            emlrtDynamicBoundsCheckR2012b(c_i + 1, 1, k_x.size(1), &g_emlrtBCI,
              &st);
          }

          k_x[c_i] = 0.001;
        }
      }

      csrc.set_size((&lb_emlrtRTEI), (&st), k_x.size(1));
      b_loop_ub = k_x.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        csrc[i3] = k_x[i3] / k0;
      }

      b_st.site = &kb_emlrtRSI;
      coder::diag(&b_st, csrc, Kx);
      b_st.site = &lb_emlrtRSI;
      coder::eye(&b_st, static_cast<real_T>(M.size(1)), Wtrn);
      b_loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Wtrn[i3] = b_grid * Wtrn[i3];
      }

      b_st.site = &lb_emlrtRSI;
      coder::power(&b_st, Kx, Omega2);
      emlrtSizeEqCheckNDR2012b(Wtrn.size(), Omega2.size(), &d_emlrtECI, &st);
      KzT.set_size((&mb_emlrtRTEI), (&st), Wtrn.size(0), Wtrn.size(1));
      b_loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        KzT[i3].re = Wtrn[i3] - Omega2[i3];
        KzT[i3].im = 0.0;
      }

      b_st.site = &lb_emlrtRSI;
      coder::b_sqrt(&b_st, KzT);
      b_loop_ub = KzT.size(0) * KzT.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        KzT[i3].re = KzT[i3].re;
        KzT[i3].im = -KzT[i3].im;
      }

      b_st.site = &mb_emlrtRSI;
      coder::eye(&b_st, static_cast<real_T>(M.size(1)), Omega2);
      b_loop_ub = Omega2.size(0) * Omega2.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Omega2[i3] = a * Omega2[i3];
      }

      b_st.site = &mb_emlrtRSI;
      coder::power(&b_st, Kx, Wtrn);
      emlrtSizeEqCheckNDR2012b(Omega2.size(), Wtrn.size(), &c_emlrtECI, &st);
      b_b.set_size((&nb_emlrtRTEI), (&st), Omega2.size(0), Omega2.size(1));
      b_loop_ub = Omega2.size(0) * Omega2.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_b[i3].re = Omega2[i3] - Wtrn[i3];
        b_b[i3].im = 0.0;
      }

      b_st.site = &mb_emlrtRSI;
      coder::b_sqrt(&b_st, b_b);
      b_loop_ub = b_b.size(0) * b_b.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_b[i3].re = b_b[i3].re;
        b_b[i3].im = -b_b[i3].im;
      }

      b_loop_ub = b_b.size(0) * b_b.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_b[i3].re = -b_b[i3].re;
        b_b[i3].im = -b_b[i3].im;
      }

      st.site = &d_emlrtRSI;

      //  Free space propagation
      b_st.site = &ub_emlrtRSI;
      coder::eye(&b_st, N_tmp, Wtrn);
      b_st.site = &ub_emlrtRSI;
      coder::power(&b_st, Kx, Omega2);
      emlrtSizeEqCheckNDR2012b(Wtrn.size(), Omega2.size(), &b_emlrtECI, &st);
      Kz.set_size((&ob_emlrtRTEI), (&st), Wtrn.size(0), Wtrn.size(1));
      b_loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Kz[i3].re = Wtrn[i3] - Omega2[i3];
        Kz[i3].im = 0.0;
      }

      b_st.site = &ub_emlrtRSI;
      coder::b_sqrt(&b_st, Kz);
      b_loop_ub = Kz.size(0) * Kz.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Kz[i3].re = Kz[i3].re;
        Kz[i3].im = -Kz[i3].im;
      }

      b_st.site = &vb_emlrtRSI;
      coder::power(&b_st, Kx, Omega2);
      b_st.site = &vb_emlrtRSI;
      coder::eye(&b_st, N_tmp, Wtrn);
      emlrtSizeEqCheckNDR2012b(Omega2.size(), Wtrn.size(), &emlrtECI, &st);
      b_loop_ub = Omega2.size(0) * Omega2.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Omega2[i3] = Omega2[i3] - Wtrn[i3];
      }

      b_st.site = &wb_emlrtRSI;
      coder::eye(&b_st, N_tmp, W0);
      b_loop_ub = Kz.size(0) * Kz.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        kinc_x = 0.0 * Kz[i3].im + Kz[i3].re;
        Kz[i3].re = 0.0 * Kz[i3].re - Kz[i3].im;
        Kz[i3].im = kinc_x;
      }

      b_st.site = &xb_emlrtRSI;
      if (Kz.size(1) != Omega2.size(1)) {
        emlrtErrorWithMessageIdR2018a(&b_st, &emlrtRTEI, "MATLAB:dimagree",
          "MATLAB:dimagree", 0);
      }

      c_st.site = &bc_emlrtRSI;
      coder::internal::mrdiv(&c_st, Omega2, Kz, V0);
      if (loop_ub != i) {
        emlrtIntegerCheckR2012b(N_tmp, &f_emlrtDCI, &st);
      }

      SG_S11.set_size((&pb_emlrtRTEI), (&st), loop_ub, SG_S11.size(1));
      if (loop_ub != i) {
        emlrtIntegerCheckR2012b(N_tmp, &g_emlrtDCI, &st);
      }

      SG_S11.set_size((&pb_emlrtRTEI), (&st), SG_S11.size(0), loop_ub);
      if (loop_ub != i) {
        emlrtIntegerCheckR2012b(N_tmp, &l_emlrtDCI, &st);
      }

      for (i3 = 0; i3 < loop_ub_tmp; i3++) {
        SG_S11[i3].re = 0U;
        SG_S11[i3].im = 0U;
      }

      b_st.site = &yb_emlrtRSI;
      coder::eye(&b_st, N_tmp, Wtrn);
      expl_temp.S12.set_size((&qb_emlrtRTEI), (&st), Wtrn.size(0), Wtrn.size(1));
      b_loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        expl_temp.S12[i3].re = Wtrn[i3];
        expl_temp.S12[i3].im = 0.0;
      }

      b_st.site = &ac_emlrtRSI;
      coder::eye(&b_st, N_tmp, Wtrn);
      expl_temp.S21.set_size((&rb_emlrtRTEI), (&st), Wtrn.size(0), Wtrn.size(1));
      b_loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        expl_temp.S21[i3].re = Wtrn[i3];
        expl_temp.S21[i3].im = 0.0;
      }

      if (loop_ub != i) {
        emlrtIntegerCheckR2012b(N_tmp, &emlrtDCI, &st);
      }

      SG_S22.set_size((&sb_emlrtRTEI), (&st), loop_ub, loop_ub);
      for (i3 = 0; i3 < c_loop_ub; i3++) {
        SG_S22[i3].re = 0U;
        SG_S22[i3].im = 0U;
      }

      expl_temp.S11.set_size((&tb_emlrtRTEI), sp, SG_S11.size(0), SG_S11.size(1));
      b_loop_ub = SG_S11.size(0) * SG_S11.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        expl_temp.S11[i3].re = SG_S11[i3].re;
        expl_temp.S11[i3].im = SG_S11[i3].im;
      }

      expl_temp.S22.set_size((&tb_emlrtRTEI), sp, SG_S22.size(0), SG_S22.size(1));
      b_loop_ub = SG_S22.size(0) * SG_S22.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        expl_temp.S22[i3].re = SG_S22[i3].re;
        expl_temp.S22[i3].im = SG_S22[i3].im;
      }

      st.site = &e_emlrtRSI;
      calcReflectionSide(&st, Kx, b_b, N_tmp, W0, V0, grid->urR, grid->erR, Mode,
                         Omega2, Sref_S11, Kz, Sref_S21, Sref_S22);
      st.site = &f_emlrtRSI;
      calcTransmissionSide(&st, Kx, KzT, N_tmp, W0, V0, grid->urT, grid->erT,
                           Mode, Wtrn, Strn_S11, Strn_S12, Strn_S21, Strn_S22);

      //        %% S matrices for a device
      //  <- Size of the device for sub_L calculations
      emlrtForLoopVectorCheckR2012b(1.0, 1.0, grid->layer_num, mxDOUBLE_CLASS,
        static_cast<int32_T>(grid->layer_num), &b_emlrtRTEI, sp);
      for (end = 0; end < i4; end++) {
        i3 = static_cast<int32_T>(Size_Device_idx_0);
        for (c_i = 0; c_i < i3; c_i++) {
          st.site = &g_emlrtRSI;
          calcLayer(&st, Kx, lam0, N_tmp, W0, V0, device->ERC, device->sub_L,
                    static_cast<real_T>(end) + 1.0, static_cast<real_T>(c_i) +
                    1.0, Mode, expl_temp_S11, expl_temp_S12, expl_temp_S21,
                    b_expl_temp_S22);
          c_expl_temp_S22.set_size((&ub_emlrtRTEI), sp, expl_temp.S22.size(0),
            expl_temp.S22.size(1));
          b_loop_ub = expl_temp.S22.size(0) * expl_temp.S22.size(1);
          for (i5 = 0; i5 < b_loop_ub; i5++) {
            c_expl_temp_S22[i5] = expl_temp.S22[i5];
          }

          c_expl_temp_S21.set_size((&ub_emlrtRTEI), sp, expl_temp.S21.size(0),
            expl_temp.S21.size(1));
          b_loop_ub = expl_temp.S21.size(0) * expl_temp.S21.size(1);
          for (i5 = 0; i5 < b_loop_ub; i5++) {
            c_expl_temp_S21[i5] = expl_temp.S21[i5];
          }

          c_expl_temp_S12.set_size((&ub_emlrtRTEI), sp, expl_temp.S12.size(0),
            expl_temp.S12.size(1));
          b_loop_ub = expl_temp.S12.size(0) * expl_temp.S12.size(1);
          for (i5 = 0; i5 < b_loop_ub; i5++) {
            c_expl_temp_S12[i5] = expl_temp.S12[i5];
          }

          c_expl_temp_S11.set_size((&ub_emlrtRTEI), sp, expl_temp.S11.size(0),
            expl_temp.S11.size(1));
          b_loop_ub = expl_temp.S11.size(0) * expl_temp.S11.size(1);
          for (i5 = 0; i5 < b_loop_ub; i5++) {
            c_expl_temp_S11[i5] = expl_temp.S11[i5];
          }

          st.site = &h_emlrtRSI;
          star(&st, c_expl_temp_S11, c_expl_temp_S12, c_expl_temp_S21,
               c_expl_temp_S22, expl_temp_S11, expl_temp_S12, expl_temp_S21,
               b_expl_temp_S22, expl_temp.S11, expl_temp.S12, expl_temp.S21,
               expl_temp.S22);
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      expl_temp_S22.set_size((&vb_emlrtRTEI), sp, expl_temp.S22.size(0),
        expl_temp.S22.size(1));
      b_loop_ub = expl_temp.S22.size(0) * expl_temp.S22.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        expl_temp_S22[i3] = expl_temp.S22[i3];
      }

      b_expl_temp_S21.set_size((&vb_emlrtRTEI), sp, expl_temp.S21.size(0),
        expl_temp.S21.size(1));
      b_loop_ub = expl_temp.S21.size(0) * expl_temp.S21.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_expl_temp_S21[i3] = expl_temp.S21[i3];
      }

      b_expl_temp_S12.set_size((&vb_emlrtRTEI), sp, expl_temp.S12.size(0),
        expl_temp.S12.size(1));
      b_loop_ub = expl_temp.S12.size(0) * expl_temp.S12.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_expl_temp_S12[i3] = expl_temp.S12[i3];
      }

      b_expl_temp_S11.set_size((&vb_emlrtRTEI), sp, expl_temp.S11.size(0),
        expl_temp.S11.size(1));
      b_loop_ub = expl_temp.S11.size(0) * expl_temp.S11.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_expl_temp_S11[i3] = expl_temp.S11[i3];
      }

      st.site = &i_emlrtRSI;
      star(&st, Sref_S11, Kz, Sref_S21, Sref_S22, b_expl_temp_S11,
           b_expl_temp_S12, b_expl_temp_S21, expl_temp_S22, expl_temp.S11,
           expl_temp.S12, expl_temp.S21, expl_temp.S22);
      d_expl_temp_S22.set_size((&wb_emlrtRTEI), sp, expl_temp.S22.size(0),
        expl_temp.S22.size(1));
      b_loop_ub = expl_temp.S22.size(0) * expl_temp.S22.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        d_expl_temp_S22[i3] = expl_temp.S22[i3];
      }

      d_expl_temp_S21.set_size((&wb_emlrtRTEI), sp, expl_temp.S21.size(0),
        expl_temp.S21.size(1));
      b_loop_ub = expl_temp.S21.size(0) * expl_temp.S21.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        d_expl_temp_S21[i3] = expl_temp.S21[i3];
      }

      d_expl_temp_S12.set_size((&wb_emlrtRTEI), sp, expl_temp.S12.size(0),
        expl_temp.S12.size(1));
      b_loop_ub = expl_temp.S12.size(0) * expl_temp.S12.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        d_expl_temp_S12[i3] = expl_temp.S12[i3];
      }

      d_expl_temp_S11.set_size((&wb_emlrtRTEI), sp, expl_temp.S11.size(0),
        expl_temp.S11.size(1));
      b_loop_ub = expl_temp.S11.size(0) * expl_temp.S11.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        d_expl_temp_S11[i3] = expl_temp.S11[i3];
      }

      st.site = &j_emlrtRSI;
      star(&st, d_expl_temp_S11, d_expl_temp_S12, d_expl_temp_S21,
           d_expl_temp_S22, Strn_S11, Strn_S12, Strn_S21, Strn_S22,
           expl_temp.S11, expl_temp.S12, expl_temp.S21, expl_temp.S22);

      //        %% Calculate Source Mode Coefficients
      st.site = &k_emlrtRSI;
      coder::mldivide(&st, Omega2, src, csrc);

      //        %% REFLECTED FIELDS
      st.site = &l_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, Omega2, expl_temp.S11, Omega2.size(1),
        expl_temp.S11.size(0));
      Sref_S11.set_size((&xb_emlrtRTEI), (&st), Omega2.size(0), Omega2.size(1));
      b_loop_ub = Omega2.size(0) * Omega2.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Sref_S11[i3].re = Omega2[i3];
        Sref_S11[i3].im = 0.0;
      }

      Kz.set_size((&yb_emlrtRTEI), (&st), Sref_S11.size(0), expl_temp.S11.size(1));
      b_loop_ub = Sref_S11.size(0);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        end = expl_temp.S11.size(1);
        for (i5 = 0; i5 < end; i5++) {
          Kz[i3 + Kz.size(0) * i5].re = 0.0;
          Kz[i3 + Kz.size(0) * i5].im = 0.0;
          c_i = Sref_S11.size(1);
          for (i6 = 0; i6 < c_i; i6++) {
            Kz[i3 + Kz.size(0) * i5].re = Kz[i3 + Kz.size(0) * i5].re +
              (Sref_S11[i3 + Sref_S11.size(0) * i6].re * expl_temp.S11[i6 +
               expl_temp.S11.size(0) * i5].re - Sref_S11[i3 + Sref_S11.size(0) *
               i6].im * expl_temp.S11[i6 + expl_temp.S11.size(0) * i5].im);
            Kz[i3 + Kz.size(0) * i5].im = Kz[i3 + Kz.size(0) * i5].im +
              (Sref_S11[i3 + Sref_S11.size(0) * i6].re * expl_temp.S11[i6 +
               expl_temp.S11.size(0) * i5].im + Sref_S11[i3 + Sref_S11.size(0) *
               i6].im * expl_temp.S11[i6 + expl_temp.S11.size(0) * i5].re);
          }
        }
      }

      st.site = &l_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, Kz, csrc, Kz.size(1), csrc.size(0));
      b_csrc.set_size((&xb_emlrtRTEI), sp, csrc.size(0));
      b_loop_ub = csrc.size(0);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_csrc[i3].re = csrc[i3];
        b_csrc[i3].im = 0.0;
      }

      b_Kz.set_size((&xb_emlrtRTEI), sp, Kz.size(0));
      b_loop_ub = Kz.size(0);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_Kz[i3].re = 0.0;
        b_Kz[i3].im = 0.0;
        end = Kz.size(1);
        for (i5 = 0; i5 < end; i5++) {
          b_Kz[i3].re = b_Kz[i3].re + (Kz[i3 + Kz.size(0) * i5].re * b_csrc[i5].
            re - Kz[i3 + Kz.size(0) * i5].im * b_csrc[i5].im);
          b_Kz[i3].im = b_Kz[i3].im + (Kz[i3 + Kz.size(0) * i5].re * b_csrc[i5].
            im + Kz[i3 + Kz.size(0) * i5].im * b_csrc[i5].re);
        }
      }

      st.site = &m_emlrtRSI;
      coder::b_abs(&st, b_Kz, r);
      st.site = &m_emlrtRSI;
      coder::power(&st, r, c_b);
      st.site = &n_emlrtRSI;
      if (ninc_tmp < 0.0) {
        emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
          "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError", 3,
          4, 4, "sqrt");
      }

      kzInc_tmp = muDoubleScalarCos(grid->Theta[j]);
      kzInc = kzInc_tmp * muDoubleScalarSqrt(ninc_tmp);
      st.site = &o_emlrtRSI;
      Omega2.set_size((&ac_emlrtRTEI), (&st), b_b.size(0), b_b.size(1));
      b_loop_ub = b_b.size(0) * b_b.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        kinc_x = -b_b[i3].re;
        ai = -b_b[i3].im;
        if (ai == 0.0) {
          kinc_x /= kzInc;
        } else if (kinc_x == 0.0) {
          kinc_x = 0.0;
        } else {
          kinc_x /= kzInc;
        }

        Omega2[i3] = kinc_x;
      }

      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, Omega2, c_b, Omega2.size(1), c_b.size(0));
      b_st.site = &xe_emlrtRSI;
      coder::internal::blas::mtimes(&b_st, Omega2, c_b, R);
      i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size(0))
        / 2.0));
      if ((i3 < 1) || (i3 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &h_emlrtBCI, sp);
      }

      if ((b_i + 1 < 1) || (b_i + 1 > REF->minus_1.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->minus_1.size(0),
          &i_emlrtBCI, sp);
      }

      if ((j + 1 < 1) || (j + 1 > REF->minus_1.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->minus_1.size(1),
          &i_emlrtBCI, sp);
      }

      REF->minus_1[b_i + REF->minus_1.size(0) * j] = R[i3 - 1];
      i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size(0))
        / 2.0)) + 2;
      if ((i3 < 1) || (i3 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &j_emlrtBCI, sp);
      }

      if ((b_i + 1 < 1) || (b_i + 1 > REF->plus_1.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->plus_1.size(0),
          &k_emlrtBCI, sp);
      }

      if ((j + 1 < 1) || (j + 1 > REF->plus_1.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->plus_1.size(1), &k_emlrtBCI,
          sp);
      }

      REF->plus_1[b_i + REF->plus_1.size(0) * j] = R[i3 - 1];
      i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size(0))
        / 2.0)) + 1;
      if ((i3 < 1) || (i3 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &l_emlrtBCI, sp);
      }

      if ((b_i + 1 < 1) || (b_i + 1 > REF->REF0.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->REF0.size(0), &m_emlrtBCI,
          sp);
      }

      if ((j + 1 < 1) || (j + 1 > REF->REF0.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->REF0.size(1), &m_emlrtBCI,
          sp);
      }

      REF->REF0[b_i + REF->REF0.size(0) * j] = R[i3 - 1];
      st.site = &p_emlrtRSI;
      kinc_x = coder::sum(&st, R);
      if ((b_i + 1 < 1) || (b_i + 1 > REF->sum.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, REF->sum.size(0), &n_emlrtBCI,
          sp);
      }

      if ((j + 1 < 1) || (j + 1 > REF->sum.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, REF->sum.size(1), &n_emlrtBCI,
          sp);
      }

      REF->sum[b_i + REF->sum.size(0) * j] = muDoubleScalarAbs(kinc_x);

      //  all reflection orders
      //        %% TRANSMITTED FIELDS
      st.site = &q_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, Wtrn, expl_temp.S21, Wtrn.size(1),
        expl_temp.S21.size(0));
      Sref_S11.set_size((&xb_emlrtRTEI), (&st), Wtrn.size(0), Wtrn.size(1));
      b_loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        Sref_S11[i3].re = Wtrn[i3];
        Sref_S11[i3].im = 0.0;
      }

      Kz.set_size((&yb_emlrtRTEI), (&st), Sref_S11.size(0), expl_temp.S21.size(1));
      b_loop_ub = Sref_S11.size(0);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        end = expl_temp.S21.size(1);
        for (i5 = 0; i5 < end; i5++) {
          Kz[i3 + Kz.size(0) * i5].re = 0.0;
          Kz[i3 + Kz.size(0) * i5].im = 0.0;
          c_i = Sref_S11.size(1);
          for (i6 = 0; i6 < c_i; i6++) {
            Kz[i3 + Kz.size(0) * i5].re = Kz[i3 + Kz.size(0) * i5].re +
              (Sref_S11[i3 + Sref_S11.size(0) * i6].re * expl_temp.S21[i6 +
               expl_temp.S21.size(0) * i5].re - Sref_S11[i3 + Sref_S11.size(0) *
               i6].im * expl_temp.S21[i6 + expl_temp.S21.size(0) * i5].im);
            Kz[i3 + Kz.size(0) * i5].im = Kz[i3 + Kz.size(0) * i5].im +
              (Sref_S11[i3 + Sref_S11.size(0) * i6].re * expl_temp.S21[i6 +
               expl_temp.S21.size(0) * i5].im + Sref_S11[i3 + Sref_S11.size(0) *
               i6].im * expl_temp.S21[i6 + expl_temp.S21.size(0) * i5].re);
          }
        }
      }

      st.site = &q_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      coder::dynamic_size_checks(&b_st, Kz, csrc, Kz.size(1), csrc.size(0));
      b_csrc.set_size((&xb_emlrtRTEI), sp, csrc.size(0));
      b_loop_ub = csrc.size(0);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_csrc[i3].re = csrc[i3];
        b_csrc[i3].im = 0.0;
      }

      b_Kz.set_size((&xb_emlrtRTEI), sp, Kz.size(0));
      b_loop_ub = Kz.size(0);
      for (i3 = 0; i3 < b_loop_ub; i3++) {
        b_Kz[i3].re = 0.0;
        b_Kz[i3].im = 0.0;
        end = Kz.size(1);
        for (i5 = 0; i5 < end; i5++) {
          b_Kz[i3].re = b_Kz[i3].re + (Kz[i3 + Kz.size(0) * i5].re * b_csrc[i5].
            re - Kz[i3 + Kz.size(0) * i5].im * b_csrc[i5].im);
          b_Kz[i3].im = b_Kz[i3].im + (Kz[i3 + Kz.size(0) * i5].re * b_csrc[i5].
            im + Kz[i3 + Kz.size(0) * i5].im * b_csrc[i5].re);
        }
      }

      st.site = &r_emlrtRSI;
      coder::b_abs(&st, b_Kz, r);
      st.site = &r_emlrtRSI;
      coder::power(&st, r, R);
      st.site = &s_emlrtRSI;
      b_st.site = &ob_emlrtRSI;
      theta_i = b_a * b_a * kinc_x_tmp;
      st.site = &s_emlrtRSI;
      if ((theta_i < -1.0) || (theta_i > 1.0)) {
        emlrtErrorWithMessageIdR2018a(&st, &s_emlrtRTEI,
          "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError", 3,
          4, 4, "asin");
      }

      theta_i = muDoubleScalarAsin(theta_i);

      //  from grating equation - zeroth mode
      if (Mode == 'E') {
        ninc_tmp = grid->urR / grid->urT;
        st.site = &t_emlrtRSI;
        Omega2.set_size((&dc_emlrtRTEI), (&st), KzT.size(0), KzT.size(1));
        b_loop_ub = KzT.size(0) * KzT.size(1);
        for (i3 = 0; i3 < b_loop_ub; i3++) {
          kinc_x = ninc_tmp * KzT[i3].re;
          ai = ninc_tmp * KzT[i3].im;
          if (ai == 0.0) {
            kinc_x /= kzInc;
          } else if (kinc_x == 0.0) {
            kinc_x = 0.0;
          } else {
            kinc_x /= kzInc;
          }

          Omega2[i3] = kinc_x;
        }

        b_st.site = &ye_emlrtRSI;
        coder::dynamic_size_checks(&b_st, Omega2, R, Omega2.size(1), R.size(0));
        csrc.set_size((&ec_emlrtRTEI), (&st), R.size(0));
        b_loop_ub = R.size(0) - 1;
        for (i3 = 0; i3 <= b_loop_ub; i3++) {
          csrc[i3] = R[i3];
        }

        b_st.site = &xe_emlrtRSI;
        coder::internal::blas::mtimes(&b_st, Omega2, csrc, R);

        //            %% Fresnel formula for transmission - s pol
        ai = muDoubleScalarCos(theta_i);
        st.site = &u_emlrtRSI;
        kinc_x = muDoubleScalarSin(theta_i);
        b_st.site = &ob_emlrtRSI;
        kinc_x_tmp = grid->erSub;
        st.site = &u_emlrtRSI;
        if (kinc_x_tmp < 0.0) {
          emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
            "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
            3, 4, 4, "sqrt");
        }

        kinc_x_tmp = muDoubleScalarSqrt(kinc_x_tmp);
        kinc_x = 1.0 - grid->erSub * (kinc_x * kinc_x);
        st.site = &u_emlrtRSI;
        if (kinc_x < 0.0) {
          emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
            "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
            3, 4, 4, "sqrt");
        }

        //  s Fresnel coeff for reflection
        st.site = &v_emlrtRSI;
        b_st.site = &ob_emlrtRSI;
        ninc_tmp = grid->erSub;
        st.site = &v_emlrtRSI;
        if (ninc_tmp < 0.0) {
          emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
            "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
            3, 4, 4, "sqrt");
        }

        ninc_tmp = muDoubleScalarSqrt(ninc_tmp);
        st.site = &v_emlrtRSI;
        if (kinc_x < 0.0) {
          emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
            "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
            3, 4, 4, "sqrt");
        }

        st.site = &w_emlrtRSI;
        ninc_tmp = muDoubleScalarAbs((kinc_x_tmp * ai - muDoubleScalarSqrt
          (kinc_x)) / (ninc_tmp * ai + muDoubleScalarSqrt(kinc_x)));
        b_st.site = &ob_emlrtRSI;
        kinc_x_tmp = 1.0 - ninc_tmp * ninc_tmp;
        st.site = &x_emlrtRSI;
        if (kinc_x_tmp < 0.0) {
          emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
            "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
            3, 4, 4, "sqrt");
        }

        kinc_x_tmp = muDoubleScalarSqrt(kinc_x_tmp);
        i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size
          (0)) / 2.0)) + 1;
        if ((i3 < 1) || (i3 > R.size(0))) {
          emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &v_emlrtBCI, sp);
        }

        i5 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size
          (0)) / 2.0)) + 1;
        if ((i5 < 1) || (i5 > R.size(0))) {
          emlrtDynamicBoundsCheckR2012b(i5, 1, R.size(0), &w_emlrtBCI, sp);
        }

        R[i5 - 1] = R[i3 - 1] * kinc_x_tmp;

        //  zeroth diff. order is observed in the air
      } else {
        if (Mode == 'H') {
          ninc_tmp = grid->erR;
          st.site = &y_emlrtRSI;
          if (ninc_tmp < 0.0) {
            emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
              "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
              3, 4, 4, "sqrt");
          }

          ninc_tmp = muDoubleScalarSqrt(ninc_tmp);
          kinc_x_tmp = grid->erT * kzInc_tmp;
          st.site = &y_emlrtRSI;
          Omega2.set_size((&bc_emlrtRTEI), (&st), KzT.size(0), KzT.size(1));
          b_loop_ub = KzT.size(0) * KzT.size(1);
          for (i3 = 0; i3 < b_loop_ub; i3++) {
            kinc_x = KzT[i3].re * ninc_tmp;
            ai = KzT[i3].im * ninc_tmp;
            if (ai == 0.0) {
              kinc_x /= kinc_x_tmp;
            } else if (kinc_x == 0.0) {
              kinc_x = 0.0;
            } else {
              kinc_x /= kinc_x_tmp;
            }

            Omega2[i3] = kinc_x;
          }

          b_st.site = &ye_emlrtRSI;
          coder::dynamic_size_checks(&b_st, Omega2, R, Omega2.size(1), R.size(0));
          csrc.set_size((&cc_emlrtRTEI), (&st), R.size(0));
          b_loop_ub = R.size(0) - 1;
          for (i3 = 0; i3 <= b_loop_ub; i3++) {
            csrc[i3] = R[i3];
          }

          b_st.site = &xe_emlrtRSI;
          coder::internal::blas::mtimes(&b_st, Omega2, csrc, R);

          //            %% Fresnel formula for transmission - p pol
          ai = muDoubleScalarCos(theta_i);
          st.site = &ab_emlrtRSI;
          kinc_x = muDoubleScalarSin(theta_i);
          b_st.site = &ob_emlrtRSI;
          kinc_x_tmp = grid->erSub;
          st.site = &ab_emlrtRSI;
          if (kinc_x_tmp < 0.0) {
            emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
              "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
              3, 4, 4, "sqrt");
          }

          kinc_x_tmp = muDoubleScalarSqrt(kinc_x_tmp);
          kinc_x = 1.0 - grid->erSub * (kinc_x * kinc_x);
          st.site = &ab_emlrtRSI;
          if (kinc_x < 0.0) {
            emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
              "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
              3, 4, 4, "sqrt");
          }

          st.site = &bb_emlrtRSI;
          b_st.site = &ob_emlrtRSI;
          ninc_tmp = grid->erSub;
          st.site = &bb_emlrtRSI;
          if (ninc_tmp < 0.0) {
            emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
              "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
              3, 4, 4, "sqrt");
          }

          ninc_tmp = muDoubleScalarSqrt(ninc_tmp);
          st.site = &bb_emlrtRSI;
          if (kinc_x < 0.0) {
            emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
              "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
              3, 4, 4, "sqrt");
          }

          st.site = &cb_emlrtRSI;
          ninc_tmp = muDoubleScalarAbs((kinc_x_tmp * muDoubleScalarSqrt(kinc_x)
            - ai) / (ninc_tmp * muDoubleScalarSqrt(kinc_x) + ai));
          b_st.site = &ob_emlrtRSI;
          kinc_x_tmp = 1.0 - ninc_tmp * ninc_tmp;
          st.site = &db_emlrtRSI;
          if (kinc_x_tmp < 0.0) {
            emlrtErrorWithMessageIdR2018a(&st, &r_emlrtRTEI,
              "Coder:toolbox:ElFunDomainError", "Coder:toolbox:ElFunDomainError",
              3, 4, 4, "sqrt");
          }

          kinc_x_tmp = muDoubleScalarSqrt(kinc_x_tmp);
          i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>
            (R.size(0)) / 2.0)) + 1;
          if ((i3 < 1) || (i3 > R.size(0))) {
            emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &x_emlrtBCI, sp);
          }

          i5 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>
            (R.size(0)) / 2.0)) + 1;
          if ((i5 < 1) || (i5 > R.size(0))) {
            emlrtDynamicBoundsCheckR2012b(i5, 1, R.size(0), &y_emlrtBCI, sp);
          }

          R[i5 - 1] = R[i3 - 1] * kinc_x_tmp;

          //  zeroth diff. order is observed in the air
        }
      }

      i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size(0))
        / 2.0));
      if ((i3 < 1) || (i3 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &o_emlrtBCI, sp);
      }

      if ((b_i + 1 < 1) || (b_i + 1 > TRN->minus_1.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->minus_1.size(0),
          &p_emlrtBCI, sp);
      }

      if ((j + 1 < 1) || (j + 1 > TRN->minus_1.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->minus_1.size(1),
          &p_emlrtBCI, sp);
      }

      TRN->minus_1[b_i + TRN->minus_1.size(0) * j] = R[i3 - 1];
      i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size(0))
        / 2.0)) + 2;
      if ((i3 < 1) || (i3 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &q_emlrtBCI, sp);
      }

      if ((b_i + 1 < 1) || (b_i + 1 > TRN->plus_1.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->plus_1.size(0),
          &r_emlrtBCI, sp);
      }

      if ((j + 1 < 1) || (j + 1 > TRN->plus_1.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->plus_1.size(1), &r_emlrtBCI,
          sp);
      }

      TRN->plus_1[b_i + TRN->plus_1.size(0) * j] = R[i3 - 1];
      i3 = static_cast<int32_T>(muDoubleScalarFloor(static_cast<real_T>(R.size(0))
        / 2.0)) + 1;
      if ((i3 < 1) || (i3 > R.size(0))) {
        emlrtDynamicBoundsCheckR2012b(i3, 1, R.size(0), &s_emlrtBCI, sp);
      }

      if ((b_i + 1 < 1) || (b_i + 1 > TRN->TRN0.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->TRN0.size(0), &t_emlrtBCI,
          sp);
      }

      if ((j + 1 < 1) || (j + 1 > TRN->TRN0.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->TRN0.size(1), &t_emlrtBCI,
          sp);
      }

      TRN->TRN0[b_i + TRN->TRN0.size(0) * j] = R[i3 - 1];
      st.site = &eb_emlrtRSI;
      kinc_x = coder::sum(&st, R);
      if ((b_i + 1 < 1) || (b_i + 1 > TRN->sum.size(0))) {
        emlrtDynamicBoundsCheckR2012b(b_i + 1, 1, TRN->sum.size(0), &u_emlrtBCI,
          sp);
      }

      if ((j + 1 < 1) || (j + 1 > TRN->sum.size(1))) {
        emlrtDynamicBoundsCheckR2012b(j + 1, 1, TRN->sum.size(1), &u_emlrtBCI,
          sp);
      }

      TRN->sum[b_i + TRN->sum.size(0) * j] = muDoubleScalarAbs(kinc_x);

      //  all diffraction orders
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

// End of code generation (Launch_RCWA.cpp)
