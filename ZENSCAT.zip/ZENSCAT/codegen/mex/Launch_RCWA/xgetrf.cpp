//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  xgetrf.cpp
//
//  Code generation for function 'xgetrf'
//


// Include files
#include "xgetrf.h"
#include "Launch_RCWA_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <stddef.h>

// Variable Definitions
static emlrtRTEInfo fg_emlrtRTEI = { 54,// lineNo
  5,                                   // colNo
  "xgetrf",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pName 
};

// Function Definitions
namespace coder
{
  namespace internal
  {
    namespace lapack
    {
      void xgetrf(const emlrtStack *sp, int32_T m, int32_T n, ::coder::array<
                  creal_T, 2U> &A, int32_T lda, ::coder::array<int32_T, 2U>
                  &ipiv, int32_T *info)
      {
        array<ptrdiff_t, 1U> ipiv_t;
        array<ptrdiff_t, 1U> r;
        emlrtStack b_st;
        emlrtStack st;
        st.prev = sp;
        st.tls = sp->tls;
        b_st.prev = &st;
        b_st.tls = st.tls;
        emlrtHeapReferenceStackEnterFcnR2012b(sp);
        st.site = &lc_emlrtRSI;
        if ((A.size(0) == 0) || (A.size(1) == 0)) {
          ipiv.set_size((&fg_emlrtRTEI), (&st), 1, 0);
          *info = 0;
        } else {
          ptrdiff_t info_t;
          int32_T i;
          int32_T varargin_1;
          b_st.site = &nc_emlrtRSI;
          info_t = (ptrdiff_t)0.0;
          i = muIntScalarMin_sint32(m, n);
          varargin_1 = muIntScalarMax_sint32(i, 1);
          r.set_size((&oc_emlrtRTEI), (&b_st), varargin_1);
          for (i = 0; i < varargin_1; i++) {
            r[i] = info_t;
          }

          ipiv_t.set_size((&kd_emlrtRTEI), (&st), r.size(0));
          info_t = LAPACKE_zgetrf_work(102, (ptrdiff_t)m, (ptrdiff_t)n,
            (lapack_complex_double *)&(A.data())[0], (ptrdiff_t)lda,
            &(ipiv_t.data())[0]);
          *info = (int32_T)info_t;
          ipiv.set_size((&ld_emlrtRTEI), (&st), 1, ipiv_t.size(0));
          b_st.site = &mc_emlrtRSI;
          if (*info < 0) {
            if (*info == -1010) {
              emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI, "MATLAB:nomem",
                "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &h_emlrtRTEI,
                "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 19, cv1, 12, *info);
            }
          }

          i = ipiv_t.size(0) - 1;
          for (varargin_1 = 0; varargin_1 <= i; varargin_1++) {
            ipiv[varargin_1] = (int32_T)ipiv_t[varargin_1];
          }
        }

        emlrtHeapReferenceStackLeaveFcnR2012b(sp);
      }
    }
  }
}

// End of code generation (xgetrf.cpp)
