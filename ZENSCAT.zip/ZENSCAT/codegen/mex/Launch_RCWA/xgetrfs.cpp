//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  xgetrfs.cpp
//
//  Code generation for function 'xgetrfs'
//


// Include files
#include "xgetrfs.h"
#include "Launch_RCWA_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <stddef.h>

// Function Definitions
namespace coder
{
  namespace internal
  {
    namespace lapack
    {
      int32_T xgetrfs(const emlrtStack *sp, ::coder::array<creal_T, 2U> &A, ::
                      coder::array<creal_T, 2U> &B)
      {
        array<ptrdiff_t, 1U> IPIV;
        array<ptrdiff_t, 1U> r;
        emlrtStack b_st;
        emlrtStack st;
        int32_T info;
        int32_T ma;
        int32_T mb;
        int32_T na;
        st.prev = sp;
        st.tls = sp->tls;
        b_st.prev = &st;
        b_st.tls = st.tls;
        emlrtHeapReferenceStackEnterFcnR2012b(sp);
        ma = A.size(0);
        na = A.size(1);
        mb = B.size(0);
        ma = muIntScalarMin_sint32(ma, na);
        ma = muIntScalarMin_sint32(mb, ma);
        st.site = &ie_emlrtRSI;
        info = 0;
        if ((ma != 0) && (B.size(1) != 0)) {
          ptrdiff_t LDA;
          ptrdiff_t N;
          b_st.site = &ke_emlrtRSI;
          N = (ptrdiff_t)0.0;
          r.set_size((&oc_emlrtRTEI), (&b_st), ma);
          for (na = 0; na < ma; na++) {
            r[na] = N;
          }

          ptrdiff_t INFO;
          IPIV.set_size((&fd_emlrtRTEI), (&st), r.size(0));
          N = (ptrdiff_t)ma;
          LDA = (ptrdiff_t)A.size(0);
          INFO = LAPACKE_zgetrf_work(102, N, N, (lapack_complex_double *)
            &(A.data())[0], LDA, &(IPIV.data())[0]);
          info = (int32_T)INFO;
          b_st.site = &je_emlrtRSI;
          if (info < 0) {
            if (info == -1010) {
              emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI, "MATLAB:nomem",
                "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&b_st, &h_emlrtRTEI,
                "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 19, cv1, 12, info);
            }
          }

          LAPACKE_zgetrs_work(102, 'N', N, (ptrdiff_t)B.size(1),
                              (lapack_complex_double *)&(A.data())[0], LDA,
                              &(IPIV.data())[0], (lapack_complex_double *)
                              &(B.data())[0], (ptrdiff_t)B.size(0));
        }

        emlrtHeapReferenceStackLeaveFcnR2012b(sp);
        return info;
      }
    }
  }
}

// End of code generation (xgetrfs.cpp)
