//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  lusolve.cpp
//
//  Code generation for function 'lusolve'
//


// Include files
#include "lusolve.h"
#include "Launch_RCWA_data.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xgetrfs.h"
#include "coder_array.h"

// Function Definitions
namespace coder
{
  namespace internal
  {
    void lusolve(const emlrtStack *sp, const ::coder::array<creal_T, 2U> &A,
                 const ::coder::array<creal_T, 2U> &B, ::coder::array<creal_T,
                 2U> &X)
    {
      array<creal_T, 2U> b_A;
      emlrtStack b_st;
      emlrtStack c_st;
      emlrtStack st;
      int32_T i;
      int32_T loop_ub;
      st.prev = sp;
      st.tls = sp->tls;
      b_st.prev = &st;
      b_st.tls = st.tls;
      c_st.prev = &b_st;
      c_st.tls = b_st.tls;
      emlrtHeapReferenceStackEnterFcnR2012b(sp);
      st.site = &ec_emlrtRSI;
      b_st.site = &ge_emlrtRSI;
      X.set_size((&gd_emlrtRTEI), (&b_st), B.size(0), B.size(1));
      loop_ub = B.size(0) * B.size(1);
      for (i = 0; i < loop_ub; i++) {
        X[i] = B[i];
      }

      b_A.set_size((&hd_emlrtRTEI), (&b_st), A.size(0), A.size(1));
      loop_ub = A.size(0) * A.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_A[i] = A[i];
      }

      c_st.site = &he_emlrtRSI;
      loop_ub = lapack::xgetrfs(&c_st, b_A, X);
      if (((A.size(0) != 1) || (A.size(1) != 1)) && (loop_ub > 0)) {
        b_st.site = &gc_emlrtRSI;
        c_st.site = &vc_emlrtRSI;
        warning(&c_st);
      }

      emlrtHeapReferenceStackLeaveFcnR2012b(sp);
    }
  }
}

// End of code generation (lusolve.cpp)
