//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  mrdivide_helper.cpp
//
//  Code generation for function 'mrdivide_helper'
//


// Include files
#include "mrdivide_helper.h"
#include "Launch_RCWA_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "xgetrf.h"
#include "xtrsm.h"
#include "coder_array.h"

// Variable Definitions
static emlrtRSInfo cc_emlrtRSI = { 42, // lineNo
  "mrdiv",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pathName 
};

static emlrtRSInfo dc_emlrtRSI = { 44, // lineNo
  "mrdiv",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pathName 
};

static emlrtRSInfo fc_emlrtRSI = { 107,// lineNo
  "lusolveNxN",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

static emlrtRSInfo hc_emlrtRSI = { 135,// lineNo
  "XtimesInvA",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

static emlrtRSInfo ic_emlrtRSI = { 140,// lineNo
  "XtimesInvA",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

static emlrtRSInfo jc_emlrtRSI = { 142,// lineNo
  "XtimesInvA",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

static emlrtRSInfo kc_emlrtRSI = { 147,// lineNo
  "XtimesInvA",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

static emlrtRTEInfo ic_emlrtRTEI = { 44,// lineNo
  32,                                  // colNo
  "mrdivide_helper",                   // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pName 
};

static emlrtRTEInfo jc_emlrtRTEI = { 44,// lineNo
  35,                                  // colNo
  "mrdivide_helper",                   // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pName 
};

static emlrtRTEInfo kc_emlrtRTEI = { 44,// lineNo
  5,                                   // colNo
  "mrdivide_helper",                   // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pName 
};

static emlrtRTEInfo lc_emlrtRTEI = { 42,// lineNo
  5,                                   // colNo
  "mrdivide_helper",                   // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pName 
};

static emlrtRTEInfo mc_emlrtRTEI = { 135,// lineNo
  2,                                   // colNo
  "lusolve",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pName 
};

static emlrtRTEInfo nc_emlrtRTEI = { 31,// lineNo
  5,                                   // colNo
  "mrdivide_helper",                   // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pName 
};

static emlrtRTEInfo od_emlrtRTEI = { 140,// lineNo
  1,                                   // colNo
  "lusolve",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pName 
};

// Function Definitions
namespace coder
{
  namespace internal
  {
    void mrdiv(const emlrtStack *sp, const ::coder::array<real_T, 2U> &A, const ::
               coder::array<creal_T, 2U> &B, ::coder::array<creal_T, 2U> &Y)
    {
      array<creal_T, 2U> b_B;
      array<creal_T, 2U> c_A;
      array<real_T, 2U> b_A;
      array<int32_T, 2U> ipiv;
      emlrtStack b_st;
      emlrtStack c_st;
      emlrtStack d_st;
      emlrtStack e_st;
      emlrtStack st;
      int32_T loop_ub;
      st.prev = sp;
      st.tls = sp->tls;
      b_st.prev = &st;
      b_st.tls = st.tls;
      c_st.prev = &b_st;
      c_st.tls = b_st.tls;
      d_st.prev = &c_st;
      d_st.tls = c_st.tls;
      e_st.prev = &d_st;
      e_st.tls = d_st.tls;
      emlrtHeapReferenceStackEnterFcnR2012b(sp);
      if ((A.size(0) == 0) || (A.size(1) == 0) || ((B.size(0) == 0) || (B.size(1)
            == 0))) {
        Y.set_size((&nc_emlrtRTEI), sp, A.size(0), B.size(0));
        loop_ub = A.size(0) * B.size(0);
        for (int32_T i = 0; i < loop_ub; i++) {
          Y[i].re = 0.0;
          Y[i].im = 0.0;
        }
      } else if (B.size(0) == B.size(1)) {
        int32_T i;
        int32_T nb;
        st.site = &cc_emlrtRSI;
        b_st.site = &ec_emlrtRSI;
        Y.set_size((&lc_emlrtRTEI), (&b_st), A.size(0), A.size(1));
        loop_ub = A.size(0) * A.size(1);
        for (i = 0; i < loop_ub; i++) {
          Y[i].re = A[i];
          Y[i].im = 0.0;
        }

        c_st.site = &fc_emlrtRSI;
        c_A.set_size((&mc_emlrtRTEI), (&c_st), B.size(0), B.size(1));
        loop_ub = B.size(0) * B.size(1);
        for (i = 0; i < loop_ub; i++) {
          c_A[i] = B[i];
        }

        d_st.site = &hc_emlrtRSI;
        lapack::xgetrf(&d_st, B.size(1), B.size(1), c_A, B.size(1), ipiv,
                       &loop_ub);
        nb = Y.size(0);
        d_st.site = &ic_emlrtRSI;
        blas::xtrsm(Y.size(0), B.size(1), c_A, B.size(1), Y, Y.size(0));
        d_st.site = &jc_emlrtRSI;
        blas::b_xtrsm(nb, B.size(1), c_A, B.size(1), Y, nb);
        i = B.size(1) - 1;
        for (int32_T j = i; j >= 1; j--) {
          int32_T i1;
          i1 = ipiv[j - 1];
          if (i1 != j) {
            d_st.site = &kc_emlrtRSI;
            if (nb > 2147483646) {
              e_st.site = &ib_emlrtRSI;
              check_forloop_overflow_error(&e_st);
            }

            for (int32_T b_i = 0; b_i < nb; b_i++) {
              real_T temp_im;
              real_T temp_re;
              temp_re = Y[b_i + Y.size(0) * (j - 1)].re;
              temp_im = Y[b_i + Y.size(0) * (j - 1)].im;
              Y[b_i + Y.size(0) * (j - 1)] = Y[b_i + Y.size(0) * (i1 - 1)];
              Y[b_i + Y.size(0) * (i1 - 1)].re = temp_re;
              Y[b_i + Y.size(0) * (i1 - 1)].im = temp_im;
            }
          }
        }

        if (((B.size(0) != 1) || (B.size(1) != 1)) && (loop_ub > 0)) {
          c_st.site = &gc_emlrtRSI;
          d_st.site = &vc_emlrtRSI;
          warning(&d_st);
        }
      } else {
        int32_T i;
        int32_T i1;
        int32_T nb;
        b_B.set_size((&ic_emlrtRTEI), sp, B.size(1), B.size(0));
        loop_ub = B.size(0);
        for (i = 0; i < loop_ub; i++) {
          nb = B.size(1);
          for (i1 = 0; i1 < nb; i1++) {
            b_B[i1 + b_B.size(0) * i].re = B[i + B.size(0) * i1].re;
            b_B[i1 + b_B.size(0) * i].im = -B[i + B.size(0) * i1].im;
          }
        }

        b_A.set_size((&jc_emlrtRTEI), sp, A.size(1), A.size(0));
        loop_ub = A.size(0);
        for (i = 0; i < loop_ub; i++) {
          nb = A.size(1);
          for (i1 = 0; i1 < nb; i1++) {
            b_A[i1 + b_A.size(0) * i] = A[i + A.size(0) * i1];
          }
        }

        st.site = &dc_emlrtRSI;
        qrsolve(&st, b_B, b_A, c_A);
        Y.set_size((&kc_emlrtRTEI), sp, c_A.size(1), c_A.size(0));
        loop_ub = c_A.size(0);
        for (i = 0; i < loop_ub; i++) {
          nb = c_A.size(1);
          for (i1 = 0; i1 < nb; i1++) {
            Y[i1 + Y.size(0) * i].re = c_A[i + c_A.size(0) * i1].re;
            Y[i1 + Y.size(0) * i].im = -c_A[i + c_A.size(0) * i1].im;
          }
        }
      }

      emlrtHeapReferenceStackLeaveFcnR2012b(sp);
    }

    void mrdiv(const emlrtStack *sp, const ::coder::array<creal_T, 2U> &A, const
               ::coder::array<creal_T, 2U> &B, ::coder::array<creal_T, 2U> &Y)
    {
      array<creal_T, 2U> b_A;
      array<creal_T, 2U> b_B;
      array<creal_T, 2U> c_A;
      array<int32_T, 2U> ipiv;
      emlrtStack b_st;
      emlrtStack c_st;
      emlrtStack d_st;
      emlrtStack e_st;
      emlrtStack st;
      int32_T b_loop_ub;
      st.prev = sp;
      st.tls = sp->tls;
      b_st.prev = &st;
      b_st.tls = st.tls;
      c_st.prev = &b_st;
      c_st.tls = b_st.tls;
      d_st.prev = &c_st;
      d_st.tls = c_st.tls;
      e_st.prev = &d_st;
      e_st.tls = d_st.tls;
      emlrtHeapReferenceStackEnterFcnR2012b(sp);
      if ((A.size(0) == 0) || (A.size(1) == 0) || ((B.size(0) == 0) || (B.size(1)
            == 0))) {
        int32_T loop_ub;
        Y.set_size((&nc_emlrtRTEI), sp, A.size(0), B.size(0));
        loop_ub = A.size(0) * B.size(0);
        for (int32_T i = 0; i < loop_ub; i++) {
          Y[i].re = 0.0;
          Y[i].im = 0.0;
        }
      } else if (B.size(0) == B.size(1)) {
        int32_T i;
        int32_T loop_ub;
        int32_T nb;
        st.site = &cc_emlrtRSI;
        b_st.site = &ec_emlrtRSI;
        c_st.site = &fc_emlrtRSI;
        b_A.set_size((&mc_emlrtRTEI), (&c_st), B.size(0), B.size(1));
        loop_ub = B.size(0) * B.size(1);
        for (i = 0; i < loop_ub; i++) {
          b_A[i] = B[i];
        }

        d_st.site = &hc_emlrtRSI;
        lapack::xgetrf(&d_st, B.size(1), B.size(1), b_A, B.size(1), ipiv,
                       &b_loop_ub);
        nb = A.size(0);
        Y.set_size((&od_emlrtRTEI), (&c_st), A.size(0), A.size(1));
        loop_ub = A.size(0) * A.size(1);
        for (i = 0; i < loop_ub; i++) {
          Y[i] = A[i];
        }

        d_st.site = &ic_emlrtRSI;
        blas::xtrsm(A.size(0), B.size(1), b_A, B.size(1), Y, A.size(0));
        d_st.site = &jc_emlrtRSI;
        blas::b_xtrsm(A.size(0), B.size(1), b_A, B.size(1), Y, A.size(0));
        i = B.size(1) - 1;
        for (loop_ub = i; loop_ub >= 1; loop_ub--) {
          int32_T i1;
          i1 = ipiv[loop_ub - 1];
          if (i1 != loop_ub) {
            d_st.site = &kc_emlrtRSI;
            if (nb > 2147483646) {
              e_st.site = &ib_emlrtRSI;
              check_forloop_overflow_error(&e_st);
            }

            for (int32_T b_i = 0; b_i < nb; b_i++) {
              real_T temp_im;
              real_T temp_re;
              temp_re = Y[b_i + Y.size(0) * (loop_ub - 1)].re;
              temp_im = Y[b_i + Y.size(0) * (loop_ub - 1)].im;
              Y[b_i + Y.size(0) * (loop_ub - 1)] = Y[b_i + Y.size(0) * (i1 - 1)];
              Y[b_i + Y.size(0) * (i1 - 1)].re = temp_re;
              Y[b_i + Y.size(0) * (i1 - 1)].im = temp_im;
            }
          }
        }

        if (((B.size(0) != 1) || (B.size(1) != 1)) && (b_loop_ub > 0)) {
          c_st.site = &gc_emlrtRSI;
          d_st.site = &vc_emlrtRSI;
          warning(&d_st);
        }
      } else {
        int32_T i;
        int32_T i1;
        int32_T loop_ub;
        b_B.set_size((&ic_emlrtRTEI), sp, B.size(1), B.size(0));
        loop_ub = B.size(0);
        for (i = 0; i < loop_ub; i++) {
          b_loop_ub = B.size(1);
          for (i1 = 0; i1 < b_loop_ub; i1++) {
            b_B[i1 + b_B.size(0) * i].re = B[i + B.size(0) * i1].re;
            b_B[i1 + b_B.size(0) * i].im = -B[i + B.size(0) * i1].im;
          }
        }

        c_A.set_size((&jc_emlrtRTEI), sp, A.size(1), A.size(0));
        loop_ub = A.size(0);
        for (i = 0; i < loop_ub; i++) {
          b_loop_ub = A.size(1);
          for (i1 = 0; i1 < b_loop_ub; i1++) {
            c_A[i1 + c_A.size(0) * i].re = A[i + A.size(0) * i1].re;
            c_A[i1 + c_A.size(0) * i].im = -A[i + A.size(0) * i1].im;
          }
        }

        st.site = &dc_emlrtRSI;
        qrsolve(&st, b_B, c_A, b_A);
        Y.set_size((&kc_emlrtRTEI), sp, b_A.size(1), b_A.size(0));
        loop_ub = b_A.size(0);
        for (i = 0; i < loop_ub; i++) {
          b_loop_ub = b_A.size(1);
          for (i1 = 0; i1 < b_loop_ub; i1++) {
            Y[i1 + Y.size(0) * i].re = b_A[i + b_A.size(0) * i1].re;
            Y[i1 + Y.size(0) * i].im = -b_A[i + b_A.size(0) * i1].im;
          }
        }
      }

      emlrtHeapReferenceStackLeaveFcnR2012b(sp);
    }
  }
}

// End of code generation (mrdivide_helper.cpp)
