//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  xunormqr.cpp
//
//  Code generation for function 'xunormqr'
//


// Include files
#include "xunormqr.h"
#include "Launch_RCWA_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "lapacke.h"
#include "mwmathutil.h"
#include <stddef.h>

// Variable Definitions
static emlrtRTEInfo kg_emlrtRTEI = { 31,// lineNo
  5,                                   // colNo
  "xunormqr",                          // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xunormqr.m"// pName 
};

// Function Definitions
namespace coder
{
  namespace internal
  {
    namespace lapack
    {
      void xunormqr(const emlrtStack *sp, const ::coder::array<creal_T, 2U> &Q, ::
                    coder::array<creal_T, 2U> &C, const ::coder::array<creal_T,
                    1U> &tau)
      {
        static const char_T fname[14] = { 'L', 'A', 'P', 'A', 'C', 'K', 'E', '_',
          'z', 'u', 'n', 'm', 'q', 'r' };

        emlrtStack b_st;
        emlrtStack st;
        st.prev = sp;
        st.tls = sp->tls;
        st.site = &pd_emlrtRSI;
        b_st.prev = &st;
        b_st.tls = st.tls;
        if ((Q.size(0) != 0) && (Q.size(1) != 0) && ((C.size(0) != 0) && (C.size
              (1) != 0))) {
          ptrdiff_t nrc_t;
          int32_T i;
          int32_T i1;
          int32_T info;
          boolean_T p;
          nrc_t = (ptrdiff_t)C.size(0);
          i = Q.size(0);
          i1 = Q.size(1);
          nrc_t = LAPACKE_zunmqr(102, 'L', 'C', nrc_t, (ptrdiff_t)C.size(1),
            (ptrdiff_t)muIntScalarMin_sint32(i, i1), (lapack_complex_double *)
            &(((::coder::array<creal_T, 2U> *)&Q)->data())[0], (ptrdiff_t)Q.size
            (0), (lapack_complex_double *)&(((::coder::array<creal_T, 1U> *)&tau)
            ->data())[0], (lapack_complex_double *)&(C.data())[0], nrc_t);
          info = (int32_T)nrc_t;
          b_st.site = &qd_emlrtRSI;
          if (info != 0) {
            boolean_T b_p;
            p = true;
            b_p = false;
            if (info == -7) {
              b_p = true;
            } else if (info == -9) {
              b_p = true;
            } else {
              if (info == -10) {
                b_p = true;
              }
            }

            if (!b_p) {
              if (info == -1010) {
                emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI,
                  "MATLAB:nomem", "MATLAB:nomem", 0);
              } else {
                emlrtErrorWithMessageIdR2018a(&b_st, &h_emlrtRTEI,
                  "Coder:toolbox:LAPACKCallErrorInfo",
                  "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, fname, 12, info);
              }
            }
          } else {
            p = false;
          }

          if (p) {
            int32_T C_idx_1;
            info = C.size(0);
            C_idx_1 = C.size(1);
            C.set_size((&kg_emlrtRTEI), (&st), info, C_idx_1);
            for (i = 0; i < C_idx_1; i++) {
              for (i1 = 0; i1 < info; i1++) {
                C[i1 + C.size(0) * i].re = rtNaN;
                C[i1 + C.size(0) * i].im = 0.0;
              }
            }
          }
        }
      }
    }
  }
}

// End of code generation (xunormqr.cpp)
