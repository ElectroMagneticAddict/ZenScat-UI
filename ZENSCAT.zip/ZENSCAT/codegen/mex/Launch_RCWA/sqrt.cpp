//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  sqrt.cpp
//
//  Code generation for function 'sqrt'
//


// Include files
#include "sqrt.h"
#include "Launch_RCWA_data.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo sb_emlrtRSI = { 16, // lineNo
  "sqrt",                              // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elfun\\sqrt.m"// pathName 
};

static emlrtRSInfo tb_emlrtRSI = { 33, // lineNo
  "applyScalarFunctionInPlace",        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunctionInPlace.m"// pathName 
};

// Function Definitions
namespace coder
{
  void b_sqrt(const emlrtStack *sp, ::coder::array<creal_T, 2U> &x)
  {
    emlrtStack b_st;
    emlrtStack c_st;
    emlrtStack st;
    real_T absxr;
    int32_T nx;
    st.prev = sp;
    st.tls = sp->tls;
    st.site = &sb_emlrtRSI;
    b_st.prev = &st;
    b_st.tls = st.tls;
    c_st.prev = &b_st;
    c_st.tls = b_st.tls;
    nx = x.size(0) * x.size(1);
    b_st.site = &tb_emlrtRSI;
    if ((1 <= nx) && (nx > 2147483646)) {
      c_st.site = &ib_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    for (int32_T k = 0; k < nx; k++) {
      real_T absxi;
      real_T xi;
      real_T xr;
      xr = x[k].re;
      xi = x[k].im;
      if (xi == 0.0) {
        if (xr < 0.0) {
          absxi = 0.0;
          xr = muDoubleScalarSqrt(-xr);
        } else {
          absxi = muDoubleScalarSqrt(xr);
          xr = 0.0;
        }
      } else if (xr == 0.0) {
        if (xi < 0.0) {
          absxi = muDoubleScalarSqrt(-xi / 2.0);
          xr = -absxi;
        } else {
          absxi = muDoubleScalarSqrt(xi / 2.0);
          xr = absxi;
        }
      } else if (muDoubleScalarIsNaN(xr)) {
        absxi = xr;
      } else if (muDoubleScalarIsNaN(xi)) {
        absxi = xi;
        xr = xi;
      } else if (muDoubleScalarIsInf(xi)) {
        absxi = muDoubleScalarAbs(xi);
        xr = xi;
      } else if (muDoubleScalarIsInf(xr)) {
        if (xr < 0.0) {
          absxi = 0.0;
          xr = xi * -xr;
        } else {
          absxi = xr;
          xr = 0.0;
        }
      } else {
        absxr = muDoubleScalarAbs(xr);
        absxi = muDoubleScalarAbs(xi);
        if ((absxr > 4.4942328371557893E+307) || (absxi >
             4.4942328371557893E+307)) {
          absxr *= 0.5;
          absxi = muDoubleScalarHypot(absxr, absxi * 0.5);
          if (absxi > absxr) {
            absxi = muDoubleScalarSqrt(absxi) * muDoubleScalarSqrt(absxr / absxi
              + 1.0);
          } else {
            absxi = muDoubleScalarSqrt(absxi) * 1.4142135623730951;
          }
        } else {
          absxi = muDoubleScalarSqrt((muDoubleScalarHypot(absxr, absxi) + absxr)
            * 0.5);
        }

        if (xr > 0.0) {
          xr = 0.5 * (xi / absxi);
        } else {
          if (xi < 0.0) {
            xr = -absxi;
          } else {
            xr = absxi;
          }

          absxi = 0.5 * (xi / xr);
        }
      }

      x[k].re = absxi;
      x[k].im = xr;
    }
  }
}

// End of code generation (sqrt.cpp)
