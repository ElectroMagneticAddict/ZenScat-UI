//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  eig.cpp
//
//  Code generation for function 'eig'
//


// Include files
#include "eig.h"
#include "Launch_RCWA_data.h"
#include "anyNonFinite.h"
#include "eigHermitianStandard.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "warning.h"
#include "coder_array.h"
#include "lapacke.h"
#include <stddef.h>

// Variable Definitions
static emlrtRSInfo eg_emlrtRSI = { 93, // lineNo
  "eig",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pathName 
};

static emlrtRSInfo fg_emlrtRSI = { 102,// lineNo
  "eig",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pathName 
};

static emlrtRSInfo gg_emlrtRSI = { 137,// lineNo
  "eig",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pathName 
};

static emlrtRSInfo hg_emlrtRSI = { 145,// lineNo
  "eig",                               // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pathName 
};

static emlrtRSInfo eh_emlrtRSI = { 59, // lineNo
  "eigStandard",                       // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStandard.m"// pathName 
};

static emlrtRSInfo fh_emlrtRSI = { 33, // lineNo
  "eigStandard",                       // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStandard.m"// pathName 
};

static emlrtRSInfo gh_emlrtRSI = { 31, // lineNo
  "eigStandard",                       // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStandard.m"// pathName 
};

static emlrtRSInfo hh_emlrtRSI = { 36, // lineNo
  "xgeev",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgeev.m"// pathName 
};

static emlrtRSInfo ih_emlrtRSI = { 182,// lineNo
  "ceval_xgeev",                       // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgeev.m"// pathName 
};

static emlrtRTEInfo m_emlrtRTEI = { 62,// lineNo
  27,                                  // colNo
  "eig",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pName 
};

static emlrtRTEInfo oe_emlrtRTEI = { 68,// lineNo
  24,                                  // colNo
  "eig",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pName 
};

static emlrtRTEInfo pe_emlrtRTEI = { 72,// lineNo
  28,                                  // colNo
  "eig",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pName 
};

static emlrtRTEInfo qe_emlrtRTEI = { 36,// lineNo
  33,                                  // colNo
  "xgeev",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgeev.m"// pName 
};

static emlrtRTEInfo re_emlrtRTEI = { 83,// lineNo
  24,                                  // colNo
  "xgeev",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgeev.m"// pName 
};

static emlrtRTEInfo se_emlrtRTEI = { 86,// lineNo
  21,                                  // colNo
  "xgeev",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgeev.m"// pName 
};

static emlrtRTEInfo te_emlrtRTEI = { 90,// lineNo
  29,                                  // colNo
  "xgeev",                             // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgeev.m"// pName 
};

static emlrtRTEInfo ue_emlrtRTEI = { 32,// lineNo
  13,                                  // colNo
  "eigStandard",                       // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\private\\eigStandard.m"// pName 
};

static emlrtRTEInfo ve_emlrtRTEI = { 97,// lineNo
  9,                                   // colNo
  "eig",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pName 
};

static emlrtRTEInfo we_emlrtRTEI = { 101,// lineNo
  13,                                  // colNo
  "eig",                               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\matfun\\eig.m"// pName 
};

// Function Definitions
namespace coder
{
  void eig(const emlrtStack *sp, const ::coder::array<creal_T, 2U> &A, ::coder::
           array<creal_T, 2U> &V, ::coder::array<creal_T, 2U> &D)
  {
    static const char_T fname[14] = { 'L', 'A', 'P', 'A', 'C', 'K', 'E', '_',
      'z', 'g', 'e', 'e', 'v', 'x' };

    ptrdiff_t ihi_t;
    ptrdiff_t ilo_t;
    array<creal_T, 2U> b_A;
    array<creal_T, 1U> W;
    array<real_T, 1U> scale;
    emlrtStack b_st;
    emlrtStack c_st;
    emlrtStack d_st;
    emlrtStack st;
    creal_T vl;
    real_T abnrm;
    real_T rconde;
    real_T rcondv;
    int32_T n;
    st.prev = sp;
    st.tls = sp->tls;
    b_st.prev = &st;
    b_st.tls = st.tls;
    c_st.prev = &b_st;
    c_st.tls = b_st.tls;
    d_st.prev = &c_st;
    d_st.tls = c_st.tls;
    emlrtHeapReferenceStackEnterFcnR2012b(sp);
    n = A.size(0);
    if (A.size(0) != A.size(1)) {
      emlrtErrorWithMessageIdR2018a(sp, &m_emlrtRTEI,
        "MATLAB:eig:inputMustBeSquareStandard",
        "MATLAB:eig:inputMustBeSquareStandard", 0);
    }

    V.set_size((&oe_emlrtRTEI), sp, A.size(0), A.size(0));
    D.set_size((&pe_emlrtRTEI), sp, A.size(0), A.size(0));
    if ((A.size(0) != 0) && (A.size(1) != 0)) {
      st.site = &eg_emlrtRSI;
      if (internal::anyNonFinite(&st, A)) {
        int32_T i;
        int32_T j;
        V.set_size((&ve_emlrtRTEI), sp, A.size(0), A.size(0));
        j = A.size(0) * A.size(0);
        for (i = 0; i < j; i++) {
          V[i].re = rtNaN;
          V[i].im = 0.0;
        }

        D.set_size((&we_emlrtRTEI), sp, A.size(0), A.size(0));
        j = A.size(0) * A.size(0);
        for (i = 0; i < j; i++) {
          D[i].re = 0.0;
          D[i].im = 0.0;
        }

        st.site = &fg_emlrtRSI;
        if (A.size(0) > 2147483646) {
          b_st.site = &ib_emlrtRSI;
          check_forloop_overflow_error(&b_st);
        }

        for (j = 0; j < n; j++) {
          D[j + D.size(0) * j].re = rtNaN;
          D[j + D.size(0) * j].im = 0.0;
        }
      } else {
        int32_T j;
        boolean_T p;
        p = (A.size(0) == A.size(1));
        if (p) {
          boolean_T exitg2;
          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= A.size(1) - 1)) {
            int32_T exitg1;
            n = 0;
            do {
              exitg1 = 0;
              if (n <= j) {
                if ((!(A[n + A.size(0) * j].re == A[j + A.size(0) * n].re)) || (
                     !(A[n + A.size(0) * j].im == -A[j + A.size(0) * n].im))) {
                  p = false;
                  exitg1 = 1;
                } else {
                  n++;
                }
              } else {
                j++;
                exitg1 = 2;
              }
            } while (exitg1 == 0);

            if (exitg1 == 1) {
              exitg2 = true;
            }
          }
        }

        if (p) {
          st.site = &gg_emlrtRSI;
          eigHermitianStandard(&st, A, V, D);
        } else {
          int32_T i;
          int32_T info;
          st.site = &hg_emlrtRSI;
          n = A.size(0);
          b_st.site = &gh_emlrtRSI;
          c_st.site = &hh_emlrtRSI;
          b_A.set_size((&qe_emlrtRTEI), (&c_st), A.size(0), A.size(1));
          j = A.size(0) * A.size(1);
          for (i = 0; i < j; i++) {
            b_A[i] = A[i];
          }

          ptrdiff_t info_t;
          scale.set_size((&re_emlrtRTEI), (&c_st), A.size(1));
          W.set_size((&se_emlrtRTEI), (&c_st), A.size(1));
          V.set_size((&te_emlrtRTEI), (&c_st), A.size(1), A.size(1));
          info_t = LAPACKE_zgeevx(102, 'B', 'N', 'V', 'N', (ptrdiff_t)A.size(1),
            (lapack_complex_double *)&(b_A.data())[0], (ptrdiff_t)A.size(0),
            (lapack_complex_double *)&(W.data())[0], (lapack_complex_double *)
            &vl, (ptrdiff_t)1, (lapack_complex_double *)&(V.data())[0],
            (ptrdiff_t)A.size(1), &ilo_t, &ihi_t, &(scale.data())[0], &abnrm,
            &rconde, &rcondv);
          info = (int32_T)info_t;
          d_st.site = &ih_emlrtRSI;
          if (info < 0) {
            if (info == -1010) {
              emlrtErrorWithMessageIdR2018a(&d_st, &i_emlrtRTEI, "MATLAB:nomem",
                "MATLAB:nomem", 0);
            } else {
              emlrtErrorWithMessageIdR2018a(&d_st, &h_emlrtRTEI,
                "Coder:toolbox:LAPACKCallErrorInfo",
                "Coder:toolbox:LAPACKCallErrorInfo", 5, 4, 14, fname, 12, info);
            }
          }

          D.set_size((&ue_emlrtRTEI), (&st), A.size(0), A.size(0));
          j = A.size(0) * A.size(0);
          for (i = 0; i < j; i++) {
            D[i].re = 0.0;
            D[i].im = 0.0;
          }

          b_st.site = &fh_emlrtRSI;
          if (A.size(0) > 2147483646) {
            c_st.site = &ib_emlrtRSI;
            check_forloop_overflow_error(&c_st);
          }

          for (j = 0; j < n; j++) {
            D[j + D.size(0) * j] = W[j];
          }

          if (info != 0) {
            b_st.site = &eh_emlrtRSI;
            internal::c_warning(&b_st);
          }
        }
      }
    }

    emlrtHeapReferenceStackLeaveFcnR2012b(sp);
  }
}

// End of code generation (eig.cpp)
