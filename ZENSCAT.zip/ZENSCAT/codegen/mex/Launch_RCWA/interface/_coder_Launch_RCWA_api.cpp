//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  _coder_Launch_RCWA_api.cpp
//
//  Code generation for function '_coder_Launch_RCWA_api'
//


// Include files
#include "_coder_Launch_RCWA_api.h"
#include "Launch_RCWA.h"
#include "Launch_RCWA_data.h"
#include "Launch_RCWA_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Declarations
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<real_T, 2U> &y);
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<creal_T, 2U> &ret);
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<creal_T, 3U> &ret);
static char_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *Mode,
  const char_T *identifier);
static char_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static void c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<real_T, 2U> &ret);
static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);
static void d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<real_T, 2U> &ret);
static char_T d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *grid, const
  char_T *identifier, struct0_T *y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, struct0_T *y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<real_T, 2U> &y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *device, const
  char_T *identifier, struct1_T *y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, struct1_T *y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<creal_T, 2U> &y);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<creal_T, 3U> &y);
static real_T emlrt_marshallIn(const emlrtStack *sp, const mxArray *NH, const
  char_T *identifier);
static real_T emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static const mxArray *emlrt_marshallOut(const struct2_T *u);
static const mxArray *emlrt_marshallOut(const struct3_T *u);
static const mxArray *emlrt_marshallOut(const coder::array<real_T, 2U> &u);

// Function Definitions
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<real_T, 2U> &y)
{
  d_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<creal_T, 2U> &ret)
{
  static const int32_T dims[2] = { -1, -1 };

  int32_T iv[2];
  const boolean_T bv[2] = { true, true };

  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", true, 2U, dims, &bv[0], iv);
  ret.set_size(((emlrtRTEInfo *)NULL), sp, iv[0], iv[1]);
  emlrtImportArrayR2015b(sp, src, &(ret.data())[0], 8, true);
  emlrtDestroyArray(&src);
}

static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<creal_T, 3U> &ret)
{
  static const int32_T dims[3] = { -1, -1, -1 };

  int32_T iv[3];
  const boolean_T bv[3] = { true, true, true };

  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", true, 3U, dims, &bv[0], iv);
  ret.set_size(((emlrtRTEInfo *)NULL), sp, iv[0], iv[1], iv[2]);
  emlrtImportArrayR2015b(sp, src, &(ret.data())[0], 8, true);
  emlrtDestroyArray(&src);
}

static char_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *Mode,
  const char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  char_T y;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(sp, emlrtAlias(Mode), &thisId);
  emlrtDestroyArray(&Mode);
  return y;
}

static char_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  char_T y;
  y = d_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static void c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<real_T, 2U> &ret)
{
  static const int32_T dims[2] = { 1, -1 };

  int32_T iv[2];
  const boolean_T bv[2] = { false, true };

  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", false, 2U, dims, &bv[0],
    iv);
  ret.set_size(((emlrtRTEInfo *)NULL), sp, iv[0], iv[1]);
  emlrtImportArrayR2015b(sp, src, &(ret.data())[0], 8, false);
  emlrtDestroyArray(&src);
}

static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  static const int32_T dims = 0;
  real_T ret;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 0U, &dims);
  ret = *(real_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static void d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, coder::array<real_T, 2U> &ret)
{
  static const int32_T dims[2] = { -1, -1 };

  int32_T iv[2];
  const boolean_T bv[2] = { true, true };

  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", false, 2U, dims, &bv[0],
    iv);
  ret.set_size(((emlrtRTEInfo *)NULL), sp, iv[0], iv[1]);
  emlrtImportArrayR2015b(sp, src, &(ret.data())[0], 8, false);
  emlrtDestroyArray(&src);
}

static char_T d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  static const int32_T dims = 0;
  char_T ret;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "char", false, 0U, &dims);
  emlrtImportCharR2015b(sp, src, &ret);
  emlrtDestroyArray(&src);
  return ret;
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *grid, const
  char_T *identifier, struct0_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  emlrt_marshallIn(sp, emlrtAlias(grid), &thisId, y);
  emlrtDestroyArray(&grid);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, struct0_T *y)
{
  static const int32_T dims = 0;
  static const char_T *fieldNames[20] = { "Lam0", "Theta", "urR", "erR", "urT",
    "erT", "erSub", "erIdx", "h", "Lx", "Lz", "Nx", "Nz", "dz", "qx", "qz", "x",
    "Length", "delta", "layer_num" };

  emlrtMsgIdentifier thisId;
  thisId.fParent = parentId;
  thisId.bParentIsCell = false;
  emlrtCheckStructR2012b(sp, parentId, u, 20, fieldNames, 0U, &dims);
  thisId.fIdentifier = "Lam0";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 0, "Lam0")),
                   &thisId, y->Lam0);
  thisId.fIdentifier = "Theta";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 1, "Theta")),
                   &thisId, y->Theta);
  thisId.fIdentifier = "urR";
  y->urR = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 2,
    "urR")), &thisId);
  thisId.fIdentifier = "erR";
  y->erR = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 3,
    "erR")), &thisId);
  thisId.fIdentifier = "urT";
  y->urT = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 4,
    "urT")), &thisId);
  thisId.fIdentifier = "erT";
  y->erT = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 5,
    "erT")), &thisId);
  thisId.fIdentifier = "erSub";
  y->erSub = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 6,
    "erSub")), &thisId);
  thisId.fIdentifier = "erIdx";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 7, "erIdx")),
                   &thisId, y->erIdx);
  thisId.fIdentifier = "h";
  y->h = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 8, "h")),
    &thisId);
  thisId.fIdentifier = "Lx";
  y->Lx = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 9, "Lx")),
    &thisId);
  thisId.fIdentifier = "Lz";
  y->Lz = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 10, "Lz")),
    &thisId);
  thisId.fIdentifier = "Nx";
  y->Nx = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 11, "Nx")),
    &thisId);
  thisId.fIdentifier = "Nz";
  y->Nz = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 12, "Nz")),
    &thisId);
  thisId.fIdentifier = "dz";
  y->dz = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 13, "dz")),
    &thisId);
  thisId.fIdentifier = "qx";
  y->qx = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 14, "qx")),
    &thisId);
  thisId.fIdentifier = "qz";
  y->qz = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 15, "qz")),
    &thisId);
  thisId.fIdentifier = "x";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 16, "x")),
                   &thisId, y->x);
  thisId.fIdentifier = "Length";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 17, "Length")),
                   &thisId, y->Length);
  thisId.fIdentifier = "delta";
  y->delta = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 18,
    "delta")), &thisId);
  thisId.fIdentifier = "layer_num";
  y->layer_num = emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0,
    19, "layer_num")), &thisId);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<real_T, 2U> &y)
{
  c_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *device, const
  char_T *identifier, struct1_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  emlrt_marshallIn(sp, emlrtAlias(device), &thisId, y);
  emlrtDestroyArray(&device);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, struct1_T *y)
{
  static const int32_T dims = 0;
  static const char_T *fieldNames[4] = { "ER", "eps", "ERC", "sub_L" };

  emlrtMsgIdentifier thisId;
  thisId.fParent = parentId;
  thisId.bParentIsCell = false;
  emlrtCheckStructR2012b(sp, parentId, u, 4, fieldNames, 0U, &dims);
  thisId.fIdentifier = "ER";
  b_emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 0, "ER")),
                     &thisId, y->ER);
  thisId.fIdentifier = "eps";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 1, "eps")),
                   &thisId, y->eps);
  thisId.fIdentifier = "ERC";
  emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 2, "ERC")),
                   &thisId, y->ERC);
  thisId.fIdentifier = "sub_L";
  b_emlrt_marshallIn(sp, emlrtAlias(emlrtGetFieldR2017b(sp, u, 0, 3, "sub_L")),
                     &thisId, y->sub_L);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<creal_T, 2U> &y)
{
  b_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, coder::array<creal_T, 3U> &y)
{
  b_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static real_T emlrt_marshallIn(const emlrtStack *sp, const mxArray *NH, const
  char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  real_T y;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = emlrt_marshallIn(sp, emlrtAlias(NH), &thisId);
  emlrtDestroyArray(&NH);
  return y;
}

static real_T emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = c_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static const mxArray *emlrt_marshallOut(const struct2_T *u)
{
  static const char_T *sv[4] = { "minus_1", "plus_1", "TRN0", "sum" };

  const mxArray *y;
  y = NULL;
  emlrtAssign(&y, emlrtCreateStructMatrix(1, 1, 4, &sv[0]));
  emlrtSetFieldR2017b(y, 0, "minus_1", emlrt_marshallOut(u->minus_1), 0);
  emlrtSetFieldR2017b(y, 0, "plus_1", emlrt_marshallOut(u->plus_1), 1);
  emlrtSetFieldR2017b(y, 0, "TRN0", emlrt_marshallOut(u->TRN0), 2);
  emlrtSetFieldR2017b(y, 0, "sum", emlrt_marshallOut(u->sum), 3);
  return y;
}

static const mxArray *emlrt_marshallOut(const struct3_T *u)
{
  static const char_T *sv[4] = { "minus_1", "plus_1", "REF0", "sum" };

  const mxArray *y;
  y = NULL;
  emlrtAssign(&y, emlrtCreateStructMatrix(1, 1, 4, &sv[0]));
  emlrtSetFieldR2017b(y, 0, "minus_1", emlrt_marshallOut(u->minus_1), 0);
  emlrtSetFieldR2017b(y, 0, "plus_1", emlrt_marshallOut(u->plus_1), 1);
  emlrtSetFieldR2017b(y, 0, "REF0", emlrt_marshallOut(u->REF0), 2);
  emlrtSetFieldR2017b(y, 0, "sum", emlrt_marshallOut(u->sum), 3);
  return y;
}

static const mxArray *emlrt_marshallOut(const coder::array<real_T, 2U> &u)
{
  const mxArray *m;
  const mxArray *y;
  real_T *pData;
  int32_T iv[2];
  int32_T i;
  y = NULL;
  iv[0] = u.size(0);
  iv[1] = u.size(1);
  m = emlrtCreateNumericArray(2, &iv[0], mxDOUBLE_CLASS, mxREAL);
  pData = emlrtMxGetPr(m);
  i = 0;
  for (int32_T b_i = 0; b_i < u.size(1); b_i++) {
    for (int32_T c_i = 0; c_i < u.size(0); c_i++) {
      pData[i] = u[c_i + u.size(0) * b_i];
      i++;
    }
  }

  emlrtAssign(&y, m);
  return y;
}

void Launch_RCWA_api(const mxArray * const prhs[4], int32_T nlhs, const mxArray *
                     plhs[2])
{
  emlrtStack st = { NULL,              // site
    NULL,                              // tls
    NULL                               // prev
  };

  struct0_T grid;
  struct1_T device;
  struct2_T TRN;
  struct3_T REF;
  real_T NH;
  char_T Mode;
  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);

  // Marshall function inputs
  NH = emlrt_marshallIn(&st, emlrtAliasP(prhs[0]), "NH");
  emlrt_marshallIn(&st, emlrtAliasP(prhs[1]), "grid", &grid);
  emlrt_marshallIn(&st, emlrtAliasP(prhs[2]), "device", &device);
  Mode = b_emlrt_marshallIn(&st, emlrtAliasP(prhs[3]), "Mode");

  // Invoke the target function
  Launch_RCWA(&st, NH, &grid, &device, Mode, &TRN, &REF);

  // Marshall function outputs
  plhs[0] = emlrt_marshallOut(&TRN);
  if (nlhs > 1) {
    plhs[1] = emlrt_marshallOut(&REF);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

// End of code generation (_coder_Launch_RCWA_api.cpp)
