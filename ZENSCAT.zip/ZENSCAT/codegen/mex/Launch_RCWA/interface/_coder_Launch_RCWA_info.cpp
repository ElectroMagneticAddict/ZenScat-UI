//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  _coder_Launch_RCWA_info.cpp
//
//  Code generation for function 'Launch_RCWA'
//


// Include files
#include "_coder_Launch_RCWA_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8] = {
    "789ced98bd6fd34018c61d9456656829151f0b888a01b6ba495b42118b93f493d6444968d25428b9da97dad45fb59d268d90bab1b23231c38ac4cec8d88d9d3f"
    "8085852df4125fed5a352e757c4da3dce2bc7aec7bee79cff9c93a2ab2b21ea1286a8cea8ca3879deba8558f5bd76bd4e9e1d623d675d851ff39b4ef1fa2a254",
    "ebd07e0ee9ecf1a4efad9a53151336cc4ea100199e3cc9abb2a800c5cc1f6890d2a1a14afb906f2b5551827951863967c1a24a5e7448270592d0ef9400b9dd5c"
    "4da674c1b05728398b763fd0fabe3bf2a23c386ff48c7e3875dc0fe0aaf118b7e6c7fad6c2ebd433fa950175835ed9518041a7a1b16baa1a9d66b2492647c7d3",
    "93d9548141d7f59a648a123880faa4aa99a22c368129aa0afdd251943766e935505338a18c1e9b925db92a01730d79e61a6acfcf01897bd145bf61576dfb0db7"
    "e7374cbdc699b6dfb7807e5b9e7e9df9b11ec6beb57b67ed985fff6e9c338ffb6adf3fd2fe5fae7df811f1f26bf9f8b52ee0d78abd1b21e987c765f9353ce63b",
    "eb7d3ccbef8e871f7e1fb1ceec09b97986add7e7b812dfc82e26d985f8eab2bd8e8c8f8fdf3a288f9ad4fc4e1e5fa48fbdca632d60ae5157edce8575c496451d"
    "c29c063848f9ff1fceebefc7675ead6d4bb07bfbc8f9e4c57a587c3ee9e13f381d06576e4e90e5f4dbe76375927e78f43ba7e37becb650e436b3c53d46518d0c",
    "cf3e2da8a901a77b9dd341df8f099f5c58478cc9c2aa0439b4aa9cc8c3d3eba8045cc7ff7e4f07dd4fc12737d6c3e2f5e95e4ec9a4f83273972cafb9afe62f92"
    "7e785c555edff6f0c3ef25d613e9e5262795b6774a85e944acbe0e347646a006bcee775edff2c98575c498bc0e1443160dc341eccbe2f55140bf373eb9b11e16",
    "afddbdc41b4b8a33f7c6c972fbd6e38f9f49fae17155b97ddeef6c69b36a8074a131a7ad0a006e36137c91dd199c87f43cb7839e875cf7c98575c49a35b45497"
    "7f25a07f90f3ea8bf8957df2623d2c5eb77b78bc8ba478527e4096cfb12ff73f91f4c3a3dff95c2acee4e30986cdcc1a2bfbd5036329964a96d2033ef73a9f2b",
    "0173455db59d2b6af111e8ddf423cde392a75f677eac87b16fa877a4bf9767099f73fc7cf47b702e4d759fc7b5069897569bcdfde5c493a564663abfc14a0b7d"
    "c0e3bff5207387", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 8936U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 4);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("Launch_RCWA"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(4.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (2.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\Launch_RCWA.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738391.90400462958));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1592791 (R2020b) Update 5"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_Launch_RCWA_info.cpp)
