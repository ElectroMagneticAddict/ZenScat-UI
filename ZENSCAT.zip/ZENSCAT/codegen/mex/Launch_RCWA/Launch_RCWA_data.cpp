//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  Launch_RCWA_data.cpp
//
//  Code generation for function 'Launch_RCWA_data'
//


// Include files
#include "Launch_RCWA_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar = NULL;
emlrtContext emlrtContextGlobal = { true,// bFirstTime
  false,                               // bInitialized
  131595U,                             // fVersionInfo
  NULL,                                // fErrorFunction
  "Launch_RCWA",                       // fFunctionName
  NULL,                                // fRTCallStack
  false,                               // bDebugMode
  { 2045744189U, 2170104910U, 2743257031U, 4284093946U },// fSigWrd
  NULL                                 // fSigMem
};

emlrtRSInfo ib_emlrtRSI = { 21,        // lineNo
  "eml_int_forloop_overflow_check",    // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"// pathName 
};

emlrtRSInfo ob_emlrtRSI = { 70,        // lineNo
  "power",                             // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\power.m"// pathName 
};

emlrtRSInfo bc_emlrtRSI = { 20,        // lineNo
  "mrdivide_helper",                   // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pathName 
};

emlrtRSInfo ec_emlrtRSI = { 67,        // lineNo
  "lusolve",                           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

emlrtRSInfo gc_emlrtRSI = { 112,       // lineNo
  "lusolveNxN",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

emlrtRSInfo lc_emlrtRSI = { 27,        // lineNo
  "xgetrf",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pathName 
};

emlrtRSInfo mc_emlrtRSI = { 91,        // lineNo
  "ceval_xgetrf",                      // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pathName 
};

emlrtRSInfo nc_emlrtRSI = { 58,        // lineNo
  "ceval_xgetrf",                      // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pathName 
};

emlrtRSInfo vc_emlrtRSI = { 90,        // lineNo
  "warn_singular",                     // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

emlrtRSInfo wc_emlrtRSI = { 41,        // lineNo
  "qrsolve",                           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo xc_emlrtRSI = { 45,        // lineNo
  "qrsolve",                           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo yc_emlrtRSI = { 52,        // lineNo
  "qrsolve",                           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo md_emlrtRSI = { 92,        // lineNo
  "LSQFromQR",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo nd_emlrtRSI = { 94,        // lineNo
  "LSQFromQR",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo od_emlrtRSI = { 104,       // lineNo
  "LSQFromQR",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo pd_emlrtRSI = { 31,        // lineNo
  "xunormqr",                          // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xunormqr.m"// pathName 
};

emlrtRSInfo qd_emlrtRSI = { 103,       // lineNo
  "ceval_xunormqr",                    // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xunormqr.m"// pathName 
};

emlrtRSInfo ge_emlrtRSI = { 109,       // lineNo
  "lusolveNxN",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

emlrtRSInfo he_emlrtRSI = { 124,       // lineNo
  "InvAtimesX",                        // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pathName 
};

emlrtRSInfo ie_emlrtRSI = { 19,        // lineNo
  "xgetrfs",                           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrfs.m"// pathName 
};

emlrtRSInfo je_emlrtRSI = { 108,       // lineNo
  "cmldiv",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrfs.m"// pathName 
};

emlrtRSInfo ke_emlrtRSI = { 70,        // lineNo
  "cmldiv",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrfs.m"// pathName 
};

emlrtRSInfo le_emlrtRSI = { 85,        // lineNo
  "LSQFromQR",                         // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pathName 
};

emlrtRSInfo xe_emlrtRSI = { 79,        // lineNo
  "eml_mtimes_helper",                 // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pathName 
};

emlrtRSInfo ye_emlrtRSI = { 48,        // lineNo
  "eml_mtimes_helper",                 // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pathName 
};

emlrtRSInfo af_emlrtRSI = { 142,       // lineNo
  "mtimes",                            // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\mtimes.m"// pathName 
};

emlrtRSInfo bf_emlrtRSI = { 178,       // lineNo
  "mtimes_blas",                       // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\mtimes.m"// pathName 
};

emlrtMCInfo c_emlrtMCI = { 53,         // lineNo
  19,                                  // colNo
  "flt2str",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\flt2str.m"// pName 
};

emlrtRTEInfo emlrtRTEI = { 16,         // lineNo
  19,                                  // colNo
  "mrdivide_helper",                   // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\mrdivide_helper.m"// pName 
};

emlrtRTEInfo f_emlrtRTEI = { 123,      // lineNo
  23,                                  // colNo
  "dynamic_size_checks",               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pName 
};

emlrtRTEInfo g_emlrtRTEI = { 118,      // lineNo
  23,                                  // colNo
  "dynamic_size_checks",               // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pName 
};

emlrtRTEInfo h_emlrtRTEI = { 47,       // lineNo
  13,                                  // colNo
  "infocheck",                         // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\infocheck.m"// pName 
};

emlrtRTEInfo i_emlrtRTEI = { 44,       // lineNo
  13,                                  // colNo
  "infocheck",                         // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\infocheck.m"// pName 
};

emlrtRTEInfo xb_emlrtRTEI = { 76,      // lineNo
  13,                                  // colNo
  "eml_mtimes_helper",                 // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pName 
};

emlrtRTEInfo yb_emlrtRTEI = { 76,      // lineNo
  9,                                   // colNo
  "eml_mtimes_helper",                 // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"// pName 
};

emlrtRTEInfo oc_emlrtRTEI = { 53,      // lineNo
  9,                                   // colNo
  "repmat",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\elmat\\repmat.m"// pName 
};

emlrtRTEInfo pc_emlrtRTEI = { 41,      // lineNo
  2,                                   // colNo
  "qrsolve",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pName 
};

emlrtRTEInfo dd_emlrtRTEI = { 85,      // lineNo
  5,                                   // colNo
  "qrsolve",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\qrsolve.m"// pName 
};

emlrtRTEInfo fd_emlrtRTEI = { 70,      // lineNo
  23,                                  // colNo
  "xgetrfs",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrfs.m"// pName 
};

emlrtRTEInfo gd_emlrtRTEI = { 124,     // lineNo
  2,                                   // colNo
  "lusolve",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pName 
};

emlrtRTEInfo hd_emlrtRTEI = { 124,     // lineNo
  9,                                   // colNo
  "lusolve",                           // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m"// pName 
};

emlrtRTEInfo kd_emlrtRTEI = { 58,      // lineNo
  29,                                  // colNo
  "xgetrf",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pName 
};

emlrtRTEInfo ld_emlrtRTEI = { 89,      // lineNo
  27,                                  // colNo
  "xgetrf",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+lapack\\xgetrf.m"// pName 
};

emlrtRTEInfo pd_emlrtRTEI = { 218,     // lineNo
  20,                                  // colNo
  "mtimes",                            // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\+blas\\mtimes.m"// pName 
};

const char_T cv1[19] = { 'L', 'A', 'P', 'A', 'C', 'K', 'E', '_', 'z', 'g', 'e',
  't', 'r', 'f', '_', 'w', 'o', 'r', 'k' };

const creal_T dc = { 1.0,              // re
  0.0                                  // im
};

emlrtRSInfo ti_emlrtRSI = { 53,        // lineNo
  "flt2str",                           // fcnName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\eml\\+coder\\+internal\\flt2str.m"// pathName 
};

// End of code generation (Launch_RCWA_data.cpp)
