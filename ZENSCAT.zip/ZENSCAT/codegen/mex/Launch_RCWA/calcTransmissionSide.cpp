//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  calcTransmissionSide.cpp
//
//  Code generation for function 'calcTransmissionSide'
//


// Include files
#include "calcTransmissionSide.h"
#include "Launch_RCWA_data.h"
#include "eye.h"
#include "inv.h"
#include "mldivide.h"
#include "mrdivide_helper.h"
#include "mtimes.h"
#include "power.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "mwmathutil.h"

// Variable Definitions
static emlrtRSInfo cf_emlrtRSI = { 3,  // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo df_emlrtRSI = { 6,  // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo ef_emlrtRSI = { 8,  // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo ff_emlrtRSI = { 12, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo gf_emlrtRSI = { 14, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo hf_emlrtRSI = { 15, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo if_emlrtRSI = { 16, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo jf_emlrtRSI = { 17, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo kf_emlrtRSI = { 18, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtRSInfo lf_emlrtRSI = { 19, // lineNo
  "calcTransmissionSide",              // fcnName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pathName 
};

static emlrtDCInfo n_emlrtDCI = { 4,   // lineNo
  22,                                  // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m",// pName 
  1                                    // checkKind
};

static emlrtECInfo j_emlrtECI = { 2,   // nDims
  6,                                   // lineNo
  9,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtECInfo k_emlrtECI = { 2,   // nDims
  14,                                  // lineNo
  5,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtECInfo l_emlrtECI = { 2,   // nDims
  15,                                  // lineNo
  5,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtECInfo m_emlrtECI = { 2,   // nDims
  17,                                  // lineNo
  17,                                  // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo rd_emlrtRTEI = { 4,// lineNo
  1,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo sd_emlrtRTEI = { 11,// lineNo
  5,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo td_emlrtRTEI = { 10,// lineNo
  5,                                   // colNo
  "mldivide",                          // fName
  "C:\\Program Files\\MATLAB\\R2020b\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.m"// pName 
};

static emlrtRTEInfo ud_emlrtRTEI = { 12,// lineNo
  5,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo vd_emlrtRTEI = { 7,// lineNo
  5,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo wd_emlrtRTEI = { 14,// lineNo
  1,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo xd_emlrtRTEI = { 15,// lineNo
  1,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo yd_emlrtRTEI = { 17,// lineNo
  1,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo ae_emlrtRTEI = { 18,// lineNo
  1,                                   // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

static emlrtRTEInfo be_emlrtRTEI = { 19,// lineNo
  12,                                  // colNo
  "calcTransmissionSide",              // fName
  "C:\\Users\\Ignas\\Desktop\\DARBAS\\2D RCWA\\2D Multilayer optimization\\Optimization_V4\\calcTransmissionSide.m"// pName 
};

// Function Definitions
void calcTransmissionSide(const emlrtStack *sp, const coder::array<real_T, 2U>
  &Kx, const coder::array<creal_T, 2U> &KzT, real_T N, const coder::array<real_T,
  2U> &W0, const coder::array<creal_T, 2U> &V0, real_T grid_urT, real_T grid_erT,
  char_T mode, coder::array<real_T, 2U> &Wtrn, coder::array<creal_T, 2U>
  &Strn_S11, coder::array<creal_T, 2U> &Strn_S12, coder::array<creal_T, 2U>
  &Strn_S21, coder::array<creal_T, 2U> &Strn_S22)
{
  coder::array<creal_T, 2U> A;
  coder::array<creal_T, 2U> B;
  coder::array<creal_T, 2U> Vtrn;
  coder::array<creal_T, 2U> b_Y;
  coder::array<creal_T, 2U> lam;
  coder::array<real_T, 2U> Q;
  coder::array<real_T, 2U> Y;
  emlrtStack b_st;
  emlrtStack st;
  int32_T i;
  int32_T loop_ub;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  //  Transmitted modes throught the device
  st.site = &cf_emlrtRSI;
  coder::eye(&st, N, Wtrn);
  if (N != static_cast<int32_T>(muDoubleScalarFloor(N))) {
    emlrtIntegerCheckR2012b(N, &n_emlrtDCI, sp);
  }

  Vtrn.set_size((&rd_emlrtRTEI), sp, (static_cast<int32_T>(N)),
                (static_cast<int32_T>(N)));
  loop_ub = static_cast<int32_T>(N) * static_cast<int32_T>(N);
  for (i = 0; i < loop_ub; i++) {
    Vtrn[i].re = 0.0;
    Vtrn[i].im = 0.0;
  }

  if (mode == 'E') {
    st.site = &df_emlrtRSI;
    coder::power(&st, Kx, Q);
    loop_ub = Q.size(0) * Q.size(1);
    for (i = 0; i < loop_ub; i++) {
      Q[i] = Q[i] / grid_urT;
    }

    st.site = &df_emlrtRSI;
    coder::eye(&st, N, Y);
    loop_ub = Y.size(0) * Y.size(1);
    for (i = 0; i < loop_ub; i++) {
      Y[i] = Y[i] * grid_erT;
    }

    emlrtSizeEqCheckNDR2012b(Q.size(), Y.size(), &j_emlrtECI, sp);
    loop_ub = Q.size(0) * Q.size(1);
    for (i = 0; i < loop_ub; i++) {
      Q[i] = Q[i] - Y[i];
    }

    lam.set_size((&vd_emlrtRTEI), sp, KzT.size(0), KzT.size(1));
    loop_ub = KzT.size(0) * KzT.size(1);
    for (i = 0; i < loop_ub; i++) {
      lam[i].re = 0.0 * KzT[i].re - KzT[i].im;
      lam[i].im = 0.0 * KzT[i].im + KzT[i].re;
    }

    st.site = &ef_emlrtRSI;
    if (lam.size(1) != Q.size(1)) {
      emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
        "MATLAB:dimagree", 0);
    }

    b_st.site = &bc_emlrtRSI;
    coder::internal::mrdiv(&b_st, Q, lam, Vtrn);
  } else {
    if (mode == 'H') {
      //      Q = (Kx.^2)/grid.erT - eye(N) * grid.urT;
      lam.set_size((&sd_emlrtRTEI), sp, KzT.size(0), KzT.size(1));
      loop_ub = KzT.size(0) * KzT.size(1);
      for (i = 0; i < loop_ub; i++) {
        lam[i].re = 0.0 * KzT[i].re - KzT[i].im;
        lam[i].im = 0.0 * KzT[i].im + KzT[i].re;
      }

      Y.set_size((&td_emlrtRTEI), sp, Wtrn.size(0), Wtrn.size(1));
      loop_ub = Wtrn.size(0) * Wtrn.size(1);
      for (i = 0; i < loop_ub; i++) {
        Y[i] = Wtrn[i] / grid_erT;
      }

      st.site = &ff_emlrtRSI;
      b_st.site = &ye_emlrtRSI;
      if (Y.size(1) != lam.size(0)) {
        if (((Y.size(0) == 1) && (Y.size(1) == 1)) || ((lam.size(0) == 1) &&
             (lam.size(1) == 1))) {
          emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
            "MATLAB:innerdim", 0);
        }
      }

      b_Y.set_size((&xb_emlrtRTEI), (&st), Y.size(0), Y.size(1));
      loop_ub = Y.size(0) * Y.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_Y[i].re = Y[i];
        b_Y[i].im = 0.0;
      }

      Vtrn.set_size((&ud_emlrtRTEI), (&st), b_Y.size(0), lam.size(1));
      loop_ub = b_Y.size(0);
      for (i = 0; i < loop_ub; i++) {
        int32_T b_loop_ub;
        b_loop_ub = lam.size(1);
        for (int32_T i1 = 0; i1 < b_loop_ub; i1++) {
          int32_T c_loop_ub;
          Vtrn[i + Vtrn.size(0) * i1].re = 0.0;
          Vtrn[i + Vtrn.size(0) * i1].im = 0.0;
          c_loop_ub = b_Y.size(1);
          for (int32_T i2 = 0; i2 < c_loop_ub; i2++) {
            Vtrn[i + Vtrn.size(0) * i1].re = Vtrn[i + Vtrn.size(0) * i1].re +
              (b_Y[i + b_Y.size(0) * i2].re * lam[i2 + lam.size(0) * i1].re -
               b_Y[i + b_Y.size(0) * i2].im * lam[i2 + lam.size(0) * i1].im);
            Vtrn[i + Vtrn.size(0) * i1].im = Vtrn[i + Vtrn.size(0) * i1].im +
              (b_Y[i + b_Y.size(0) * i2].re * lam[i2 + lam.size(0) * i1].im +
               b_Y[i + b_Y.size(0) * i2].im * lam[i2 + lam.size(0) * i1].re);
          }
        }
      }

      //  according to Moharam and Gaylord.
    }
  }

  st.site = &gf_emlrtRSI;
  coder::mldivide(&st, W0, Wtrn, Y);
  st.site = &gf_emlrtRSI;
  coder::mldivide(&st, V0, Vtrn, A);
  emlrtSizeEqCheckNDR2012b(Y.size(), A.size(), &k_emlrtECI, sp);
  loop_ub = Y.size(0) * Y.size(1);
  A.set_size((&wd_emlrtRTEI), sp, Y.size(0), Y.size(1));
  for (i = 0; i < loop_ub; i++) {
    A[i].re = Y[i] + A[i].re;
    A[i].im = A[i].im;
  }

  st.site = &hf_emlrtRSI;
  coder::mldivide(&st, W0, Wtrn, Y);
  st.site = &hf_emlrtRSI;
  coder::mldivide(&st, V0, Vtrn, B);
  emlrtSizeEqCheckNDR2012b(Y.size(), B.size(), &l_emlrtECI, sp);
  loop_ub = Y.size(0) * Y.size(1);
  B.set_size((&xd_emlrtRTEI), sp, Y.size(0), Y.size(1));
  for (i = 0; i < loop_ub; i++) {
    B[i].re = Y[i] - B[i].re;
    B[i].im = 0.0 - B[i].im;
  }

  st.site = &if_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, B, A, Strn_S11);
  st.site = &jf_emlrtRSI;
  if (A.size(1) != B.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &emlrtRTEI, "MATLAB:dimagree",
      "MATLAB:dimagree", 0);
  }

  b_st.site = &bc_emlrtRSI;
  coder::internal::mrdiv(&b_st, B, A, lam);
  st.site = &jf_emlrtRSI;
  b_st.site = &ye_emlrtRSI;
  if (lam.size(1) != B.size(0)) {
    if (((lam.size(0) == 1) && (lam.size(1) == 1)) || ((B.size(0) == 1) &&
         (B.size(1) == 1))) {
      emlrtErrorWithMessageIdR2018a(&b_st, &g_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &f_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  b_st.site = &xe_emlrtRSI;
  coder::internal::blas::mtimes(&b_st, lam, B, Vtrn);
  emlrtSizeEqCheckNDR2012b(A.size(), Vtrn.size(), &m_emlrtECI, sp);
  Strn_S12.set_size((&yd_emlrtRTEI), sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    Strn_S12[i].re = 0.5 * (A[i].re - Vtrn[i].re);
    Strn_S12[i].im = 0.5 * (A[i].im - Vtrn[i].im);
  }

  st.site = &kf_emlrtRSI;
  coder::inv(&st, A, lam);
  Strn_S21.set_size((&ae_emlrtRTEI), sp, lam.size(0), lam.size(1));
  loop_ub = lam.size(0) * lam.size(1);
  for (i = 0; i < loop_ub; i++) {
    Strn_S21[i].re = 2.0 * lam[i].re;
    Strn_S21[i].im = 2.0 * lam[i].im;
  }

  b_Y.set_size((&be_emlrtRTEI), sp, A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_Y[i].re = -A[i].re;
    b_Y[i].im = -A[i].im;
  }

  st.site = &lf_emlrtRSI;
  coder::mldivide(&st, b_Y, B, Strn_S22);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

// End of code generation (calcTransmissionSide.cpp)
