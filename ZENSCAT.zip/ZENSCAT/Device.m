function device = Device(NH,grid,interface, Work, interface_stuff, is_flat)
layer_num = grid.layer_num;
w_r       = 0;
Length    = grid.Length;
switch Work
    case 'Fields'
        w_r = 1;
    case 'Casual'
        w_r = 0;
    case 'Optimze'
        w_r = 0;
end
if nargin == 5
    is_flat = 0;
else
    is_flat = 1;
end
%% Various structures
    %% cases for different interfaces
    if strcmp(interface, 'sin') == 1
        z = grid.h/2 * sin(grid.qx * grid.x - pi/2); % Ideal harmonic (Sine) interface
    elseif strcmp(interface, 'DE1') == 1
        z = trapezium(grid.x, grid, interface_stuff) - grid.h/2;
        z = [z(:,floor(grid.Nx/2+1):end) flip(z(:,floor(grid.Nx/2+1):end),2)]; % Ideal trapezium interface
    elseif strcmp(interface, 'DE4') == 1 %% DE4 is softened edges of the trapezium grating
        z = Trapezium_Softened(grid.x, grid, interface_stuff) - grid.h/2; % Supergaussian interface
    elseif strcmp(interface, 'tri') == 1
        z = Triangle(grid.x, grid, interface_stuff);
    else
        z = grid.h/2 * sin(grid.qx * grid.x - pi/2); % if else, C++ style
    end
    d = zeros(1+length(Length),length(z)); % Define d matrix - locations of interfaces + substrate
    %% ----------------- Main interface conversion to array  ----------------- 
    d(1,:) = z;
    for i = 1:length(Length)
        if and(Length(i) > grid.h,w_r == 0) % Field
            Length(i) = grid.h/(grid.Nz) + grid.h;
        end
        d(i+1,:) = z(:) - sum(Length(1:i));
    end 
    Area  = grid.erR * ones(grid.Nx,grid.Nz+grid.delta); % air vs n_high
    %% ----------------- Main interface conversion to array  ----------------- 
    idx = 1; % idx for all arbitrary profiles
    for i = 1:length(Length) + 1
        if i == length(Length) + 1
           idx = length(Length); % it is written that way to make the program work
        end
        d_0 = d(i,:);
        for nx = 1:grid.Nx
            nz  = round((d_0(nx) + grid.Lz/2)/grid.dz); % create epsilon(z,x)
            Area(nx,1:nz+grid.delta) = grid.erIdx(idx);
        end
        idx = idx + 1;
    end        
    %% Substrate part

    % d_0 = d(end,:); % substrate profile
    
    if is_flat
        d_0 = z(:) * 0 - sum(Length) + 1*grid.h/2; % flat surface
    else
        d_0 = d(end,:);
    end

    for nx = 1:grid.Nx
        nz  = round((d_0(nx) + grid.Lz/2)/grid.dz);
        Area(nx,1:nz+grid.delta) = grid.erSub;
    end
    %% Post processing part
    ER = rot90(Area);

    ER(ER<=0) = 1;
    D         = size(ER);
    %% find indices where epsilon of substrate is the same and destroy it!
    if w_r == 0
        Ind_Substr = zeros(1,D(1)); 
        for i = 1:D(1)
            Ind_Substr(i) = sum(ER(i,:))/length(ER(i,:)) - grid.erSub;
        end
        idx_substr = abs(Ind_Substr) < 1e-6; % if the difference smaller than tolerance
        dck = diff(idx_substr); Substr_Index = find(dck==1);
        ER(Substr_Index + 4:end,:) = [];
        D = size(ER);
    end
    %% find indices where epsilon is the same - put bigger thicknesses there when L_i > h
    indices = zeros(length(Length),D(1)); 
    for j = 1:length(Length)
        for i = 1:D(1)
            indices(j,i) = sum(ER(i,:))/length(ER(i,:)) - grid.erIdx(j);
        end
    end
    idx   = abs(indices) < 1e-6;
    sub_L = GeometrySub_Lengths(grid,idx, w_r, interface);
    %% Convolution for smoothing the edges if n(x,z) is not smooth
    % constructing unit cell and the whole device
    % smoothing the grid -> Modelling is closer to reality by using fft. It
    % softens the edges and smoothes epsilon(x,z)
    B = exp(-((grid.x-mean(grid.x))/grid.Lx*100).^8);
    SS = size(Area);
    if interface_stuff.smooth == 1
        for j = 1:layer_num
            for i = SS(2):length(ER(:,1,1))
                ER0 = fft(ER(i,:,j)).*fft(B)/sum(B(:));
                ER0 = ifftshift((ifft(ER0)));
                ER(i,:,j) = ER0;
            end
        end
    end
    %% Fourier transform along z and calculate convolution matrix
    % ER(1,:) = 1;
    E = convmat1D(ER,NH);
    %% Save all the data inside the structure
    device.ER  = ER;
    device.eps = [];
    device.ERC = E; 
    device.sub_L = sub_L * 1e-6; % conversion to nm (Used for X = expm(- sub_L * k0 * eigen_val)

    sum(device.sub_L)
    % plot(device.sub_L)
    if w_r == 1
        %% discretize z
        clear z
        S = size(Area_sup);
        z1 = linspace(-grid.dz * length(Area_sup), 0, S(1));
        z2 = linspace(0, grid.dz * length(Area), length(Area));
        z = [z1 z2];
        device.z = z;
    end
end