# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 17:23:06 2024

@author: toran
"""

import matplotlib.pyplot as plt
import numpy as np
import scipy

#------------------- rectangle function --------------------------------------
def rec(x):
    return abs(x) <= 0.5

#-------------- params that are saved to RCWA --------------------------------
Nx     = int(1028)
Lx     = 0.530
h      = 0.230
x      = np.linspace(-Lx/2, Lx/2, Nx)

#------------ refractive index of a BIC device -------------------------------
n_rec     = 2 #HfO2
layer_num = 2
w_rec     = 0.5*Lx

#--------------------- assign permitivities ----------------------------------
er1 = 2.0**2
er2 = 1.47**2

n1 = rec(x/w_rec)
n1 = 1 - n1
n1 = n1 * (1 - n_rec) + n_rec
n2 = er1 * np.ones(Nx)
n3 = er2 * np.ones(Nx)

##################### Construct a device #####################################
ER      = np.ones((layer_num + 1, Nx))
ER[0,:] = n1**2
ER[1,:] = er2
ER[2,:] = n1**2

sub_L = np.zeros(layer_num + 1)


sub_L[0] = h
sub_L[1] = 0.215
sub_L[2] = h

################ Vizualize relative permittivity #############################
plt.imshow(ER, aspect = 'auto')
plt.colorbar()

#---------------------- Save data into .mat ----------------------------------
data = {    'x': x,
        'sub_L': sub_L,
           'ER': ER,
           'Lx': Lx}
 
scipy.io.savemat('RCWA_DATA.mat', data)
np.save('RCWA_DATA.py',data)